document.addEventListener('DOMContentLoaded', inicializar);

// TODO: Criação do mapa de telas para registrar no roteador

function inicializar() {
    // TODO: Registro das telas no roteador (requisito do framework)
    
    mapearAcaoBotoes();
}

function mapearAcaoBotoes() {
    document
        .getElementById('btn-exemplos')
        .addEventListener('click', montarTelaExemplos);
    
    document
        .getElementById('btn-idiomas')
        .addEventListener('click', montarTelaIdiomas);
    
    document
        .getElementById('btn-categorias')
        .addEventListener('click', montarTelaCategorias);
}

function montarTelaExemplos() {
    // TODO: Remoção da montagem manual da tela de exemplos
    document.getElementById('conteudo').innerHTML = '<h2>Tela de Exemplos</h2>';

    // TODO: Carregamento integrado da tela de exemplos através do roteador
}

function montarTelaIdiomas() {
    // TODO: Remoção da montagem manual da tela de idiomas
    document.getElementById('conteudo').innerHTML = '<h2>Tela de Idiomas</h2>';

    // TODO: Carregamento integrado da tela de idiomas através do roteador
}

function montarTelaCategorias() {
    // TODO: Remoção da montagem manual da tela de categorias
    document.getElementById('conteudo').innerHTML = '<h2>Tela de Categorias</h2>';

    // TODO: Carregamento integrado da tela de categorias através do roteador
}
