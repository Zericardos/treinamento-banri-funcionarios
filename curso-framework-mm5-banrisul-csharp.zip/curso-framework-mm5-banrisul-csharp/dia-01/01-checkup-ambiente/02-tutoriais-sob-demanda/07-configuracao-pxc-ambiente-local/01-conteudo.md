# Configuração de provisionamento do sistema PXC no ambiente operacional local

Para configurar o sistema `PXC` (e qualquer outro CSS) no ambiente operacional local vamos fazer uso da ferramenta do [PZP](../../dicionario-banrisul.md#pzp---ferramenta-de-apoio-ao-desenvolvimento): **IIS Tools**:

![IIS Tools](./_assets/01-iis-tools.png)

O **IIS Tools** agrega funcionalidades de configuração dos sistemas através dos seus respectivos [CSS](../../../../dicionario-banrisul.md#css---código-de-sigla-de-sistema)s e também o provisionamento do ambiente operacional local fazendo uso do **[IIS](../../../../dicionario-banrisul.md#iis---internet-information-services) Express**. Uma vez configurado um determinado CSS no **IIS Tools**, o provisionamento local é feito automaticamente com a busca dos arquivos na pasta `C:\Soft\[CSS]\`.

O IIS Express faz uso de um arquivo de configuração chamado `applicationhost.config`, que normalmente fica localizado em `C:\Users\[matricula]\OneDrive - Banrisul S.A\Documentos\IISExpress\config\` (ou `C:\Users\[matricula]\Documents\IISExpress\config\` caso não tenha OneDrive configurado na estação). Esse arquivo é provido automaticamente pelo banco no setup inicial das estações, porém em casos de não existência, pode ser criado automaticamente pelo IIS Express na sua inicialização. É a partir deste arquivo que o IIS Express sabe quais sites estão configurados e como eles devem ser servidos — e também é nele que o **IIS Tools** faz as alterações necessárias para o provisionamento dos sistemas.

Vale ressaltar que podem existir casos em que o arquivo `applicationhost.config` não é provido (tendo que ser criado na primeira execução do IIS Express) ou é provido em um estado incompleto em relação às configurações básicas que já deveriam vir por padrão quando a estação é provida — aqui é necessário um **_pré-setup_**:

No arquivo `applicationhost.config` atualize completamente os dois seguintes trechos:

A partir da tag `<sites>`, atualize completamente para:

```xml
<sites>
    <site name="WebSite1" id="1" serverAutoStart="true">
        <application path="/">
            <virtualDirectory path="/" physicalPath="c:\bergs" />
        </application>
        <application path="/bergs">
            <virtualDirectory path="/" physicalPath="c:\bergs" />
        </application>
        <application path="/PWX">
            <virtualDirectory path="/" physicalPath="C:\soft\PWX" />
        </application>
        <bindings>
            <binding protocol="http" bindingInformation=":80:" />
        </bindings>
    </site>
    <siteDefaults>
        <logFile logFormat="W3C" directory="%IIS_USER_HOME%\Logs" />
        <traceFailedRequestsLogging directory="%IIS_USER_HOME%\TraceLogFiles" enabled="true" maxLogFileSizeKB="1024" />
    </siteDefaults>
    <applicationDefaults applicationPool="Clr4IntegratedAppPool" />
    <virtualDirectoryDefaults allowSubDirConfig="true" />
</sites>
```

e a partir da tag `<modules>`, atualize completamente para:

```xml
<modules>
    <add name="Bergs.Pwx.Pwxocwxn.ContextoWeb" type="Bergs.Pwx.Pwxocwxn.ContextoWeb, Pwxocwxn, Version=4.0.0.0, Culture=neutral, PublicKeyToken=59daf1f8ae89c75c" />
    <add name="IsapiFilterModule" lockItem="true" />
    <add name="BasicAuthenticationModule" lockItem="true" />
    <add name="IsapiModule" lockItem="true" />
    <add name="HttpLoggingModule" lockItem="true" />
    <add name="DynamicCompressionModule" lockItem="true" />
    <add name="StaticCompressionModule" lockItem="true" />
    <add name="DefaultDocumentModule" lockItem="true" />
    <add name="DirectoryListingModule" lockItem="true" />
    <add name="ProtocolSupportModule" lockItem="true" />
    <add name="HttpRedirectionModule" lockItem="true" />
    <add name="ServerSideIncludeModule" lockItem="true" />
    <add name="StaticFileModule" lockItem="true" />
    <add name="AnonymousAuthenticationModule" lockItem="true" />
    <add name="CertificateMappingAuthenticationModule" lockItem="true" />
    <add name="UrlAuthorizationModule" lockItem="true" />
    <add name="WindowsAuthenticationModule" lockItem="true" />
    <add name="IISCertificateMappingAuthenticationModule" lockItem="true" />
    <add name="WebMatrixSupportModule" lockItem="true" />
    <add name="IpRestrictionModule" lockItem="true" />
    <add name="DynamicIpRestrictionModule" lockItem="true" />
    <add name="RequestFilteringModule" lockItem="true" />
    <add name="CustomLoggingModule" lockItem="true" />
    <add name="CustomErrorModule" lockItem="true" />
    <add name="FailedRequestsTracingModule" lockItem="true" />
    <add name="CgiModule" lockItem="true" />
    <add name="FastCgiModule" lockItem="true" />
    <!-- <add name="WebDAVModule" /> -->
    <add name="RewriteModule" />
    <add name="OutputCache" type="System.Web.Caching.OutputCacheModule" preCondition="managedHandler" />
    <add name="Session" type="System.Web.SessionState.SessionStateModule" preCondition="managedHandler" />
    <add name="WindowsAuthentication" type="System.Web.Security.WindowsAuthenticationModule" preCondition="managedHandler" />
    <add name="FormsAuthentication" type="System.Web.Security.FormsAuthenticationModule" preCondition="managedHandler" />
    <add name="DefaultAuthentication" type="System.Web.Security.DefaultAuthenticationModule" preCondition="managedHandler" />
    <add name="RoleManager" type="System.Web.Security.RoleManagerModule" preCondition="managedHandler" />
    <add name="UrlAuthorization" type="System.Web.Security.UrlAuthorizationModule" preCondition="managedHandler" />
    <add name="FileAuthorization" type="System.Web.Security.FileAuthorizationModule" preCondition="managedHandler" />
    <add name="AnonymousIdentification" type="System.Web.Security.AnonymousIdentificationModule" preCondition="managedHandler" />
    <add name="Profile" type="System.Web.Profile.ProfileModule" preCondition="managedHandler" />
    <add name="UrlMappingsModule" type="System.Web.UrlMappingsModule" preCondition="managedHandler" />
    <add name="ApplicationInitializationModule" lockItem="true" />
    <add name="WebSocketModule" lockItem="true" />
    <add name="ServiceModel-4.0" type="System.ServiceModel.Activation.ServiceHttpModule,System.ServiceModel.Activation,Version=4.0.0.0,Culture=neutral,PublicKeyToken=31bf3856ad364e35" preCondition="managedHandler,runtimeVersionv4.0" />
    <add name="ConfigurationValidationModule" lockItem="true" />
    <add name="UrlRoutingModule-4.0" type="System.Web.Routing.UrlRoutingModule" preCondition="managedHandler,runtimeVersionv4.0" />
    <add name="ScriptModule-4.0" type="System.Web.Handlers.ScriptModule, System.Web.Extensions, Version=4.0.0.0, Culture=neutral, PublicKeyToken=31bf3856ad364e35" preCondition="managedHandler,runtimeVersionv4.0" />
    <add name="ServiceModel" type="System.ServiceModel.Activation.HttpModule, System.ServiceModel, Version=3.0.0.0, Culture=neutral, PublicKeyToken=b77a5c561934e089" preCondition="managedHandler,runtimeVersionv2.0" />
</modules>
```

Com isso o arquivo `applicationhost.config` estará com as configurações básicas necessárias para o correto funcionamento do IIS Express no ecossistema do Banrisul, apesar de ainda não ter nenhum sistema (`PXC` e etc) de fato configurado para execução.

> Notas:
>
> - Olhos atentos notarão que foi mencionado que nenhum sistema ainda estaria configurado, porém no trecho atualizado da tag `<sites>` já existe uma configuração para o sistema `PWX` — isso ocorre porque o `PWX` funciona como a `main` da aplicação, sendo responsável por gerenciar autenticação e menus de acesso aos demais sistemas;
> - O **IIS Tools** pode apresentar erro de inicialização caso o arquivo `applicationhost.config` não esteja presente na pasta esperada. Nesse caso, basta abrir primeiro a própria aplicação isolada do **IIS Express** (também contida no [PZP](../../dicionario-banrisul.md#pzp---ferramenta-de-apoio-ao-desenvolvimento)), que o arquivo será criado automaticamente e o **IIS Tools** passará a funcionar corretamente — o que não significa correto funcionamento do IIS Express no ecossistema do Banrisul, pois o arquivo ainda não terá as configurações básicas necessárias mencionadas acima;
> - Se faz aqui a opção de sempre usar a ferramenta do [PZP](../../dicionario-banrisul.md#pzp---ferramenta-de-apoio-ao-desenvolvimento) **IIS Tools** em detrimento do **IIS Express** pelo fato de através do **IIS Tools** ser possível operar o **IIS Express** com mais facilidade.

## Configurando o sistema PXC no IIS Tools

Para configurar o sistema `PXC` no **IIS Tools**, vamos em **Cadastrar CSS** digitar `PXC` no campo **CSS** e clicar em **Cadastrar**.

> Nota: É possível que após clicar em **Cadastrar** hajam avisos em janelas do Windows ou até mesmo terminal [CMD](../../dicionario-banrisul.md#cmd-command-prompt) indicando que a pasta `C:\Soft\PXC\` já existe — Esses avisos podem ser ignorados e fechados, pois não influenciam no resultado.

Com isso, uma mensagem de sucesso será exibida e o registro `PXC` na lista de CSSs será atualizado para `Soft=sim`, `IIS=sim` e `64 bits=☑`.

![Aviso de sucesso cadastro PXC](./_assets/02-cadastrar-pxc-iis-tools.png)
![Registro PXC na lista](./_assets/03-cadastrar-pxc-iis-tools-registro.png)

No arquivo `applicationhost.config`, basicamente a mudança que ocorrerá será a adição de uma seção `<application>` para o sistema `PXC` dentro do `<site>` — que representa a **aplicação padrão provisionada pelo IIS Express** - sendo cada sistema (CSS) uma _"feature"_ dessa grande aplicação.

A seção `<application>` conterá a rota `/pxc` apontando para a pasta física `C:\Soft\PXC\`:

![Registro PXC no applicationhost.config](./_assets/04-cadastrar-pxc-iis-tools-registro-applicationhost-config.png)

Porém, essa adição automática **demandará uma pequena correção manual**, pois o **IIS Tools** adiciona a seção `<application>` do `PXC` utilizando um pool de aplicações incorreto para o nosso contexto (`DefaultAppPool`), o que pode causar comportamentos inesperados na inicialização do sistema `PXC` no IIS Express.

> Notas:
>
> - Não necessariamente a correção que faremos aqui servirá para qualquer contexto de atuação de time — podem haver variações e necessidades de configurações de pools diferentes em cada contexto. Nesse caso sempre consulte o seu time específico quando necessário;
> - Pesquise por conta própria a respeito de pools de aplicações — não será abordado nem explicado em aula por questão de brevidade.

Vamos então abrir o arquivo `applicationhost.config` novamente e localizar a seção `<sites>`, onde encontraremos o trecho adicionado automaticamente pelo **IIS Tools**:

```xml
<sites>
    <site name="WebSite1" id="1" serverAutoStart="true">
        <!-- [...] -->
        <application path="/PXC" applicationPool="DefaultAppPool">
            <virtualDirectory path="/" physicalPath="c:\soft\PXC" />
        </application>
        <!-- [...] -->
    </site>
    <!-- [...] -->
</sites>
```

Vamos apenas remover o atributo `applicationPool="DefaultAppPool"` da seção `<application>` do `PXC`, ficando assim:

```xml
<sites>
    <site name="WebSite1" id="1" serverAutoStart="true">
        <!-- [...] -->
        <application path="/PXC">
            <virtualDirectory path="/" physicalPath="c:\soft\PXC" />
        </application>
        <!-- [...] -->
    </site>
    <!-- [...] -->
</sites>
```

Salve o arquivo `applicationhost.config` após a alteração e reinicie o **IIS Tools** para que as alterações tenham efeito.

Com isso, o sistema `PXC` estará devidamente configurado no ambiente operacional local.
