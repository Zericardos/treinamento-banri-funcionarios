# Provisionamento do ambiente operacional local

Para provisionar o ambiente operacional local vamos fazer uso da ferramenta do [PZP](../../dicionario-banrisul.md#pzp---ferramenta-de-apoio-ao-desenvolvimento): **IIS Tools**:

![IIS Tools](./_assets/01-iis-tools.png)

O **IIS Tools** agrega funcionalidades de configuração dos sistemas através dos seus respectivos [CSS](../../../../dicionario-banrisul.md#css---código-de-sigla-de-sistema)s e também o provisionamento do ambiente operacional local fazendo uso do **[IIS](../../../../dicionario-banrisul.md#iis---internet-information-services) Express**. Uma vez configurado um determinado CSS no **IIS Tools**, o provisionamento local é feito automaticamente com a busca dos arquivos na pasta `C:\Soft\[CSS]\`.

Se nos recordarmos que existem rotinas automáticas de monitoramento e sincronização entre as pastas `Desenvhome` (onde ficam os projetos ativos e o código-fonte em edição no Visual Studio) e `Soft`, podemos concluir que o ambiente operacional local estará sempre atualizado com os últimos builds realizados no Visual Studio:

![Fluxo de pastas](./_assets/02-fluxo-pastas-desenvolvimento.png)

Ou seja, enquanto o **IIS Express** estiver executando, teremos uma espécie de [CI](../../../../dicionario-banrisul.md#ci---continuous-integration) entre o ambiente local e o código sendo compilado no Visual Studio.

> Essa solução funciona basicamente para o backend MM4 e uma parte estrutural do frontend MM5, mas não tem o mesmo comportamento para os recursos mais dinâmicos do frontend como arquivos [HTML](../../../../dicionario-banrisul.md#html---hypertext-markup-language), [CSS](../../../../dicionario-banrisul.md#css---cascading-style-sheets) e JavaScript — Para solucionar a integração desses outros recursos, vamos fazer uso de uma outra ferramenta que será abordada na sequência, que funciona como uma espécie de ferramenta de [_live reloading_](../../../../dicionario-banrisul.md#live-reloading) parcial (só demandando refresh da página mas sem precisar reiniciar toda a aplicação).

## Inicializando o provisionamento

Para iniciar o provisionamento, basta abrir o **IIS Tools** e o IIS Express será iniciado automaticamente:

![Log do IIS Express](./_assets/03-iis-express-log.png)

É importante que a linha que expressa a inicialização da rota do sistema `PXC` esteja visível no log do IIS Express:

![Log PXC do IIS Express](./_assets/04-iis-express-log-pxc.png)

Isso indicará que o sistema `PXC` está devidamente configurado e ativo no ambiente local.

Caso o log não apresente essa linha, será necessário configurar o sistema `PXC` no ambiente operacional local: [configuração de provisionamento do sistema PXC no ambiente operacional local](../07-configuracao-pxc-ambiente-local/01-conteudo.md)

As configurações do **IIS Tools** podem ficar todas com os seus valores padrão enquanto a execução estiver em andamento. Uma opção que pode ser ativada conforme conveniência é a de fechamento automático do IIS Express ao fechar o **IIS Tools** através da opção **Opções ⟹ Finalizar IIS ao fechar IISTools**:

![Fechamento automático do IIS Express](./_assets/05-iis-tools-fechamento-automatico-iis-express.png)

> Nota: Os botões **Iniciar**, **Finalizar** e **Reiniciar** são todos para a operação do IIS Express, assim como o botão **Abrir localhost** também efetua a abertura da aplicação no navegador já através do endereço correto: (<http://[nome-de-patrimonio].corp.banrisul.com.br/pwx/>):
>
> ![Gerenciamento IIS no IIS Tools](./_assets/06-gerenciamento-iis-iis-tools.png)

Com o IIS Express em execução, ao abrir o navegador no endereço <http://[nome-de-patrimonio].corp.banrisul.com.br/pwx/> o login será requerido, e após o menu a opção `PXC  Treinamento MM5` deverá estar visível:

![PXC - Menu Treinamento MM5](./_assets/07-ambiente-local-menu-pxc.png)

> Nota: Caso a opção não esteja sendo exibida nem no seu ambiente local, significa que a permissão não está atribuída. Solicite acesso ao `PXC  Treinamento MM5` à sua liderança.

Acessando o menu, a tela de aplicação então abrirá normalmente:

![PXC - Aplicação Treinamento MM5](./_assets/08-ambiente-local-tela-inicial-pxc.png)

> Nota: A mensagem `Erro de Servidor no Aplicativo '/PXC'. - Não é possível encontrar o recurso.` contida na página inicial é normal, pois o frontend MM5 ainda não foi desenvolvido e provisionado no ambiente local.
