﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Pxcuidxn.Test")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcuidxn.Test")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2025")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("a7f2f423-4153-45d9-bcf4-aa92a20aa894")]