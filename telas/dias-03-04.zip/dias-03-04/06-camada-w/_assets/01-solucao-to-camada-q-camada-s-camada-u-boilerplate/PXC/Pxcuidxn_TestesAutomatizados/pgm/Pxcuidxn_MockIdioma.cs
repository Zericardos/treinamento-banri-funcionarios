﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pxc.Pxcbtoxn;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuidxn.Tests
{
    /// <summary>
    /// Contém os métodos de mock para testes da classe Idioma
    /// </summary>
    public class MockIdioma: AbstractMmMock
    {
        /// <summary>
        /// Construtor da classe de mocks
        /// </summary>
        /// <param name="infra">Infra</param>
        public MockIdioma(InfraTeste infra) : base(infra)
        { }

        /// <summary>
        /// Registra um mock para o método Alterar
        /// </summary>
        public void MockarAlterarQComFalha()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoFalhaControlada = Infra.RetornarFalha<int>(new MensagemFalhaTestador("Alterar"));

            mockIdiomaBD
                .Alterar(matcherToIdiomaEsperado)
                .Retorna(resultadoFalhaControlada);
        }

        /// <summary>
        /// Registra um mock para o método Contar
        /// </summary>
        public void MockarContarQComFalha()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoFalhaControlada = Infra.RetornarFalha<long>(new MensagemFalhaTestador("Contar"));

            mockIdiomaBD
                .Contar(matcherToIdiomaEsperado)
                .Retorna(resultadoFalhaControlada);
        }

        /// <summary>
        /// Registra um mock para o método Excluir
        /// </summary>
        public void MockarExcluirQComFalha()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoFalhaControlada = Infra.RetornarFalha<int>(new MensagemFalhaTestador("Excluir"));

            mockIdiomaBD
                .Excluir(matcherToIdiomaEsperado)
                .Retorna(resultadoFalhaControlada);
        }

        /// <summary>
        /// Registra um mock para o método Incluir
        /// </summary>
        public void MockarIncluirQComFalha()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoFalhaControlada = Infra.RetornarFalha<int>(new MensagemFalhaTestador("Incluir"));

            mockIdiomaBD
                .Incluir(matcherToIdiomaEsperado)
                .Retorna(resultadoFalhaControlada);
        }

        /// <summary>
        /// Registra um mock para o método Listar
        /// </summary>
        public void MockarListarQComFalha()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();
            var matcherToPaginacaoEsperado = MmMockArgumento.Qualquer<TOPaginacao>();

            var resultadoFalhaControlada = Infra.RetornarFalha<List<TOIdioma>>(new MensagemFalhaTestador("Listar"));

            mockIdiomaBD
                .Listar(matcherToIdiomaEsperado, matcherToPaginacaoEsperado)
                .Retorna(resultadoFalhaControlada);
        }

        /// <summary>
        /// Registra um mock para o método Obter
        /// </summary>
        public void MockarObterQComFalha()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoFalhaControlada = Infra.RetornarFalha<TOIdioma>(new MensagemFalhaTestador("Obter"));

            mockIdiomaBD
                .Obter(matcherToIdiomaEsperado)
                .Retorna(resultadoFalhaControlada);
        }

        /// <summary>
        /// Registra um mock para o método Alterar
        /// </summary>
        public void MockarAlterarQComExcecao()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoExcecaoControlada = Infra.TratarExcecao<int>(new Exception("Simulação de teste de exceção do método Alterar."));

            mockIdiomaBD
                .Alterar(matcherToIdiomaEsperado)
                .Retorna(resultadoExcecaoControlada);
        }

        /// <summary>
        /// Registra um mock para o método Contar
        /// </summary>
        public void MockarContarQComExcecao()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoExcecaoControlada = Infra.TratarExcecao<long>(new Exception("Simulação de teste de exceção do método Contar."));

            mockIdiomaBD
                .Contar(matcherToIdiomaEsperado)
                .Retorna(resultadoExcecaoControlada);
        }

        /// <summary>
        /// Registra um mock para o método Excluir
        /// </summary>
        public void MockarExcluirQComExcecao()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoExcecaoControlada = Infra.TratarExcecao<int>(new Exception("Simulação de teste de exceção do método Excluir."));

            mockIdiomaBD
                .Excluir(matcherToIdiomaEsperado)
                .Retorna(resultadoExcecaoControlada);
        }

        /// <summary>
        /// Registra um mock para o método Incluir
        /// </summary>
        public void MockarIncluirQComExcecao()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoFalhaControladaObter = Infra.RetornarFalha<TOIdioma>(new RegistroInexistenteMensagem());

            mockIdiomaBD
                .Obter(matcherToIdiomaEsperado)
                .Retorna(resultadoFalhaControladaObter);

            var resultadoExcecaoControladaIncluir = Infra.TratarExcecao<int>(new Exception("Simulação de teste de exceção do método Incluir."));

            mockIdiomaBD
                .Incluir(matcherToIdiomaEsperado)
                .Retorna(resultadoExcecaoControladaIncluir);
        }

        /// <summary>
        /// Registra um mock para o método Listar
        /// </summary>
        public void MockarListarQComExcecao()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();
            var matcherToPaginacaoEsperado = MmMockArgumento.Qualquer<TOPaginacao>();

            var resultadoExcecaoControlada = Infra.TratarExcecao<List<TOIdioma>>(new Exception("Simulação de teste de exceção do método Listar."));

            mockIdiomaBD
                .Listar(matcherToIdiomaEsperado, matcherToPaginacaoEsperado)
                .Retorna(resultadoExcecaoControlada);
        }

        /// <summary>
        /// Registra um mock para o método Obter
        /// </summary>
        public void MockarObterQComExcecao()
        {
            var mockIdiomaBD = Mock.Para<Pxcqidxn.Idioma>();

            var matcherToIdiomaEsperado = MmMockArgumento.Qualquer<TOIdioma>();

            var resultadoExcecaoControlada = Infra.TratarExcecao<TOIdioma>(new Exception("Simulação de teste de exceção do método Obter."));

            mockIdiomaBD
                .Obter(matcherToIdiomaEsperado)
                .Retorna(resultadoExcecaoControlada);
        }
    }
}
