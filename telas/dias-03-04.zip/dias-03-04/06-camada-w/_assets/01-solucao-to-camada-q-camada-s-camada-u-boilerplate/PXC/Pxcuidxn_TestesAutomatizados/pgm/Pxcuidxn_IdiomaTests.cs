﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pwx.Pwxoiexn.Validacoes;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsidxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuidxn.Tests
{
    /// <summary>
    /// Contém os métodos de teste da classe Idioma
    /// </summary>
    [TestFixture(Description = "Classe de testes para a classe RN Idioma.", Author = "T07007")]
    public class IdiomaTests: AbstractTesteRegraNegocio<Idioma>
    {
        #region US3 - Alteração de dados de idioma

        /// <summary>
        /// Realiza o teste padrão para o método Alterar(TOIdioma)
        /// Validações realizadas: 
        /// - Altera o registro na base, conforme os dados informados
        /// - Verifica se o retorno do método Alterar foi de sucesso
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo
        /// 2 - Retorno.OK é sucesso (== true)
        /// 3 - Retorno.Dados não está nulo
        /// - Obtém o TO novamente da base, utilizando o método Obter
        /// - Compara o retorno do Obter com os dados do TO preenchido
        /// </summary>
        [Test(Description = "Testa o método Alterar(TOIdioma).", Author = "T07007")]
        public void AlterarComSucessoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar valores necessários para o toIdioma
            // toIdioma.CodIdioma = ;
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.DescIdioma = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;

            var resultado = TestarAlterar(toIdioma);
        }

        /// <summary>
        /// Realiza um teste para o método Alterar com teste de falha de campo obrigatório.
        /// </summary>
        [Test(Description = "Testa o método Alterar(TOIdioma) com falha de campo obrigatório (CodIdioma).", Author = "T07007")]
        public void AlterarFalhaCampoObrigatorioCodIdiomaTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            Retorno<Int32> retorno = this.RN.Alterar(toIdioma);
            MMAssert.FalhaCampoObrigatorio(retorno, "COD_IDIOMA");
            // TODO: Incluir as Assertivas necessárias para o Alterar
        }

        /// <summary>
        /// Realiza um teste para o método Alterar com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Alterar(TOIdioma).", Author = "T07007")]
        public void AlterarComFalhaTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarAlterarQComFalha();
            Retorno<Int32> retorno = this.RN.Alterar(toIdioma);
            MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Alterar
        }

        /// <summary>
        /// Realiza um teste para o método Alterar com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Alterar(TOIdioma).", Author = "T07007")]
        public void AlterarComExcecaoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarAlterarQComExcecao();
            Retorno<Int32> retorno = this.RN.Alterar(toIdioma);
            MMAssert.Excecao<Exception>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Alterar
        }

        #endregion

        #region Contar (Extra (sem US vinculada)

        /// <summary>
        /// Realiza o teste padrão para o método Contar(TOIdioma).
        /// Validações realizadas: 
        /// - Chama o Contar usando os filtros informados.
        /// - Verifica se o retorno do método Contar foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// 4 - Retorno.Dados não é zero.
        /// 
        /// </summary>
        [Test(Description = "Testa o método Contar(TOIdioma).", Author = "T07007")]
        public void ContarComSucessoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar valores necessários para o toIdioma
            // toIdioma.CodIdioma = ;
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.DescIdioma = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            base.TestarContar(toIdioma);
        }

        /// <summary>
        /// Realiza um teste para o método Contar com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Contar(TOIdioma).", Author = "T07007")]
        public void ContarComFalhaTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarContarQComFalha();
            Retorno<Int64> retorno = this.RN.Contar(toIdioma);
            MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Contar
        }

        /// <summary>
        /// Realiza um teste para o método Contar com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Contar(TOIdioma).", Author = "T07007")]
        public void ContarComExcecaoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarContarQComExcecao();
            Retorno<Int64> retorno = this.RN.Contar(toIdioma);
            MMAssert.Excecao<Exception>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Contar
        }

        #endregion

        #region US2 - Remoção de idioma

        /// <summary>
        /// Realiza o teste padrão para o método Excluir(TOIdioma).
        /// Validações realizadas: 
        /// - Exclui o registro na base, conforme a chave informada.
        /// - Verifica se o retorno do método Excluir foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Tenta obter o registro novamente da base, através do método Obter.
        /// - Verifica se o registro não existe mais.
        /// </summary>
        [Test(Description = "Testa o método Excluir(TOIdioma).", Author = "T07007")]
        public void ExcluirComSucessoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar valores necessários para o toIdioma
            // toIdioma.CodIdioma = ;
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.DescIdioma = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            base.TestarExcluir(toIdioma);
        }

        /// <summary>
        /// Realiza um teste para o método Excluir com teste de falha de campo obrigatório.
        /// </summary>
        [Test(Description = "Testa o método Excluir(TOIdioma) com falha de campo obrigatório (CodIdioma).", Author = "T07007")]
        public void ExcluirFalhaCampoObrigatorioCodIdiomaTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            Retorno<Int32> retorno = this.RN.Excluir(toIdioma);
            MMAssert.FalhaCampoObrigatorio(retorno, "COD_IDIOMA");
            // TODO: Incluir as Assertivas necessárias para o Excluir
        }

        /// <summary>
        /// Realiza um teste para o método Excluir com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Excluir(TOIdioma).", Author = "T07007")]
        public void ExcluirComFalhaTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarExcluirQComFalha();
            Retorno<Int32> retorno = this.RN.Excluir(toIdioma);
            MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Excluir
        }

        /// <summary>
        /// Realiza um teste para o método Excluir com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Excluir(TOIdioma).", Author = "T07007")]
        public void ExcluirComExcecaoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarExcluirQComExcecao();
            Retorno<Int32> retorno = this.RN.Excluir(toIdioma);
            MMAssert.Excecao<Exception>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Excluir
        }

        #endregion

        #region Imprimir (Extra (sem US vinculada)

        /// <summary>
        /// Realiza o teste padrão para o método Imprimir(TOIdioma).
        /// Validações realizadas: 
        /// - Chama o método Imprimir usando os filtros informados.
        /// - Verifica se o retorno do método Imprimir foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Verifica se o caminho em Retorno.Dados é existente, ou seja, se o relatório foi gerado.
        /// </summary>
        [Test(Description = "Testa o método Imprimir(TOIdioma).", Author = "T07007")]
        public void ImprimirComSucessoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar valores necessários para o toIdioma
            // toIdioma.CodIdioma = ;
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.DescIdioma = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            base.TestarImprimir(toIdioma);
        }

        /// <summary>
        /// Realiza um teste para o método Imprimir com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Imprimir(TOIdioma).", Author = "T07007")]
        public void ImprimirComFalhaTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarListarQComFalha();
            Retorno<String> retorno = this.RN.Imprimir(toIdioma);
            MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Imprimir
        }

        /// <summary>
        /// Realiza um teste para o método Imprimir com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Imprimir(TOIdioma).", Author = "T07007")]
        public void ImprimirComExcecaoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarListarQComExcecao();
            Retorno<String> retorno = this.RN.Imprimir(toIdioma);
            MMAssert.Excecao<Exception>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Imprimir
        }

        #endregion

        #region US1 - Inclusão de novo idioma

        /// <summary>
        /// Realiza o teste padrão para o método Incluir(TOIdioma)
        /// Validações realizadas: 
        /// - Chama o método Incluir usando os filtros informados
        /// - Verifica se o retorno do método Incluir foi de sucesso
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo
        /// 2 - Retorno.OK é sucesso (== true)
        /// 3 - Retorno.Dados não está nulo
        /// - Obtém o TO novamente da base, utilizando o método Obter
        /// - Compara o retorno do Obter com os dados do TO preenchido
        /// </summary>
        [Test(Description = "TC1 - Testa o método Incluir(TOIdioma).", Author = "T07007")]
        public void TC1IncluirComSucessoTest()
        {
            // A1 Arrange

            var codigoIsoCombinadoEsperado = "en-US";

            Infra.ExecutarSql($"DELETE FROM {TOIdioma.TABELA} WHERE {TOIdioma.CODIGO_IDIOMA} = {Feconid.IsoToCodigo(codigoIsoCombinadoEsperado)}");

            var toIdioma = new TOIdioma()
            {
                CodigoIsoCombinado = codigoIsoCombinadoEsperado,
                DescIdioma = "Inglês estadunidense"
            };

            // A2 Act e A3 Assert

            var resultado = TestarIncluir(toIdioma);

            toIdioma.DescIdioma = new CampoObrigatorio<string>(); // Desseta o valor da descrição para poder mandar como filtragem no Obter desconsiderando a descrição

            var resultadoConsulta = RN.Obter(toIdioma);

            Assert.That(resultadoConsulta.Dados.CodigoIsoCombinado, Is.EqualTo(codigoIsoCombinadoEsperado));
        }

        /// <summary>
        /// Realiza um teste para o método Incluir com teste de campo CodigoIsoCombinado não informado
        /// </summary>
        [Test(Description = "TC2-A - Testa o método Incluir(TOIdioma) com CodigoIsoCombinado não informado.", Author = "T07007")]
        public void TC2AIncluirCodigoIsoCombinadoNaoInformadoTest()
        {
            // A1 Arrange

            var mensagemEsperada = new IdiomaMensagem(TipoIdiomaMensagem.FalhaRnValidarExistenciaCodIso);

            var toIdioma = new TOIdioma()
            {
                DescIdioma = "Inglês estadunidense"
            };

            // A2 Act

            var resultado = RN.Incluir(toIdioma);

            // A3 Assert

            Assert.False(resultado.OK);

            Assert.Zero(resultado.Dados);

            MMAssert.FalhaComMensagem<IdiomaMensagem>(resultado, mensagemEsperada.Identificador);
        }

        /// <summary>
        /// Realiza um teste para o método Incluir com teste de campo CodigoIsoCombinado inválido
        /// </summary>
        [Test(Description = "TC2-B - Testa o método Incluir(TOIdioma) com CodigoIsoCombinado inválido.", Author = "T07007")]
        public void TC2BIncluirCodigoIsoCombinadoInvalidoTest()
        {
            // A1 Arrange

            var mensagemEsperada = new IdiomaMensagem(TipoIdiomaMensagem.FalhaRnConverterCodIsoParaCodNumerico);

            var toIdioma = new TOIdioma()
            {
                CodigoIsoCombinado = "en-U",
                DescIdioma = "Inglês estadunidense"
            };

            // A2 Act

            var resultado = RN.Incluir(toIdioma);

            // A3 Assert

            Assert.False(resultado.OK);

            Assert.Zero(resultado.Dados);

            MMAssert.FalhaComMensagem<IdiomaMensagem>(resultado, mensagemEsperada.Identificador);
        }

        /// <summary>
        /// Realiza um teste para o método Incluir com teste de campo CodigoIsoCombinado inválido (vazio)
        /// </summary>
        [Test(Description = "TC2-C - Testa o método Incluir(TOIdioma) com CodigoIsoCombinado inválido (vazio).", Author = "T07007")]
        public void TC2CIncluirCodigoIsoCombinadoInvalidoVazioTest()
        {
            // A1 Arrange

            var toIdioma = new TOIdioma()
            {
                CodigoIsoCombinado = string.Empty,
                DescIdioma = "Inglês estadunidense"
            };

            var mensagemNaoBrancoEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<NaoBrancoAttribute>(toIdioma, nameof(toIdioma.CodigoIsoCombinado));

            // A2 Act

            var resultado = RN.Incluir(toIdioma);

            // A3 Assert

            Assert.False(resultado.OK);

            Assert.Zero(resultado.Dados);

            Assert.IsInstanceOf<ObjetoInvalidoMensagem>(resultado.Mensagem);

            if (!string.IsNullOrWhiteSpace(mensagemNaoBrancoEsperada))
                Assert.That(resultado.Mensagem.ParaUsuario, Contains.Substring(mensagemNaoBrancoEsperada));
        }

        /// <summary>
        /// Realiza um teste para o método Incluir com teste de outro idioma com mesmo código já cadastrado
        /// </summary>
        [Test(Description = "TC3 - Testa o método Incluir(TOIdioma) com outro idioma com mesmo código já cadastrado.", Author = "T07007")]
        public void TC3IncluirComOutroJaCadastradoTest()
        {
            // A1 Arrange

            var mensagemEsperada = new IdiomaMensagem(TipoIdiomaMensagem.FalhaRnIncluirIdiomaJaExistente);

            var toIdioma = new TOIdioma()
            {
                CodigoIsoCombinado = "en-US",
                DescIdioma = "Inglês estadunidense"
            };

            Infra.ExecutarSql($"DELETE FROM {TOIdioma.TABELA} WHERE {TOIdioma.CODIGO_IDIOMA} = {Feconid.IsoToCodigo(toIdioma.CodigoIsoCombinado)}");

            Infra.ExecutarSql(
                $"INSERT INTO {TOIdioma.TABELA}({TOIdioma.CODIGO_IDIOMA}, {TOIdioma.DESCRICAO_IDIOMA}, {TOIdioma.CODIGO_USUARIO}, {TOIdioma.DATA_HORA_ULTIMA_ALTERACAO})"
                + $" VALUES({Feconid.IsoToCodigo(toIdioma.CodigoIsoCombinado)}, '{toIdioma.DescIdioma}', '{Infra.Usuario.Matricula}', {BDUtils.BD_CURRENT_TIMESTAMP})"
            );

            // A2 Act

            var resultado = RN.Incluir(toIdioma);

            // A3 Assert

            Assert.False(resultado.OK);

            Assert.Zero(resultado.Dados);

            MMAssert.FalhaComMensagem<IdiomaMensagem>(resultado, mensagemEsperada.Identificador);
        }

        /// <summary>
        /// Realiza um teste para o método Incluir com teste de campo DescIdioma não informado
        /// </summary>
        [Test(Description = "TC4-A - Testa o método Incluir(TOIdioma) com DescIdioma não informado.", Author = "T07007")]
        public void TC4AIncluirDescIdiomaNaoInformadoTest()
        {
            // A1 Arrange

            var mensagemEsperada = new IdiomaMensagem(TipoIdiomaMensagem.FalhaRnValidarExistenciaDescricao);

            var toIdioma = new TOIdioma()
            {
                CodigoIsoCombinado = "en-US",
            };

            // A2 Act

            var resultado = RN.Incluir(toIdioma);

            // A3 Assert

            Assert.False(resultado.OK);

            Assert.Zero(resultado.Dados);

            MMAssert.FalhaComMensagem<IdiomaMensagem>(resultado, mensagemEsperada.Identificador);
        }

        /// <summary>
        /// Realiza um teste para o método Incluir com teste de campo DescIdioma inválido
        /// </summary>
        [Test(Description = "TC4-B - Testa o método Incluir(TOIdioma) com DescIdioma inválido.", Author = "T07007")]
        [TestCase("")]
        [TestCase("Inglê$ &st@dunid&ns&")]
        public void TC4BIncluirDescIdiomaInvalidoTest(string descIdioma)
        {
            // A1 Arrange

            var toIdioma = new TOIdioma()
            {
                CodigoIsoCombinado = "en-US",
                DescIdioma = descIdioma
            };

            var mensagemAlfanumericoEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<AlfanumericoAttribute>(toIdioma, nameof(toIdioma.DescIdioma));

            // A2 Act

            var resultado = RN.Incluir(toIdioma);

            // A3 Assert

            Assert.False(resultado.OK);

            Assert.Zero(resultado.Dados);

            Assert.IsInstanceOf<ObjetoInvalidoMensagem>(resultado.Mensagem);

            if (!string.IsNullOrWhiteSpace(mensagemAlfanumericoEsperada))
                Assert.That(resultado.Mensagem.ParaUsuario, Contains.Substring(mensagemAlfanumericoEsperada));
        }

        /// <summary>
        /// Realiza um teste para o método Incluir com teste de falha.
        /// </summary>
        [Test(Description = "TC5 (Extra/Erro na Q) - Testa o método Incluir(TOIdioma).", Author = "T07007")]
        public void TC5ExtraIncluirComExcecaoCamadaQTest()
        {
            // A1 Arrange

            var mockIdioma = new MockIdioma(Infra);

            mockIdioma.MockarIncluirQComExcecao();

            var toIdioma = new TOIdioma()
            {
                CodigoIsoCombinado = "en-US",
                DescIdioma = "Inglês estadunidense"
            };

            // A2 Act

            var resultado = RN.Incluir(toIdioma);

            // A3 Assert

            MMAssert.Excecao<Exception>(resultado);
        }

        #endregion

        #region US4 - Listagem de idiomas

        /// <summary>
        /// Realiza o teste padrão para o método Listar(TOIdioma, TOPaginacao).
        /// Validações realizadas: 
        /// - Chama o Listar usando os filtros informados.
        /// - Verifica se o retorno do método Listar foi de sucesso
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// 4 - Retorno.Dados possui elementos.
        /// - Compara o retorno com os dados da lista de TO preenchida antes do teste.
        /// </summary>
        [Test(Description = "Testa o método Listar(TOIdioma, TOPaginacao).", Author = "T07007")]
        public void ListarComSucessoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            TOPaginacao toPaginacao = new TOPaginacao(1, 10);
            // TODO: Setar os valores necessários para o toIdioma
            // TODO: Setar os valores necessários para o toPaginacao
            // toIdioma.CodIdioma = ;
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.DescIdioma = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;

            base.TestarListar(toIdioma, toPaginacao);
        }

        /// <summary>
        /// Realiza um teste para o método Listar com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Listar(TOIdioma, TOPaginacao).", Author = "T07007")]
        public void ListarComFalhaTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            TOPaginacao toPaginacao = null;
            // TODO: Setar os valores necessários para o toPaginacao
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarListarQComFalha();
            Retorno<List<TOIdioma>> retorno = this.RN.Listar(toIdioma, toPaginacao);
            MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Listar
        }

        /// <summary>
        /// Realiza um teste para o método Listar com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Listar(TOIdioma, TOPaginacao).", Author = "T07007")]
        public void ListarComExcecaoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            TOPaginacao toPaginacao = null;
            // TODO: Setar os valores necessários para o toPaginacao
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarListarQComExcecao();
            Retorno<List<TOIdioma>> retorno = this.RN.Listar(toIdioma, toPaginacao);
            MMAssert.Excecao<Exception>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Listar
        }

        #endregion

        #region US5 - Consulta de idioma por código

        /// <summary>
        /// Realiza o teste padrão para o método Obter(TOIdioma).
        /// Validações realizadas: 
        /// - Chama o método Obter usando os filtros de chave informados.
        /// - Verifica se o retorno do método Obter foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Compara o retorno do Obter com os dados do TO preenchido antes do teste.
        /// </summary>
        [Test(Description = "Testa o método Obter(TOIdioma).", Author = "T07007")]
        public void ObterComSucessoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar valores necessários para o toIdioma
            // toIdioma.CodIdioma = ;
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.DescIdioma = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            base.TestarObter(toIdioma);
        }

        /// <summary>
        /// Realiza um teste para o método Obter com teste de falha de campo obrigatório.
        /// </summary>
        [Test(Description = "Testa o método Obter(TOIdioma) com falha de campo obrigatório (CodIdioma).", Author = "T07007")]
        public void ObterFalhaCampoObrigatorioCodIdiomaTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            Retorno<TOIdioma> retorno = this.RN.Obter(toIdioma);
            MMAssert.FalhaCampoObrigatorio(retorno, "COD_IDIOMA");
            // TODO: Incluir as Assertivas necessárias para o Obter
        }

        /// <summary>
        /// Realiza um teste para o método Obter com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Obter(TOIdioma).", Author = "T07007")]
        public void ObterComFalhaTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarObterQComFalha();
            Retorno<TOIdioma> retorno = this.RN.Obter(toIdioma);
            MMAssert.FalhaComMensagem<MensagemFalhaTestador>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Obter
        }

        /// <summary>
        /// Realiza um teste para o método Obter com teste de falha.
        /// </summary>
        [Test(Description = "Testa o método Obter(TOIdioma).", Author = "T07007")]
        public void ObterComExcecaoTest()
        {
            TOIdioma toIdioma = new TOIdioma();
            // TODO: Setar os valores necessários para o toIdioma
            toIdioma.CodIdioma = 0;
            toIdioma.DescIdioma = "Inserir um valor para toIdioma.DescIdioma caso necessário.";
            // toIdioma.CodigoIsoCombinado = ;
            // toIdioma.CodUsuario = ;
            // toIdioma.DthrUltAtu = ;
            MockIdioma classeMock = new MockIdioma(this.Infra);
            classeMock.MockarObterQComExcecao();
            Retorno<TOIdioma> retorno = this.RN.Obter(toIdioma);
            MMAssert.Excecao<Exception>(retorno);
            // TODO: Incluir as Assertivas necessárias para o Obter
        }

        #endregion        

        /// <summary>
        /// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste
        /// </summary>
        protected override void BeforeAll()
        { }

        /// <summary>
        /// Executa uma ação ANTES de cada método de teste da classe
        /// </summary>
        protected override void BeforeEach()
        { }

        /// <summary>
        /// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste
        /// </summary>
        protected override void AfterAll()
        { }

        /// <summary>
        /// Executa uma ação DEPOIS de cada método de teste da classe
        /// </summary>
        protected override void AfterEach()
        { }

        /// <summary>
        /// Método para setar os dados necessários para conexão com o PHA no servidor de build
        /// </summary>
        /// <returns>TO com dados necessários para conexão no servidor de build</returns>
        protected override TOPhaServidorBuild SetarDadosServidorBuild()
        {
            var grupoPha = "GESTAG"; // TODO: Alterar para pegar de um arquivo de configuração (como o Banrisul faz isso?)
            var nomeProdutoPha = "TREINAMENTO MM5"; // TODO: Alterar para pegar de um arquivo de configuração (como o Banrisul faz isso?)

            return new TOPhaServidorBuild(grupoPha, nomeProdutoPha);
        }
    }
}
