﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Pxcqidxn")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcqidxn")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2025")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("c538ce72-63a7-455d-9574-fc2191087ab0")]