# Camada W

A [**camada W**](../../dicionario-banrisul.md#camada-w---camada-web), em uma comparação direta, poderia ser entendida como **o equivalente da UI, com o conjunto formado por um SPA Host e um frontend web**, sendo responsável por tudo que envolve **apresentação e interação com o usuário**.

Enquanto as **camadas** [**S**](../../dicionario-banrisul.md#camada-s---camada-service) e [**Q**](../../dicionario-banrisul.md#camada-q---camada-query) operam no domínio exclusivamente de backend, com o processamento e persistência de dados, a **camada W** existe exclusivamente para fazer a ponte entre backend e frontend, e a ponte entre a aplicação como um todo com o usuário. Ela é o ponto onde a aplicação _"se materializa"_, _"toma forma"_  para quem a utiliza.

Suas responsabilidades incluem:

- Disponibilizar a interface visual da aplicação (arquivos HTML, CSS e JavaScript — componentes frontend);
- Gerenciar trocas entre telas (navegação) e estados visuais;
- Capturar ações do usuário (cliques, envios de formulários e interações em geral);
- Transformar ações do usuário em comandos para execução de operações de processamento e persistência — a serem executadas pelas camadas responsáveis;
- Receber respostas das operações das camadas responsáveis e traduzir essas respostas em feedbacks visuais ao usuário.

Do ponto de vista arquitetural, a **camada W não contém regras de negócio nem conhece detalhes de persistência**. Ela apenas orquestra a experiência do usuário, delegando a operação de dados de backend à camada S.

<!-- ## Wrapper -->

<!-- TODO: Copiar o conteúdo de wrapper pra cá -->

<!-- Tudo daqui pra baixo foi confeccionado em XGH - https://gohorse.com.br/extreme-go-horse-xgh.html | Deve ser completamente refatorado seguindo o mesmo formato de roteiro e nível de detalhes e cuidado adotados para a confecção dos materiais das camadas Q, S e U de MM4 -->
## Camada W no MM5

No MM5, essa camada é implementada segundo o modelo de [**SPA**](../../dicionario-banrisul.md#spa---single-page-application), onde a aplicação web é carregada uma única vez no navegador e, a partir daí, as diferentes telas são exibidas dinamicamente por meio da manipulação do DOM, sem recarregamento completo da página.

### Organização da camada W

A camada W é composta por três grandes blocos que trabalham em conjunto:

- **Interface gráfica (HTML e CSS)**, responsável pelo layout, posicionamento e aparência dos componentes;
- **Código JavaScript**, responsável por controlar o comportamento da interface, estados de tela, eventos e comunicação;
- **Código C# na camada W**, responsável por receber requisições do frontend, invocar a camada S e devolver os resultados processados.

Essa separação permite que o navegador execute toda a lógica de apresentação, enquanto o servidor atua como intermediário entre o usuário e o núcleo da aplicação.

### Navegação e gerenciamento de telas

No MM5, cada tela da aplicação (por exemplo: **Filtro**, **Lista** e **Cadastro**) é representada por uma seção do HTML encapsulada em uma `<div>`. O framework controla quais dessas seções estão visíveis em determinado momento, alternando-as conforme a operação em execução.

Essa abordagem permite:

- Navegação fluida entre telas;
- Manutenção do estado da aplicação no navegador;
- Atualização parcial da interface sem perda de contexto.

A lógica de exibição e ocultação das telas é controlada por JavaScript, que atua diretamente sobre o DOM, enquanto o CSS define os estilos e o layout dessas áreas.

### Comunicação com o servidor

A camada W se comunica com o backend por meio de **chamadas assíncronas** feitas a serviços (ASMX) — porção backend da camada W, utilizando JavaScript. Nessas chamadas:

1. O JavaScript envia dados ao serviço;
2. O serviço ASMX os recebe e os encaminha para um manipulador da própria camada W;
3. Esse manipulador então invoca os métodos da camada S;
4. O resultado é devolvido ao JavaScript;
5. O JavaScript atualiza a interface com base na resposta.

Esse fluxo permite que a interface reaja dinamicamente às operações do usuário sem interromper a navegação.

### Papel do projeto Processa Tela

O projeto **Processa Tela** atua como o **SPA Host** do MM5. Ele é responsável por entregar os arquivos HTML, CSS e JavaScript ao navegador e por aplicar transformações e configurações necessárias antes da exibição das telas.

Além disso, ele centraliza os recursos compartilhados da camada W, garantindo que todas as telas sigam os mesmos padrões visuais e comportamentais.

### Benefícios da abordagem

A forma como a camada W é estruturada no MM5 oferece:

- **Separação clara de responsabilidades** entre apresentação, regras e dados;
- **Reutilização de componentes e padrões de tela**;
- **Experiência de usuário fluida**, típica de aplicações SPA;
- **Isolamento da lógica de negócio**, que permanece concentrada na camada S.

## Laboratório - Laboratório em cima da criação de uma camada W para de Idiomas

Vamos criar a camada W para idiomas

> Na pasta desta aula você pode baixar todo o backend de idiomas.
<!-- Boilerplate em [./_assets/01-projeto-to-boilerplate/] -->

a modelagem SQL implementada na base **IBM DB2**;

```sql
SELECT
    COD_IDIOMA     -- INTEGER  NN PK
  , DESC_IDIOMA    -- CHAR(50) NN
  , COD_USUARIO    -- CHAR(6)
  , DTHR_ULT_ATU   -- TIMESTAMP
FROM PXC.IDIOMA;
```

### Passo 1: Criar o projeto de camada W

Para criar o projeto de camada W vamos usar o **Gerador de Telas MM5**.

Com o gerador aberto, vamos selecionar **Padrão 3 telas** e **Carregar TO**;.

Na janela do explorer, vamos selecionar o projeto de TOs (`pxcbtoxn`) a partir da pasta de output e uso do ambiente local (`C:\Soft\PXC\bin`) e clicar em **Abrir**.

Na listagem que será exibida vamos selecionar o TO de idiomas (`TOIdioma`) e clicar em **Configurar projeto**.

Irá ser exibida uma mensagem de aviso do campo CodigoIsoCombinado não possuir o atributo `CampoTabela` — Isso é esperado, não temos esse campo como uma propriedade a ser persistida. É só clicar em Ok na mensagem e prosseguir.

Na tela principal teremos 5 abas:

- **Projeto:** A aba das configurações do projeto, onde configuraremos componentes do nome do projeto, local de destino da geração, etc;
- **Filtro:** Primeira das 3 telas, uma pré-lista, onde configuraremos como a lista vai ser carregada;
- **Lista:** Segunda das 3 telas, sendo a tela de listagem (equivalente à listagem de um CRUD);
- **Cadastrio:** Terceira das 3 telas, sendo a tela de detalhes para operações em cima de um dos itens (nesse caso idiomas), para edição e exclusão — e em estado vazio também para inclusão de novos itens;
- **Definições:** Uma espécie de recurso de especificações técnicas, para anotações em cima do **projeto** — aqui estamos tratando como projeto de tela porque é possível de se salvar esse projeto de tela para ser recarregado posteriormente no **Gerador de Telas MM5**. Ou seja, essa aba de definições serve como uma área de documentação do projeto de tela (não o utilizaremos).

Na aba **Projeto** já podemos especificar os dados básicos de configuração de projeto:

- Campo produto sempre **Treinamento MM5**;
- identificador o mesmo de sempre para idiomas: `id`;
- Diretório de destino vamos especificar a Genhome.

Tem uma área muito importante na tela de projeto, que é a área **Processamento**. Nela precisamos marcar a opção **Gerar processa TelaHTML**.
Isso ocorre **somente na primeira vez** que estivermos criando uma tela de camada W para uma dada solução — ou seja, é feito uma vez só quando o primeiro frontend da solução `pxckcfxn` estiver sendo definido. É através dessa opção que o projeto **Processa Tela** será criado.

Nas abas das 3 telas, podemos especificar melhor os textos e deixá-los mais "amigáveis". Essa etapa já vai entregar um frontend um pouco mais refinado.

Feitas as alterações em labels para deixar os textos mais amigáveis, clique no botão "play" de **Gerar Projeto** e confirme a geração.

> Certifique-se de fechar o **Gerador de Telas MM5** depois de gerar os projetos, pois o **Gerador de Telas MM5** aberto pode manter alguns arquivos gerados "trancados" ocasionando falha de compilação no _Visual Studio_.

Dentro da `Genhome\PXC\` serão gerados os dois projetos:

- `pxcw00xn_ProcessaTela` - O projeto padrão (que é gerado só uma vez) para fazer o tratamento das telas;
- `pxcwidxn_Idioma` - A camada W de fato para idiomas — para cada TO um projeto diferente desses será criado, assim como é feito nas camadas S, Q e U.

Vamos mover os dois projetos para dentro da solução em `Desenvhome\PXC` (Não esquecendo de adicioná-los também pelo _Visual Studio_).

Compilando a solução, vamos perceber que a pasta `link` da camada W, agora vai estar dentro da pasta do ambiente operacional local `C:\Soft\PXC\link`. Semelhante a uma `wwwroot`, é daqui que o ambiente operacional local vai ler os arquivos de frontend (HTML, CSS e JavaScript).

Execute o **IIS Tools** e abra novamente o ambiente operacional local, navegue para **Treinamento MM5**, menu **MM5** e depois **Idioma** — As telas geradas já devem começar a aparecer para você.

Porém, em termos de funcionalidade, poucas coisas além da navegação estarão realmente funcionais. É nesse momento que começaremos a refinar principalmente o comportamento das telas através dos arquivos HTML e JavaScript.

- Precisamos nos certificar que os campos que estão no HTML são os que realmente queremos para filtragem, listagem e detalhamento;
- Precisamos garantir que o JavaScript está capturando corretamente os valores dos campos do HTML;
- Precisamos garantir que o JavaScript está fazendo as requisições de acordo com os contratos esperados pela camada S;
  - Isso envolve uma revisão tanto no arquivo JavaScript, quando no arquivo C# respectivo à camada W de idiomas (contido dentro do projeto de camada W — subarquivo (também conhecido como "code behind") do `Pxcwidxn_Idioma.cs`).

> Nota: Para uma melhor experiência, abra a pasta `link` como raíz de projeto direto no VSCode.

Algumas características importantes:

- JQuery é bastante utilizado no JavaScript para interagir com elementos da DOM;
- O HTML é bastante personalizado e voltado à filosofia de **HTML semântico**, utilizando uma série de elementos MM;
- No JavaScript o objeto `oInfra` é bastante comum. Ele é um semelhante ao super objeto `Infra` do backend — ou seja, ele é o portador das funcionalidades utilitárias de "framework".

## [Exercícios](02-exercicios.md)
