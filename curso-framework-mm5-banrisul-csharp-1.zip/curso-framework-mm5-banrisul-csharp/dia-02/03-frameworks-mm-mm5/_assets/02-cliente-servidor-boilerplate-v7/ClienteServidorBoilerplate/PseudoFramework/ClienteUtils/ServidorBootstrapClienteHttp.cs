using System;
using System.IO;
using System.Net;
using System.Threading.Tasks;

namespace PseudoFramework.ClienteUtils
{
    public class ServidorBootstrapClienteHttp
    {
        public static string IDENTIFICADOR = "SERVIDOR BOOTSTRAP CLIENTE";

        private bool _executando;
        private string _caminhoBase;
        private string _caminhoBaseArquivos;
        private string _nomeArquivoBootstrap;

        private HttpListener _listener;

        public ServidorBootstrapClienteHttp(string caminhoBase, string caminhoBaseArquivos, string nomeArquivoBootstrap)
        {
            _executando = false;

            _caminhoBase = caminhoBase;

            _caminhoBaseArquivos = caminhoBaseArquivos;

            _nomeArquivoBootstrap = nomeArquivoBootstrap;

            _listener = new HttpListener();

            _listener.Prefixes.Add(_caminhoBase);
        }

        public void Iniciar()
        {
            _listener.Start();

            _executando = true;

            Console.WriteLine($"Iniciado e aguardando requisições em {_caminhoBase}\n");

            Console.WriteLine($"Servindo arquivos de {_caminhoBaseArquivos}\n");

            Task.Run(
                () =>
                {
                    while (_executando)
                    {
                        try
                        {
                            var contexto = _listener.GetContext();

                            Task.Run(() => ProcessarRequisicao(contexto));
                        }
                        catch (HttpListenerException)
                        {
                            if (_executando) throw;
                        }
                        catch (Exception excecao)
                        {
                            Console.WriteLine($" [x] ERRO {excecao.Message}");
                        }
                    }
                }
            );
        }

        public void Encerrar()
        {
            Console.Write($"Encerrando... ");

            _executando = false;

            _listener.Stop();

            Console.Write($"Encerrado.\n\n");
        }

        private void ProcessarRequisicao(HttpListenerContext contexto)
        {
            var requisicaoObjeto = contexto.Request;

            var verboHttp = requisicaoObjeto.HttpMethod;

            var respostaObjeto = contexto.Response;

            if (verboHttp != "GET" && verboHttp != "HEAD")
            {
                respostaObjeto.StatusCode = 405;

                respostaObjeto.Close();

                return;
            }

            var caminhoRelativoArquivo = requisicaoObjeto.Url.AbsolutePath;

            var caminhoAbsolutoArquivo = ResolverArquivo(caminhoRelativoArquivo);

            if (caminhoAbsolutoArquivo == null)
            {
                respostaObjeto.StatusCode = 404;

                respostaObjeto.Close();

                return;
            }

            respostaObjeto.ContentType = DefinirContentType(caminhoAbsolutoArquivo);

            respostaObjeto.StatusCode = 200;

            var respostaBuffer = File.ReadAllBytes(caminhoAbsolutoArquivo);

            respostaObjeto.ContentLength64 = respostaBuffer.Length;

            if (verboHttp == "GET")
            {
                using (var respostaStream = respostaObjeto.OutputStream)
                {
                    respostaStream.Write(respostaBuffer, 0, respostaBuffer.Length);
                }
            }

            respostaObjeto.Close();
        }

        private string ResolverArquivo(string caminhoRelativoArquivo)
        {
            if (caminhoRelativoArquivo == "/")
                caminhoRelativoArquivo = $"/{_nomeArquivoBootstrap}";

            caminhoRelativoArquivo = caminhoRelativoArquivo
                .TrimStart('/')
                .Replace('/', Path.DirectorySeparatorChar);

            var caminhoAbsolutoArquivo = Path.Combine(_caminhoBaseArquivos, caminhoRelativoArquivo);

            if (!File.Exists(caminhoAbsolutoArquivo))
                return null;

            return caminhoAbsolutoArquivo;
        }

        private string DefinirContentType(string caminhoAbsolutoArquivo)
        {
            var extensao = Path
                .GetExtension(caminhoAbsolutoArquivo)
                .ToLower();

            switch (extensao)
            {
                case ".html":
                    return "text/html; charset=utf-8";
                case ".css":
                    return "text/css";
                case ".js":
                    return "application/javascript";
                case ".png":
                    return "image/png";
                case ".jpeg":
                case ".jpg":
                    return "image/jpeg";
                case ".svg":
                    return "image/svg+xml";
                default:
                    return "application/octet-stream";
            }
        }
    }
}
