using System;
using System.IO;

namespace PseudoFramework.SharedUtils
{
    public static class ConectorHttpStaticFiles
    {
        private static string CAMINHO = "wwwroot";
        private static string ARQUIVO = "index.html";

        public static string ObterCaminho(string caminho)
        {
            return Path.Combine(AppContext.BaseDirectory, caminho);
        }

        public static string ObterCaminho()
        {
            return ObterCaminho(CAMINHO);
        }

        public static string ObterNomeArquivo()
        {
            return ARQUIVO;
        }
    }
}
