<!-- 
    Este conteúdo replica o mesmo conteúdo contido no "Curso Framework MM4 Banrisul" (https://github.com/dbserver/curso-framework-mm4-banrisul-csharp/blob/309634cf14c9613627833f923302aa152171cd04/dia-03/04-web-cliente-servidor/01-conteudo.md) com algumas leves mudanças específicas do contexto de MM5.

    - Ao iniciar este "Curso Framework MM5 Banrisul", copie novamente o conteúdo referido acima para este arquivo e verifique as mudanças através de um diff simples, de forma a garantir que todos os elementos sejam atualizados corretamente — ao fazer isso, mantenha as mudanças contextuais sinalizadas com o comentário: "Ajuste de contexto MM5".

    ATENÇÃO: Jamais apague esse comentário.
-->

# Web: Modelo Cliente-Servidor

O **modelo Cliente-Servidor** é um dos pilares da computação moderna. Ele define uma forma organizada de comunicação entre dois componentes principais:

- **Cliente:** A aplicação que **faz uma requisição** — ou seja, que pede algo;
- **Servidor:** A aplicação que **recebe o pedido**, processa a informação e **responde**.

Esse padrão é utilizado em praticamente todos os sistemas distribuídos — de um simples site na web até plataformas corporativas complexas.

É como se as duas partes se comunicassem:

> Cliente: _"Olá servidor, preciso do número de telefone da pessoa chamada John Doe, sei que você armazena a base de lista telefônica aí do seu lado. Pode me mandar?"_
>
> Servidor: _"Claro cliente! já localizei aqui o número para a pessoa com esse nome. Aqui está: (99) 95959-9595."_

Para que esse tipo de interação seja possível, existem diversos **padrões, protocolos e formatos** que regulam a comunicação entre sistemas, como:

- **Protocolos de comunicação:** HTTP, HTTPS, FTP, SMTP, AMQP, gRPC, entre outros;
- **Formatos de troca de dados:** Texto, XML, JSON, BSON, TOON, binário, entre outros.

## Protocolos de comunicação

Um **protocolo de comunicação** define _como_ duas partes devem se comportar durante interação mútua — em outras palavras, ele é a **regra de convivência e interação** que cliente e servidor precisam seguir para conviver em harmonia.

No desenvolvimento de aplicações, os protocolos mais comuns se dividem em duas categorias:

### Protocolos síncronos

São baseados no ciclo **requisição - resposta imediata**. Ou seja: o cliente envia um pedido e **aguarda a resposta no mesmo canal** antes de continuar.

O exemplo mais conhecido é o **[HTTP](../../dicionario-banrisul.md#http---hypertext-transfer-protocol) (e sua variação segura, [HTTPS](../../dicionario-banrisul.md#https---hypertext-transfer-protocol-secure))**, utilizado em praticamente toda a web.

Neste modelo, o ciclo costuma ser:

- Cliente: Abre uma conexão com o servidor;
- Cliente: Envia uma requisição indicando um **verbo de intenção** (`GET`, `POST`, `PUT`, `DELETE`, entre outros — verbos HTTP);
- Cliente: Aguarda o processamento e resposta do servidor;
- Servidor: Recebe o indicativo de conexão e aceita a abertura;
- Servidor: Recebe a requisição e a processa conforme a intenção expressa pelo cliente;
- Servidor: Devolve a resposta adequada ao cliente;
- Cliente: Recebe a resposta do servidor;
- Fecha ou reutiliza a conexão para um próximo ciclo.

Esse tipo de comunicação é mais intuitivo, sendo ideal para operações rápidas e transações que precisam de confirmação imediata.

### Protocolos assíncronos

Baseiam-se em um sistema denominado **mensageria** — onde o cliente envia uma mensagem e **não precisa aguardar a resposta de imediato**. Ele continua seu trabalho, e quando o servidor processar a mensagem, a resposta chega **por outro canal**, às vezes minutos (ou horas... ou dias) depois.

Esse tipo de comunicação usa um intermediário, chamado **[Message Broker](../../dicionario-banrisul.md#message-broker)**, que pode ser, por exemplo, o **RabbitMQ**, que através de um protocolo AMQP, possibilita um ciclo semelhante a este:

- Cliente: Abre uma conexão com o message broker;
- Servidor: Abre uma conexão com o message broker;
- Cliente: Envia uma mensagem de requisição para uma fila específica, mapeada pelo message broker;
- Servidor: Está previamente inscrito na mesma fila que o message broker mapeou, e assim que pode, recebe a mensagem de requisição através da fila em questão e inicia o processamento;
- Servidor: Quando finalizado o processamento e for necessário, envia a mensagem de resposta para a fila de retorno também mapeada pelo message broker;
- Cliente: Assim como o servidor, está previamente inscrito na fila de retorno, assim, recebe a mensagem de resposta através dessa fila;
- Cliente e Servidor: Mantêm conexões ativas com o message broker.

Esse tipo de comunicação é menos intuitivo, mas agrega níveis mais sofisticados de confiabilidade e resiliência, sendo ideal para transações que possibilitam processamento que não necessita ser imediato, mas precisa ser confiável e pode ocorrer em grandes volumes.

## Formatos de troca de dados

Se o protocolo de comunicação é a regra de convivência e interação, o **formato de troca de dados** pode ser entendido como o **idioma** usado por cliente e servidor para se comunicarem.

Ou seja, mesmo que ambos sigam as regras de boa convivência, se falarem idiomas diferentes, a interação vai continuar sendo ineficaz.

No desenvolvimento de aplicações, alguns formatos comuns de trocas de arquivos são:

- **Texto simples (plain text):** Ideal para mensagens rápidas e legíveis;
- **[XML](../../dicionario-banrisul.md#xml---extensible-markup-language):** Mais verboso, permite estruturas complexas e validações mais estruturadas de dados;
- **[JSON](../../dicionario-banrisul.md#json---javascript-object-notation):** Formato mais leve, muito usado em [API](/dicionario-banrisul.md#api---application-programming-interface)s web modernas.

## Backend e Frontend

No mundo web, os termos **backend** e **frontend** estão diretamente ligados ao modelo Cliente-Servidor:

- **Backend:** atua como **servidor**, processando, armazenando e fornecendo dados solicitados pelo frontend. Implementa a lógica de negócio e responde às requisições, garantindo informações corretas e estruturadas. Funciona exatamente como o servidor do modelo Cliente-Servidor, seguindo protocolos e entendendo o idioma dos dados.
- **Frontend:** é voltado para o usuário — geralmente um navegador, app móvel ou página web — e **se comporta como cliente**, fazendo requisições para obter dados, enviar informações ou realizar ações. Se comunica com o backend seguindo os mesmos princípios do modelo Cliente-Servidor.

A diferença de termos reflete o foco: O **frontend** prioriza a interface e a interação com o usuário, e o **backend** prioriza o processamento e fornecimento de dados. Em essência, a lógica de comunicação, regras de interação (protocolos de comunicação) e idioma (formatos de troca de dados) permanecem os mesmos, apenas adaptados ao contexto da web.

<!-- Ajuste de contexto MM5 (Todo o laboratório até o fim) -->
## Laboratório

Neste laboratório, importaremos o _boilerplate_ de **solução Cliente-Servidor - v6** fornecido na pasta da aula e converteremos a aplicação console C# — que hoje atua como frontend — em um **servidor de arquivos estáticos**, responsável por prover os artefatos de frontend (arquivos `HTML`, `CSS` e `JavaScript`) ao navegador, seguindo um modelo mais moderno e amplamente consagrado, adotado por ferramentas de mercado como _NGINX_ e _Apache HTTP Server_.
<!-- Boilerplate em [./_assets/01-cliente-servidor-boilerplate-v6/] -->

### Passo 1: Executar aplicação no estado atual

Execute os projetos **Cliente** e **C3_UI** da pasta **Servidor**. Com ambas as aplicações executando você perceberá que haverão dois consoles, um de um servidor HTTP pronto para receber requisições, e outro do cliente que conterá um menu interativo com algumas operações, com plena comunicação com o servidor via requisições HTTP `JSON`. Teste algumas dessas operações do cliente para verificar essa comunicação com o servidor e os comportamentos gerais das aplicações.

Analisando a anatomia do projeto **Cliente** você perceberá a existência de pastas `Telas` e `DTOs`, que são utilizadas para estruturar a "interface interativa" da aplicação console e os objetos de transferência de dados para o servidor. Com a transformação do cliente em um servidor de arquivos estáticos, essas pastas e seus conteúdos se tornarão obsoletos, já que toda a interatividade passará a ser feita via navegador através dos artefatos web (arquivos `HTML`, `CSS` e `JavaScript`) que serão providos pelo servidor.

### Passo 2: Implementar o servidor de arquivos estáticos

O "framework" (projeto **PseudoFramework**) já possui uma classe utilitária chamada `ServidorBootstrapClienteHttp`, que facilita a criação de servidores HTTP simples para servir arquivos estáticos. Vamos utilizá-la para transformar o projeto **Cliente** em um servidor de arquivos estáticos.

Para isso, no método `Main(...)` da `Program.cs` do projeto **Cliente**, vamos agir em cima dos trechos comentados com **TODO**:

```csharp
public static void Main(string[] args)
{
    // TODO: Remoção do uso do objeto ClienteHttp — a aplicação console não se comportará mais como um "frontend" por si só
    // var cliente = new ClienteHttp();

    // TODO: Definição do caminho do servidor HTTP de arquivos estáticos
    var caminhoServidorHttp = ConectorHttp.ObterCaminho(3120);
    
    // TODO: Uso do objeto ServidorBootstrapClienteHttp para disponibilizar o servidor de arquivos estáticos para recepção de requisições de arquivos
    var servidor = new ServidorBootstrapClienteHttp(
        caminhoServidorHttp,
        ConectorHttpStaticFiles.ObterCaminho(),
        ConectorHttpStaticFiles.ObterNomeArquivo()
    );
    
    // TODO: Substituição do bloco de exibição (substituir também o header e footer)
    Console.WriteLine("::::::::::::::::::::::::::::::::::::");
    Console.WriteLine($":::: {ServidorBootstrapClienteHttp.IDENTIFICADOR} ::::");
    Console.WriteLine("::::::::::::::::::::::::::::::::::::\n");

    // TODO: Remoção completa do loop de interação com o usuário — essa lógica será responsabilidade do frontend provido pelos arquivos html, css e js
    // while (true)
    // {
    //     ExibirMenuPrincipal();

    //     var opcaoTela = ObterOpcaoTela();

    //     if (opcaoTela == "S")
    //         break;

    //     Console.WriteLine();

    //     ExecutarTela(opcaoTela, cliente);
    // }

    // TODO: Remoção do encerramento do cliente HTTP já que esse objeto não existe mais
    //cliente.Encerrar();

    // TODO: Comunicação de orientação ao usuário de como encerrar o servidor
    Console.WriteLine("Pressione ENTER para encerrar...\n");
    
    // TODO: [Instância de ServidorBootstrapClienteHttp].Iniciar();
    servidor.Iniciar();

    // TODO: Chamada do método que abre o navegador padrão do sistema operacional apontando para o caminho do servidor HTTP de arquivos estáticos
    AbrirBrowser(caminhoServidorHttp);

    // TODO: Aguarde de uma tecla para encerrar o servidor
    Console.ReadKey();

    // TODO: [Instância de ServidorBootstrapClienteHttp].Encerrar();
    servidor.Encerrar();

    Console.ReadKey();
}
```

> Notas:
>
> - Após concluído, os comentários com **TODO** podem ser removidos;
> - Trechos que foram comentados devido à necessidade de remoção agora também podem ser completamente removidos.

O método `AbrirBrowser(...)` utilizado acima também precisa ser implementado na `Program.cs` do projeto **Cliente**. Você pode colocá-lo logo após o método `Main(...)`:

```csharp
public static void Main(string[] args)
{
    // [...]
}

private static void AbrirBrowser(string caminhoServidorHttp)
{
    try
    {
        Process.Start(
            new ProcessStartInfo
            {
                FileName = caminhoServidorHttp,
                UseShellExecute = true
            }
        );
    }
    catch
    {
        Console.WriteLine($"Abra manualmente no endereço: {caminhoServidorHttp}");
    }
}
```

> Nota: Vamos manter temporariamente os demais métodos da `Program.cs` (`ObterOpcaoTela(...)` e `ExecutarTela(...)`) — eles estão obsoletos, mas serão úteis na hora de construir a página `HTML`. Em determinado momento, quando adequado, vamos removê-los assim como também vamos remover as pastas `Telas` e `DTOs` e seus respectivos conteúdos.

### Passo 3: Criar a pasta `wwwroot` e configurar para ser copiada nas compilações

Na raíz do projeto **Cliente**, vamos adicionar a pasta `wwwroot` criando-a ou pelo próprio _Visual Studio_ ou pelo _Windows Explorer_. O resultado da estrutura do projeto **Cliente** deve ficar assim:

```makefile
ClienteServidor\                      # Pasta da solução
|
├── Cliente\                          # Pasta do projeto Cliente 
|   ├── [...]                         # Outras pastas e arquivos da estrutura omitidos por brevidade
|   |
|   ├── wwwroot\                      # Pasta base de provimento do frontend (a partir dessa pasta o servidor de arquivos estáticos procurará os arquivos solicitados nas requisições)
|   |
|   └── [...]                         # Outras pastas e arquivos da estrutura omitidos por brevidade
|
├── PseudoFramework\                  # Pasta do projeto PseudoFramework (estrutura interna omitida por brevidade)
|
├── Servidor\                         # Pasta interna de solução para organizar grupo dos projetos do servidor (estrutura interna omitida por brevidade)
|
└── ClienteServidor.sln               # Arquivo .NET da solução
```

Porém, da forma como o projeto está neste momento, a pasta `wwwroot` não está sendo enviada para o _output_ de compilação quando o servidor é compilado, o que significa que se o servidor for executado, no endereço de destino onde ele é compilado, ele vai tentar procurar uma pasta `wwwroot` e não vai encontrar.

Para corrigir essa inconsistência, precisamos configurar o projeto **Cliente** para também copiar a pasta `wwwroot` e todo o seu conteúdo interno para a saída da compilação, assim como é feito para todos os demais artefatos do projeto.

Para isso, vamos precisar alterar diretamente o arquivo `.csproj` do  projeto **Cliente**:

**Parte 1:** No _Visual Studio_, vamos "descarregar" temporariamente o projeto **Cliente** clicando com o botão direito em cima dele, e selecionando a opção **Unload Project (Descarregar Projeto)**. O projeto será fechado e ficará sinalizado como **Unavailable (Indisponível)**.

**Parte 2:** No _Visual Studio_, vamos agora clicar com o botão direito em cima do do projeto **Cliente** descarregado, e selecionar a opção **Edit Cliente.csproj (Editar Cliente.csproj)**. O arquivo `.csproj` então abrirá no editor. No trecho comentado com um **TODO** vamos adicionar a seguinte seção:

```xml
<!-- [...] -->
<Project ToolsVersion="15.0" xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
  <!-- [...] -->
  
  <!-- TODO: Configuração para incluir a pasta wwwroot junto na saída quando compilar -->
  <ItemGroup>
    <Content Include="wwwroot\**\*">
      <CopyToOutputDirectory>PreserveNewest</CopyToOutputDirectory>
    </Content>
  </ItemGroup>

  <!-- [...] -->
</Project>
```

> Nota: Após concluído, o comentário com **TODO** pode ser removido.

Salve a alteração e feche o arquivo.

**Parte 3:** No _Visual Studio_, vamos "carregar" novamente o projeto **Cliente** clicando com o botão direito em cima dele, e selecionando a opção **Reload Project (Recarregar Projeto)**. O projeto então voltará ao seu estado inicial, com os arquivos internos disponíveis e totalmente funcional.

Agora sim, todos os arquivos contidos em `wwwroot` passarão a ser copiados automaticamente para a saída da compilação.

> Importante: Todos os arquivos que forem criados dentro da pasta `wwwroot` devem ser criados **fora do _Visual Studio_** (ou pelo próprio _Windows Explorer_, ou por outros editores como o _VSCode_). Primeiro porque o _Visual Studio_ não tem um bom suporte para manutenção de código-fonte de arquivos web frontend, e segundo porque o _Visual Studio_ irá bagunçar nossa configuração de compilação do `wwwroot` se adicionarmos arquivos por dentro dele. A recomendação para aplicações frontend é sempre a manutenção através do _VSCode_ — logo, é um bom momento para abrir o projeto dentro dele a partir do contexto da `wwwroot`.

### Passo 4: Adicionar o arquivo `HTML` base

Na raíz da pasta `wwwroot` vamos adicionar o nosso primeiro artefato web — o arquivo `index.html` (lembrando: não crie através do _Visual Studio_). O resultado da estrutura após a criação do arquivo deve ser semelhante a esse:

```makefile
ClienteServidor\                      # Pasta da solução
|
├── Cliente\                          # Pasta do projeto Cliente 
|   ├── [...]                         # Outras pastas e arquivos da estrutura omitidos por brevidade
|   |
|   ├── wwwroot\                      # Pasta base de provimento do frontend (a partir dessa pasta o servidor de arquivos estáticos procurará os arquivos solicitados nas requisições)
|   |   └── index.html                # Arquivo base inicial do frontend (inicialização da aplicação frontend a partir dele)
|   |
|   └── [...]                         # Outras pastas e arquivos da estrutura omitidos por brevidade
|
├── PseudoFramework\                  # Pasta do projeto PseudoFramework (estrutura interna omitida por brevidade)
|
├── Servidor\                         # Pasta interna de solução para organizar grupo dos projetos do servidor (estrutura interna omitida por brevidade)
|
└── ClienteServidor.sln               # Arquivo .NET da solução
```

O arquivo `index.html` por enquanto terá o seguinte conteúdo:

```html
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="utf-8">

    <title>Cliente</title>
</head>
<body>
    <h1>Servidor de arquivos estáticos ativo</h1>
    
    <p>
        Se você está vendo esta página, o
        <strong>ServidorBootstrapClienteHttp</strong>
        está funcionando corretamente.
    </p>
</body>
</html>
```

Execute o projeto **Cliente** e verifique se o navegador carrega corretamente a tela do `index.html`:

![Tela inicial index.html](./_assets/02-lab01-tela-inicial-index-html.png)

## [Exercícios](02-exercicios.md)
