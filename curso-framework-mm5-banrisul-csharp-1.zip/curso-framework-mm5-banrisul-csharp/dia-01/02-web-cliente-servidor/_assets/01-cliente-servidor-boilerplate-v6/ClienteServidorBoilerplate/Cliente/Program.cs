using Cliente.Telas;
using PseudoFramework.ClienteUtils;
using System;

namespace Cliente
{
    public class Program
    {
        public static void Main(string[] args)
        {
            // TODO: Remoção do uso do objeto ClienteHttp — a aplicação console não se comportará mais como um "frontend" por si só
            var cliente = new ClienteHttp();

            // TODO: Definição do caminho do servidor HTTP de arquivos estáticos
            
            // TODO: Uso do objeto ServidorBootstrapClienteHttp para disponibilizar o servidor de arquivos estáticos para recepção de requisições de arquivos
            
            // TODO: Substituição do bloco de exibição (substituir também o header e footer)
            Console.WriteLine("::::::::::::::::::");
            Console.WriteLine($":::: {ClienteHttp.IDENTIFICADOR} :::::");
            Console.WriteLine("::::::::::::::::::\n");

            // TODO: Remoção completa do loop de interação com o usuário — essa lógica será responsabilidade do frontend provido pelos arquivos html, css e js
            while (true)
            {
                ExibirMenuPrincipal();

                var opcaoTela = ObterOpcaoTela();

                if (opcaoTela == "S")
                    break;

                Console.WriteLine();

                ExecutarTela(opcaoTela, cliente);
            }

            // TODO: Remoção do encerramento do cliente HTTP já que esse objeto não existe mais
            cliente.Encerrar();

            // TODO: Comunicação de orientação ao usuário de como encerrar o servidor
            
            // TODO: [Instância de ServidorBootstrapClienteHttp].Iniciar();
            
            // TODO: Chamada do método que abre o navegador padrão do sistema operacional apontando para o caminho do servidor HTTP de arquivos estáticos
            
            // TODO: Aguarde de uma tecla para encerrar o servidor

            // TODO: [Instância de ServidorBootstrapClienteHttp].Encerrar();

            Console.ReadKey();
        }

        private static void ExibirMenuPrincipal()
        {
            Console.WriteLine("1 - Exemplos");
            Console.WriteLine("2 - Idiomas");
            Console.WriteLine("3 - Categorias");
            Console.WriteLine("S - Sair");
        }

        private static string ObterOpcaoTela()
        {
            Console.Write("Selecione a Tela: ");

            return Console.ReadLine().Trim().ToUpper();
        }

        private static void ExecutarTela(string opcaoTela, ClienteHttp cliente)
        {
            Tela tela;

            switch (opcaoTela)
            {
                case "1":
                    {
                        tela = new TelaExemplos(cliente);
                        break;
                    }
                case "2":
                    {
                        tela = new TelaIdiomas(cliente);
                        break;
                    }
                case "3":
                    {
                        tela = new TelaCategorias(cliente);
                        break;
                    }
                default:
                    {
                        Console.WriteLine("Tela não existe.");
                        Console.WriteLine();

                        return;
                    }
            }

            while (true)
            {
                tela.ExibirOpcoes();

                var opcao = tela.ObterOpcao();

                Console.WriteLine();

                if (opcao == "S")
                    break;

                tela.ExecutarOpcao(opcao);
            }
        }
    }
}
