document.addEventListener('DOMContentLoaded', inicializar);

function inicializar() {
    mapearAcaoBotoes();
}

function mapearAcaoBotoes() {
    document
        .getElementById('btn-exemplos')
        .addEventListener('click', montarTelaExemplos);
    
    document
        .getElementById('btn-idiomas')
        .addEventListener('click', montarTelaIdiomas);
    
    document
        .getElementById('btn-categorias')
        .addEventListener('click', montarTelaCategorias);
}

function montarTelaExemplos() {
    document.getElementById('conteudo').innerHTML = '<h2>Tela de Exemplos</h2>';
}

function montarTelaIdiomas() {
    document.getElementById('conteudo').innerHTML = '<h2>Tela de Idiomas</h2>';
}

function montarTelaCategorias() {
    document.getElementById('conteudo').innerHTML = '<h2>Tela de Categorias</h2>';
}
