# Exercícios de Web: Modelo Cliente-Servidor

## 1. Criando a tela inicial do frontend web

Neste exercício, você irá iniciar a construção do frontend do projeto **Cliente**, utilizando apenas **HTML**, **JavaScript**, **JQuery** (se entender necessário) e **CSS**.

Como já sabemos pois adaptamos no laboratório anterior, agora a aplicação do projeto **Cliente** não tem o frontend mais rodando dentro da aplicação console. Agora na verdade a aplicação console se tornou um servidor de arquivos estáticos, que está nos provendo os artefatos de frontend web.

Vamos continuar essa construção a partir do `index.html` (utilize o _boilerplate_ de projeto **Cliente** fornecido na pasta da aula se necessário):
<!-- Boilerplate em [./_assets/03-exercicio1-boilerplate-cliente/] -->

### Estrutura

O primeiro passo a ser tomado é a criação do **menu principal**, que vai permitir ao usuário "navegar" entre as funcionalidades da aplicação.

A aplicação em geral possui 3 áreas de funcionalidade:

- **Exemplos**;
- **Idiomas**;
- **Categorias**.

Cada uma delas corresponderá a uma "tela" da aplicação.

Utilize o arquivo `index.html` dentro da pasta `wwwroot` para criar:

- Um elemento que represente o **menu principal** da aplicação — a forma do menu é de livre escolha — o importante é que cada item do menu seja um elemento clicável (por exemplo: `<button>`, `<a>` ou `<li>`);
- Um elemento que represente a **área de conteúdo**, onde as telas serão exibidas.

> Dica: use ao menos uma `<div>` para o menu e outra `<div>` para a área de conteúdo.

### Comportamento

- Crie uma pasta `scripts` na `wwwroot`:

```makefile
ClienteServidor\                      # Pasta da solução
|
├── Cliente\                          # Pasta do projeto Cliente 
|   ├── [...]                         # Outras pastas e arquivos da estrutura omitidos por brevidade
|   |
|   ├── wwwroot\                      # Pasta base de provimento do frontend (a partir dessa pasta o servidor de arquivos estáticos procurará os arquivos solicitados nas requisições)
|   |   ├── scripts\                  # Pasta de arquivos JavaScript e JQuery do frontend
|   |   └── index.html                # Arquivo base inicial do frontend (inicialização da aplicação frontend a partir dele)
|   |
|   └── [...]                         # Outras pastas e arquivos da estrutura omitidos por brevidade
|
├── PseudoFramework\                  # Pasta do projeto PseudoFramework (estrutura interna omitida por brevidade)
|
├── Servidor\                         # Pasta interna de solução para organizar grupo dos projetos do servidor (estrutura interna omitida por brevidade)
|
└── ClienteServidor.sln               # Arquivo .NET da solução
```

E nela utilizando **JavaScript** e **JQuery** (com quantos arquivos entender necessário), implemente o seguinte comportamento:

Quando o usuário clicar em um item do menu, a área de conteúdo deve ser **recarregada** com um texto respectivo ao menu selecionado:

- Se menu **Exemplos**: "Tela de Exemplos";
- Se menu **Categorias**: "Tela de Categorias";
- Se menu **Idiomas**: "Tela de Idiomas".

> Dicas:
>
> - Use seletores, evento `click` e manipulação de DOM em geral;
> - Crie ao menos uma função para "montar a tela" de cada uma das funcionalidades.

### Estilização

- Crie uma pasta `styles` na `wwwroot`:

```makefile
ClienteServidor\                      # Pasta da solução
|
├── Cliente\                          # Pasta do projeto Cliente 
|   ├── [...]                         # Outras pastas e arquivos da estrutura omitidos por brevidade
|   |
|   ├── wwwroot\                      # Pasta base de provimento do frontend (a partir dessa pasta o servidor de arquivos estáticos procurará os arquivos solicitados nas requisições)
|   |   ├── scripts\                  # Pasta de arquivos JavaScript e JQuery do frontend
|   |   ├── styles\                   # Pasta de arquivos CSS do frontend
|   |   └── index.html                # Arquivo base inicial do frontend (inicialização da aplicação frontend a partir dele)
|   |
|   └── [...]                         # Outras pastas e arquivos da estrutura omitidos por brevidade
|
├── PseudoFramework\                  # Pasta do projeto PseudoFramework (estrutura interna omitida por brevidade)
|
├── Servidor\                         # Pasta interna de solução para organizar grupo dos projetos do servidor (estrutura interna omitida por brevidade)
|
└── ClienteServidor.sln               # Arquivo .NET da solução
```

E nela utilizando **CSS** (com quantos arquivos entender necessário), implemente uma estilização simples para o menu e para a área de conteúdos.

Evite recursos sofisticados, trabalhe apenas com propriedades básicas de CSS, como cores, margens, espaçamento, alinhamento e posicionamento.

Ao final deste exercício, quando a aplicação for executada, deverá ser possível:

- Visualizar o menu com as opções **Exemplos**, **Idiomas** e **Categorias**;
- Clicando em alguma das opções de menu, ver a área de conteúdo carregando dinamicamente a respectiva "tela", **sem recarregamento completo da página**.
