<!-- 
    Este conteúdo replica o mesmo conteúdo contido no "Curso Framework MM4 Banrisul" (https://github.com/dbserver/curso-framework-mm4-banrisul-csharp/blob/f515a778233847d0baf546407396833d004ab63b/dia-01/01-checkup-ambiente/02-tutoriais-sob-demanda/05-solicitacao-acesso-tabelas-consulta-objetos/01-conteudo.md).

    - Ao iniciar este "Curso Framework MM5 Banrisul", copie novamente o conteúdo referido acima para este arquivo e verifique as mudanças através de um diff simples, de forma a garantir que todos os elementos sejam atualizados corretamente.

    DICA: Caso queira facilitar o processo, você pode copiar as 5 pastas inteiras de tutoriais sob demanda do repositório "Curso Framework MM4 Banrisul" para cá ("Curso Framework MM5 Banrisul"), já que os primeiros 5 tutoriais são os tutoriais que são compartilhados entre os dois cursos e devem ser sempre idênticos.

    ATENÇÃO: Jamais apague esse comentário.
-->

# Solicitação de permissão de acesso a tabelas no BOP Web
