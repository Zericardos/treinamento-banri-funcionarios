# Desabilitação da política de HSTS para o domínio do Banrisul

> Atenção: Tire vantagem da desabilitação da política de HSTS exclusivamente quando acessando ambientes operacionais que não possuem certificados SSL válidos, como ambientes locais ou de desenvolvimento. **Mesmo com o domínio do Banrisul desabilitado para HSTS, em ambientes de homologação, testes ou produção, SEMPRE priorize o acesso através de `https://[...]`**.

A política de [HSTS](../../../../dicionario-banrisul.md#hsts---http-strict-transport-security) é uma política de segurança que força os navegadores a acessarem determinados domínios exclusivamente através do protocolo seguro `https://[...]`. O Google Chrome mantém uma lista interna de domínios que utilizam essa política, e o domínio `banrisul.com.br` está incluído nessa lista em navegadores das estações do Banrisul. Isso significa que, mesmo que você tente acessar um ambiente operacional através de `http://[...]`, o navegador automaticamente vai redirecionar a sua requisição para `https://[...]`.

Para desabilitar o domínio do Banrisul da política de HSTS no Google Chrome, siga os passos abaixo:

- No Google Chrome, acesse a URL: <chrome://net-internals/#hsts>;
- Na seção **Delete domain security policies**, insira o domínio `banrisul.com.br` no campo **Domain** e clique no botão **Delete** para remover o domínio da lista de políticas de HSTS:
  ![Ambiente local](./_assets/01-remocao-dominio-banrisul-hsts.png)
- Na seção **Query HSTS/PKP domain**, insira o domínio `banrisul.com.br` no campo **Domain** e clique no botão **Query** para verificar se o domínio foi removido com sucesso — se o domínio tiver sido realmente removido, logo abaixo do campo **Domain** será exibida a mensagem `Not found`.
  ![Ambiente local](./_assets/02-checagem-remocao-dominio-banrisul-hsts.png)

Após seguir esses passos, o Google Chrome não aplicará mais a política de HSTS para o domínio do Banrisul, permitindo que você acesse ambientes que não possuem certificados SSL válidos através do protocolo `http://[...]`.

> Nota: Essa configuração é específica para o navegador Google Chrome. Outros navegadores podem ter procedimentos diferentes para desabilitar a política de HSTS.
