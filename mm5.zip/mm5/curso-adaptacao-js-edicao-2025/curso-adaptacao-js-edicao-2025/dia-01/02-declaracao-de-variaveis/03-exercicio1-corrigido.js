const CAPACIDADE_MAXIMA = 1000;

let ingressosVendidos = 75;
let ingressosRestantes = 925

console.log("Ingressos vendidos: ", ingressosVendidos, " de ", CAPACIDADE_MAXIMA);
console.log("Ingressos restantes: ", ingressosRestantes);
