# Exercício: Declaração de variáveis

- Declarar uma constante que representa o valor de capacidade máxima que uma casa de shows suporta;
- Declarar variáveis com o número de ingressos vendidos e o número de ingressos restantes — atribuindo a eles os seus respectivos valores;
- Imprimir um relatório semelhante a este no console:

    ```
    Ingressos vendidos: 75 de 1000
    Ingressos restantes: 925
    ```

> Dica: Para imprimir, use console.log("...").
