let altura = 120;
let acompanhada = true; 

let podeEntrar = altura >= 120 || acompanhada;
console.log("Pode entrar no brinquedo? " + podeEntrar);
