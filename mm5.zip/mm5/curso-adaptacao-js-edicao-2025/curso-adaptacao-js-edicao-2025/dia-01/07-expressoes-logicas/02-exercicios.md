# Exercícios: Expressões lógicas

## 1. Brinquedo no parque
- Defina duas variáveis: altura da criança e se está acompanhada de um adulto;
- Verifique se a criança pode entrar no brinquedo, de acordo com a seguinte regra: pode entrar sozinha se tiver altura de pelo menos 1 metro e 20cm, ou, senão, só se estiver acompanhada de um adulto;
- Exiba o resultado no console.

## 2. Número positivo e par
- Armazene um número em uma variável;
- Verifique se o número fornecido é positivo e par;
- Exiba o resultado no console.

## 3. Ano bissexto
- Armazene em uma variável numérica um ano;
- Verifique se o ano é bissexto;
- Exiba o resultado no console.

> Dica: Regra para um ano ser considerado bissexto: É divisível por 4 e não divisível por 100, ou é divisível por 400.