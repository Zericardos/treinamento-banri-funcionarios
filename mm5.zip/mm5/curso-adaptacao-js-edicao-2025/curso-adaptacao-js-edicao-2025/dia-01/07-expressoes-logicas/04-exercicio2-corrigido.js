let numero = 8; 

const positivo = numero > 0;
const par = numero % 2 === 0;
const positivoEPar = positivo && par;

console.log("Resultado (Positivo E Par): " + positivoEPar);