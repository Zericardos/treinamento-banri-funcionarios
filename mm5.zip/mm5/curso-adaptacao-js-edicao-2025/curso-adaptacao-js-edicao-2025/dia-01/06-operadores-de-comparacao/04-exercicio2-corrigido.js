let numString = "10";
let numNumber = 10;  

console.log(numString + " == " + numNumber + " → " + (numString == numNumber));
console.log(numString + " === " + numNumber + " → " + (numString === numNumber));
console.log(numString + " != " + numNumber + " → " + (numString != numNumber));
console.log(numString + " !== " + numNumber + " → " + (numString !== numNumber));
