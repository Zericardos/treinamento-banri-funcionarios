const senha = "TRE1N4MENT0_MM";

let senhaUsuario = "tre1n4ment0_mm";
console.log("Senha válida? ", (senhaUsuario === senha));