var listaDeTarefas = [
    "Comprar ingredientes do jantar",
    "Responder e-mails pendentes"
]
console.log(listaDeTarefas);
const tarefa3 = "Pagar a conta de luz";
listaDeTarefas.push(tarefa3);
console.log(listaDeTarefas);
var tareaRemovida = listaDeTarefas.pop();
console.log(listaDeTarefas);
console.log(`Tamanho da listaDeTarefas ${listaDeTarefas.length}`);
console.log(tareaRemovida);
console.log(`Primeira tarefa ${listaDeTarefas[0]}`);
console.log(`Quantidade de tarefas: ${listaDeTarefas.length}`);

// 2
const produto = {
    nome: "sorvete",
    preco: 5.99,
    emEstoque: true
};
console.log(produto);
console.log(`Produto completo ${produto}`);
console.log(`Nome do produto ${produto.nome}`);
console.log(`Nome do produto ${produto['preco']}`);

produto.preco = 3150.00;
produto.id = 101;

for (const [key, value] of Object.entries(produto)) {
    console.log(`${key} tem valor: ${value}` );
}