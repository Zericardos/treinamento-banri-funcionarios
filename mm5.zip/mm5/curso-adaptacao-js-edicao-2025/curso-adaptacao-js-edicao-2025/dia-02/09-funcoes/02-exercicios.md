# Exercícios: Funções

## 1. Sorveteria
O objetivo é construir um sistema simples de pedidos de sorvete, com base nas variáveis definidas, aplicando cálculos de total, descontos e promoções.
- Importe o boilerplate de código fornecido na pasta da aula
- Refatore o código "quebrando-o" em mais partes, fazendo uso de N funções que entender necessárias para que a solução fique mais organizada e elegante.

A execução deve continuar funcional e com resultados exatamente iguais aos que estavam antes da refatoração.