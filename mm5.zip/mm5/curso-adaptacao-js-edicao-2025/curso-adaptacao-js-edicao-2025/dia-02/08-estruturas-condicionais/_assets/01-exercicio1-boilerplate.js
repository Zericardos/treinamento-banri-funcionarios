/* Constantes de animais */
const ANIMAL_COMPANHEIRO = "Companheira(o)";
const ANIMAL_ASTUTO = "Astuta(o)";
const ANIMAL_GUARDIAO = "Guardiã(o)";
const ANIMAL_FEROZ = "Feroz";
const ANIMAL_DESCONHECIDO = "Desconhecida(o)";
    
/* Constantes de cores */
const COR_FLAMEJANTE = "Flamejante";
const COR_SABEDORIA = "Sábia(o)";
const COR_SILVESTRE = "Silvestre";
const COR_RADIANTE = "Radiante";
const COR_MISTERIOSA = "Misteriosa(o)";

/* Constantes de aventuras */
const AVENTURA_EXPLORAR = "Pront(a)o para aventuras!";
const AVENTURA_DESCANSAR = "Tranquila(o) e serena(o)!";
const AVENTURA_CRIAR = "Criativa(o) e engenhosa(o)!";
const AVENTURA_COMPETIR = "Audaciosa(o) e competitiva(o)!";
const AVENTURA_DESTEMIDA = "Destemida(o) em qualquer jornada!";

// O seu código para descobrir o avatar deve vir abaixo deste bloco.
