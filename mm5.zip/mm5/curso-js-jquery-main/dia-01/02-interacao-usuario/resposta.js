var resposta1 = prompt("Digite o seu nome");
var paragrafo = document.getElementById("mensagem-boas-vindas");
if (resposta1){
    paragrafo.textContent = (`"Seja bem-vindo(a), ${resposta1}!"`)
}
else {
    paragrafo.textContent =  (`"Seja bem-vindo(a), Visitante!"`)
}