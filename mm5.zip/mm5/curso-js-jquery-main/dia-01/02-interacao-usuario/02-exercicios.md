# Exercícios: interação com o usuário

## 1. Prompt - Boas vindas
- Utilize o código HTML base disponível no arquivo [./_assets/01-exercicio1-boilerplate.html](./_assets/01-exercicio1-boilerplate.html).
- Use a função nativa prompt() do JavaScript para solicitar que o usuário digite seu nome e armazene o resultado em uma variável.
- Defina o conteúdo de texto do parágrafo que tem o `id="mensagem-boas-vindas"` para a seguinte frase, substituindo [NOME] pelo valor capturado: "Seja bem-vindo(a), [NOME]!"
- Caso nenhum nome seja informado, substitua o nome por "Visitante".

## 2. Manipulando o Título da Página e Adicionando Elementos ao DOM
- Utilize o código HTML base disponível no arquivo [./_assets/02-exercicio2-boilerplate.html](./_assets/02-exercicio2-boilerplate.html).
- Ao clicar no botão, o valor digitado no campo de texto deve se tornar o **novo título da página**.
- Além disso, crie dinamicamente um parágrafo abaixo do botão com a mensagem: *"Título atualizado para: [novo título]"*.
- Caso nenhum texto seja informado, informe com um `alert()` que é necessário digitar um título válido.

## 3. Modificando Imagens Dinamicamente
- Utilize o código HTML base disponível no arquivo [./_assets/03-exercicio3-boilerplate.html](./_assets/03-exercicio3-boilerplate.html).
- Quando o botão "Trocar imagem" for clicado, a primeira imagem deve trocar seu `src` para o mesmo da segunda imagem.