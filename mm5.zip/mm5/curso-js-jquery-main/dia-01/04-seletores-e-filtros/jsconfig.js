{
    "typeAcquisition": {
        "include": [
            "jquery"
        ]
    }
}