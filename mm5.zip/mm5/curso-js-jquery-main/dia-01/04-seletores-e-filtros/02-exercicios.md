# Exercícios: Seletores e Filtros com jQuery

- Utilize o código HTML base disponível no arquivo [./_assets/01-exercicio1-boilerplate.html](./_assets/01-exercicio1-boilerplate.html).
- Adicione a classe completo (usando o método `.addClass()`) ao primeiro item da lista.
- Mude a cor de fundo (usando `.css()`) do último item para #ffdddd (vermelho claro).
- Aplique o método `.hide()` para fazer o segundo item desaparecer.