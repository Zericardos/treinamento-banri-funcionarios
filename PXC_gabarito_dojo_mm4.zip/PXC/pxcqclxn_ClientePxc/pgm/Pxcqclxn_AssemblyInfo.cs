﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Pxcqclxn")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcqclxn")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2026")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("0e5d6473-d504-4dde-aed9-7f3cf619bbca")]