﻿using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcqclxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Relatorios;
using Bergs.Pwx.Pwxoiexn.RN;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using System;
using System.Collections.Generic;
using System.Text;

namespace Bergs.Pxc.Pxcsclxn
{ 
    /// <summary>Classe que possui as regras de negócio para o acesso da tabela CLIENTE_PXC da base de dados PXC.</summary>
    public class ClientePxc : AplicacaoRegraNegocio
    {
        private List<int> AgenciasValidas = new List<int> { 515, 590, 4022, 9008 };
        private List<string> TipoPessoaValidas = new List<string> { "F", "J" };

        private bool AgenciaEhValida(int agencia)
        {
            return AgenciasValidas.Contains(agencia);
        }

        private bool TipoPessoaEhValida(string tipoPessoa)
        {
            return TipoPessoaValidas.Contains(tipoPessoa);
        }

        /// <summary>Conta quantidade de registros da tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<long> Contar(TOClientePxc toClientePxc)
        {
            try
            {
                if (!toClientePxc.Agencia.FoiSetado || !this.AgenciaEhValida(toClientePxc.Agencia))
                {
                    return this.Infra.RetornarFalha<long>(new ClienteMensagem(TipoMensagem.AgenciaInvalida));
                }

                Pxcqclxn.ClientePxc bdClientePxc;
                Retorno<long> contagemClientePxc;
            
                bdClientePxc = this.Infra.InstanciarBD<Pxcqclxn.ClientePxc>();

                contagemClientePxc = bdClientePxc.Contar(toClientePxc);
                if (!contagemClientePxc.OK)
                {
                    return contagemClientePxc;
                }
                
                return this.Infra.RetornarSucesso(contagemClientePxc.Dados, new OperacaoRealizadaMensagem());
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<long>(ex);
            }
        }
        
        /// <summary>Inclui registro na tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<int> Incluir(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqclxn.ClientePxc bdClientePxc;
                Retorno<int> inclusaoClientePxc;
                
                //Valida que os campos obrigatórios foram informados
                if (!toClientePxc.Agencia.FoiSetado || !this.AgenciaEhValida(toClientePxc.Agencia))
                {
                    return this.Infra.RetornarFalha<int>(new ClienteMensagem(TipoMensagem.AgenciaInvalida));
                }
                if (!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new ClienteMensagem(TipoMensagem.CodigoNaoInformado));
                }
                if (!toClientePxc.NomeCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new ClienteMensagem(TipoMensagem.NomeInvalido));
                }
                if (!toClientePxc.TipoPessoa.FoiSetado || !this.TipoPessoaEhValida(toClientePxc.TipoPessoa))
                {
                    return this.Infra.RetornarFalha<int>(new ClienteMensagem(TipoMensagem.TipoPessoaInvalido));
                }

                if (!ValidarTO(toClientePxc, out var listaRetornoValidacao))
                {
                    return Infra.RetornarFalha<int>(new ObjetoInvalidoMensagem(listaRetornoValidacao));
                }
                    
                toClientePxc.CodOperador = this.Infra.Usuario.Matricula;
                toClientePxc.VlrCapitalSocial = 0;

                bdClientePxc = this.Infra.InstanciarBD<Pxcqclxn.ClientePxc>();
                
                var toObter = new TOClientePxc() 
                { 
                    CodCliente = toClientePxc.CodCliente, 
                    TipoPessoa = toClientePxc.TipoPessoa 
                };
                var retornoObter = Obter(toObter);

                // se eu consegui obter então o registro já existe no banco
                if (retornoObter.OK)
                {
                    return this.Infra.RetornarFalha<int>(new ClienteMensagem(TipoMensagem.RegistroDuplicado));
                }

                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    inclusaoClientePxc = bdClientePxc.Incluir(toClientePxc);

                    if (!inclusaoClientePxc.OK && (inclusaoClientePxc.Mensagem is RegistroDuplicadoMensagem))
                    {
                        return this.Infra.RetornarFalha<int>(new ClienteMensagem(TipoMensagem.RegistroDuplicado));
                    }

                    if (!inclusaoClientePxc.OK)
                    {
                        return inclusaoClientePxc;
                    }
                    
                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(inclusaoClientePxc.Dados, new OperacaoRealizadaMensagem("Inclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<int>(ex);
            }
        }
    
        /// <summary>Lista registros da tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <param name="toPaginacao">Classe da infra-estrutura contendo as informações de paginação.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<List<TOClientePxc>> Listar(TOClientePxc toClientePxc, TOPaginacao toPaginacao)
        {
            try
            {
                if (!toClientePxc.NomeCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<List<TOClientePxc>>(new ClienteMensagem(TipoMensagem.NomeInvalido));
                }

                if (!ValidarTO(toClientePxc, out var listaRetornoValidacao))
                    return Infra.RetornarFalha<List<TOClientePxc>>(new ObjetoInvalidoMensagem(listaRetornoValidacao));

                Pxcqclxn.ClientePxc bdClientePxc;
                Retorno<List<TOClientePxc>> listagemClientePxc;
                
                bdClientePxc = this.Infra.InstanciarBD<Pxcqclxn.ClientePxc>();

                listagemClientePxc = bdClientePxc.Listar(toClientePxc, toPaginacao);
                if (!listagemClientePxc.OK)
                {
                    return listagemClientePxc;
                }

                if (listagemClientePxc.Dados.Count == 0)
                {
                    return this.Infra.RetornarFalha<List<TOClientePxc>>(new ClienteMensagem(TipoMensagem.NenhumClienteEncontrado));
                }
                
                return this.Infra.RetornarSucesso(listagemClientePxc.Dados, new OperacaoRealizadaMensagem());
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<List<TOClientePxc>>(ex);
            }
        }
    
        /// <summary>Obtém registro da tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOClientePxc> Obter(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqclxn.ClientePxc bdClientePxc;
                Retorno<TOClientePxc> obtencaoClientePxc;
                
                //Valida que os campos que fazem parte da chave primária foram informados
                if (!toClientePxc.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOClientePxc>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }
                if (!toClientePxc.TipoPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOClientePxc>(new CampoObrigatorioMensagem("TIPO_PESSOA"));
                }

                bdClientePxc = this.Infra.InstanciarBD<Pxcqclxn.ClientePxc>();

                obtencaoClientePxc = bdClientePxc.Obter(toClientePxc);
                if (!obtencaoClientePxc.OK)
                {
                    return obtencaoClientePxc;
                }
                
                return this.Infra.RetornarSucesso(obtencaoClientePxc.Dados, new OperacaoRealizadaMensagem());
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<TOClientePxc>(ex);
            }
        }
        /// <summary>Exclui registro da tabela CLIENTE_PXC.</summary>
        /// <param name="toClientePxc">Transfer Object de entrada referente à tabela CLIENTE_PXC.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<Int32> Excluir(TOClientePxc toClientePxc)
        {
            try
            {
                Pxcqclxn.ClientePxc bdClientePxc = this.Infra.InstanciarBD<Pxcqclxn.ClientePxc>();

                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    Retorno<Int32> exclusaoClientePxc = bdClientePxc.Excluir(toClientePxc);

                    if (!exclusaoClientePxc.OK)
                    {
                        return exclusaoClientePxc;
                    }

                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(exclusaoClientePxc.Dados, new OperacaoRealizadaMensagem("Exclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<Int32>(ex);
            }
        }
    } 
}