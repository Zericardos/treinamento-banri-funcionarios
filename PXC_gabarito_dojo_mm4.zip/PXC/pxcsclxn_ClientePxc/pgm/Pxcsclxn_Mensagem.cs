﻿using Bergs.Pxc.Pxcbtoxn;
using System;

namespace Bergs.Pxc.Pxcsclxn
{
    /// <summary>Mensagens previstas para o componente</summary>
    public enum TipoMensagem
    {
        /// <summary>Falha por agência informada ser inválida</summary>
        AgenciaInvalida,
        /// <summary>Falha por código não informado</summary>
        CodigoNaoInformado,
        /// <summary>Falha por nome inválido</summary>
        NomeInvalido,
        /// <summary>Falha por tipo pessoa informado ser inválido</summary>
        TipoPessoaInvalido,
        /// <summary>Falha por sobrenome informado ser inválido</summary>
        SobrenomeInvalido,
        /// <summary>Falha por não encontrar nenhum cliente</summary>
        NenhumClienteEncontrado,
        /// <summary>Falha por agência não existir</summary>
        AgenciaNaoExisteNoSistema,
        /// <summary>Falha registro duplicado</summary>
        RegistroDuplicado
    }

    /// <summary>Classe de mensagem</summary>
    public class ClienteMensagem : Bergs.Pwx.Pwxoiexn.Mensagens.Mensagem
    {
        /// <summary>
        /// Mensagem
        /// </summary>
        private String mensagem;

        /// <summary>
        /// Tipo de mensagem
        /// </summary>
        private Pxcsclxn.TipoMensagem tipoMensagem;

        /// <summary>
        /// Mensagem para o usuário
        /// </summary>
        public override String ParaUsuario
        {
            get { return this.ParaOperador; }
        }

        /// <summary>
        /// Mensagem para o operador
        /// </summary>
        public override String ParaOperador
        {
            get { return this.mensagem; }
        }

        /// <summary>
        /// Identificador
        /// </summary>
        public override String Identificador
        {
            get { return tipoMensagem.ToString(); }
        }

        /// <summary>
        /// Construtor da classe Mensagem
        /// </summary>
        /// <param name="mensagem">Mensagem</param>
        /// <param name="argumentos">Argumentos</param>
        public ClienteMensagem(Pxcsclxn.TipoMensagem mensagem, params String[] argumentos)
        {
            tipoMensagem = mensagem;

            switch (mensagem)
            {
                case Pxcsclxn.TipoMensagem.AgenciaInvalida:
                    this.mensagem = "Uma agência válida (515, 590, 4022 ou 9008) deve ser informada.";
                    break;
                case Pxcsclxn.TipoMensagem.RegistroDuplicado:
                    this.mensagem = "Já existe na base de dados um cliente com a combinação de código cliente e tipo pessoa informados.";
                    break;
                case Pxcsclxn.TipoMensagem.NomeInvalido:
                    this.mensagem = TOClientePxc.MENSAGEM_NOME_INVALIDO;
                    break;
                case Pxcsclxn.TipoMensagem.AgenciaNaoExisteNoSistema:
                    this.mensagem = "A agência informada não existe no sistema!";
                    break;
                case Pxcsclxn.TipoMensagem.TipoPessoaInvalido:
                    this.mensagem = "Um tipo pessoa válido (\"F\" ou \"J\") deve ser informado.";
                    break;
                case Pxcsclxn.TipoMensagem.NenhumClienteEncontrado:
                    this.mensagem = "Não existem clientes cadastrados com o nome informado.";
                    break;
                default:
                    this.mensagem = "Mensagem não definida.";
                    break;
            }
        }
    }
}
