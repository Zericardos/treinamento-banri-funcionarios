﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using Bergs.Pwx.Pwxoiexn.Validacoes;
using System;
using System.Data;
using System.Xml.Serialization;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela CLIENTE_PXC da base de dados PXC.</summary>
    public class TOClientePxc : TOTabela
  {
        /// <summary>
        /// constante para guardar a mensagem de nome inválido.
        /// </summary>
        public const string MENSAGEM_NOME_INVALIDO = "Um nome alfanumérico válido deve ser informado.";
        /// <summary>Campo COD_CLIENTE da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Chave = true, Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 14, Precisao = 14)]
        public CampoObrigatorio<String> CodCliente { get; set; }
        
        /// <summary>Campo TIPO_PESSOA da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("tipo_pessoa")]
        [CampoTabela("TIPO_PESSOA", Chave = true, Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<String> TipoPessoa { get; set; }
        
        /// <summary>Campo AGENCIA da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("agencia")]
        [CampoTabela("AGENCIA", Obrigatorio = true, TipoParametro = DbType.Int16, Tamanho = 2, Precisao = 2)]
        public CampoObrigatorio<Int16> Agencia { get; set; }
        
        /// <summary>Campo COD_OPERADOR da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<String> CodOperador { get; set; }
        
        /// <summary>Campo DT_ABE_CAD da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("dt_abe_cad")]
        [CampoTabela("DT_ABE_CAD", Obrigatorio = true, TipoParametro = DbType.Date, Tamanho = 4, Precisao = 4)]
        public CampoObrigatorio<DateTime> DtAbeCad { get; set; }
        
        /// <summary>Campo NOME_CLIENTE da tabela CLIENTE_PXC.</summary>
        [Alfanumerico (mensagemErro: MENSAGEM_NOME_INVALIDO)]
        [XmlAttribute("nome_cliente")]
        [CampoTabela("NOME_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 50, Precisao = 50)]
        public CampoObrigatorio<String> NomeCliente { get; set; }
        
        /// <summary>Campo ULT_ATUALIZACAO da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao { get; set; }
        
        /// <summary>Campo DT_CONSTITUICAO da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("dt_constituicao")]
        [CampoTabela("DT_CONSTITUICAO", TipoParametro = DbType.Date, Tamanho = 4, Precisao = 4)]
        public CampoOpcional<DateTime> DtConstituicao { get; set; }
        
        /// <summary>Campo IND_FUNC_BANRISUL da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("ind_func_banrisul")]
        [CampoTabela("IND_FUNC_BANRISUL", TipoParametro = DbType.String, Tamanho = 1, Precisao = 1)]
        public CampoOpcional<String> IndFuncBanrisul { get; set; }
        
        /// <summary>Campo NOME_FANTASIA da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("nome_fantasia")]
        [CampoTabela("NOME_FANTASIA", TipoParametro = DbType.String, Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> NomeFantasia { get; set; }
        
        /// <summary>Campo NOME_MAE da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("nome_mae")]
        [CampoTabela("NOME_MAE", TipoParametro = DbType.String, Tamanho = 30, Precisao = 30)]
        public CampoOpcional<String> NomeMae { get; set; }
        
        /// <summary>Campo ULT_NOSSO_NRO da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("ult_nosso_nro")]
        [CampoTabela("ULT_NOSSO_NRO", TipoParametro = DbType.Int32, Tamanho = 4, Precisao = 4)]
        public CampoOpcional<Int32> UltNossoNro { get; set; }
        
        /// <summary>Campo VLR_CAPITAL_SOCIAL da tabela CLIENTE_PXC.</summary>
        [XmlAttribute("vlr_capital_social")]
        [CampoTabela("VLR_CAPITAL_SOCIAL", TipoParametro = DbType.Decimal, Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoOpcional<Decimal> VlrCapitalSocial { get; set; }

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "COD_CLIENTE":
                        CodCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "TIPO_PESSOA":
                        TipoPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "AGENCIA":
                        Agencia = Convert.ToInt16(campo.Conteudo);
                        break;
                    case "COD_OPERADOR":
                        CodOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "DT_ABE_CAD":
                        DtAbeCad = Convert.ToDateTime(campo.Conteudo);
                        break;
                    case "NOME_CLIENTE":
                        NomeCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        UltAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    case "DT_CONSTITUICAO":
                        DtConstituicao = LerCampoOpcional<DateTime>(campo);
                        break;
                    case "IND_FUNC_BANRISUL":
                        IndFuncBanrisul = LerCampoOpcional<String>(campo);
                        break;
                    case "NOME_FANTASIA":
                        NomeFantasia = LerCampoOpcional<String>(campo);
                        break;
                    case "NOME_MAE":
                        NomeMae = LerCampoOpcional<String>(campo);
                        break;
                    case "ULT_NOSSO_NRO":
                        UltNossoNro = LerCampoOpcional<Int32>(campo);
                        break;
                    case "VLR_CAPITAL_SOCIAL":
                        VlrCapitalSocial = LerCampoOpcional<Decimal>(campo);
                        break;
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}