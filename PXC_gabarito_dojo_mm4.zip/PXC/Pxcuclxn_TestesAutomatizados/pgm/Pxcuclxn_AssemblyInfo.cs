﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Pxcuclxn.Test")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcuclxn.Test")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2026")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("31729c4a-346d-402b-94a4-58f47e4bf262")]