﻿using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcsclxn;
using NUnit.Framework;
using System;

namespace Bergs.Pxc.Pxcuclxn.Tests
{
	
	///  <summary>
	/// Contém os métodos de teste da classe ClientePxc.
	/// </summary>
	[TestFixture(Description="Classe de testes para a classe RN ClientePxc.", Author="T10863")]
	public class ClientePxcTests : AbstractTesteRegraNegocio<ClientePxc>
	{
		///  <summary>
		/// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
		/// </summary>
		protected override void BeforeAll()
		{
		}
		///  <summary>
		/// Executa uma ação ANTES de cada método de teste da classe.
		/// </summary>
		protected override void BeforeEach()
		{
		}
		///  <summary>
		/// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
		/// </summary>
		protected override void AfterAll()
		{
		}
		///  <summary>
		/// Executa uma ação DEPOIS de cada método de teste da classe.
		/// </summary>
		protected override void AfterEach()
		{
		}
		///  <summary>
		/// Método para setar os dados necessários para conexão com o PHA no servidor de build.
		/// </summary>
		/// <returns>TO com dados necessários para conexão no servidor de build.</returns>
		protected override TOPhaServidorBuild SetarDadosServidorBuild()
		{
			return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
		}
		///  <summary></summary>
		[Test(Description="Testa o método Contar com sucesso.", Author="T10863")]
		public void US1_CA01_ContarComSucessoTest()
		{
            short agencia = 515;

            // Crio um registro no banco pra garantir que sempre vai ter pelo menos um cliente com agencia 515.
            TOClientePxc toClienteInclusao = new TOClientePxc();
            toClienteInclusao.TipoPessoa = "F";
            toClienteInclusao.Agencia = agencia;
            toClienteInclusao.NomeCliente = "Gabriel Pereira";
            toClienteInclusao.CodCliente = "9989";
            this.RN.Incluir(toClienteInclusao);

            // Monto o TO com uma agência que tem clientes
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.Agencia = agencia;

            // Executo contagem
            base.TestarContar(toClientePxc);

            // Asserts equivalentes ao base.TestarContar()
            //MMAssert.NotNull(retorno);
            //MMAssert.True(retorno.OK);
            //MMAssert.NotNull(retorno.Dados);
            //MMAssert.NotZero(retorno.Dados);
        }
        ///  <summary></summary>
		[Test(Description = "Testa o método Contar com agência inválida.", Author = "T10863")]
        public void US1_CA02_ContarComAgenciaInvalidaTest()
        {
            // Monto o TO com uma agência inválida
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.Agencia = 10;

            // Executo contagem
            Retorno<long> retorno = this.RN.Contar(toClientePxc);

            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados); // Alternativamente daria pra fazer Assert.True(resposta.Dados == 0);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.AgenciaInvalida);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }
        ///  <summary></summary>
        [Test(Description="Testa o método Incluir com sucesso", Author="T10863")]
		public void US2_CA01_IncluirComSucessoTest()
		{
            string codCliente = "9889";
            string tipoPessoa = "F";

            // Garanto que não vai haver nenhum cliente com o mesmo código e tipo pessoa.
            TOClientePxc toClientePxcExclusao = new TOClientePxc();
            toClientePxcExclusao.CodCliente = codCliente;
            toClientePxcExclusao.TipoPessoa = tipoPessoa;

            this.RN.Excluir(toClientePxcExclusao);

            // Monto TO com dados válidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.TipoPessoa = tipoPessoa;
            toClientePxc.Agencia = 9008;
            toClientePxc.NomeCliente = "Gabriel Pereira";
            toClientePxc.CodCliente = codCliente;

            base.TestarIncluir(toClientePxc);
		}
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem mandar o código do cliente.", Author = "T10863")]
        public void US2_CA02_IncluirSemCodClienteTest()
        {
            // Monto TO com dados inválidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.TipoPessoa = "F";
            toClientePxc.Agencia = 9008;
            toClientePxc.NomeCliente = "Gabriel Pereira";

            // Executo inclusão
            Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);

            // Valido que deu erro na inclusão
            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.CodigoNaoInformado);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem o nome do cliente.", Author = "T10863")]
        public void US2_CA03_IncluirSemNomeClienteTest()
        {
            // Monto TO com dados inválidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.TipoPessoa = "F";
            toClientePxc.Agencia = 9008;
            toClientePxc.CodCliente = "9008";

            // Executo inclusão
            Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);

            // Valido que deu erro na inclusão
            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.NomeInvalido);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir com o nome do cliente inválido.", Author = "T10863")]
        public void US2_CA04_IncluirComNomeClienteInvalidoTest()
        {
            // Monto TO com dados inválidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.TipoPessoa = "F";
            toClientePxc.Agencia = 9008;
            toClientePxc.CodCliente = "9008";
            toClientePxc.NomeCliente = "@@@@@";

            // Executo inclusão
            Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);

            // Valido que deu erro na inclusão
            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = TOClientePxc.MENSAGEM_NOME_INVALIDO;
            MMAssert.True(retorno.Mensagem.ParaUsuario.ToString().Contains(mensagemEsperada));
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem o tipo pessoa do cliente.", Author = "T10863")]
        public void US2_CA05_IncluirSemTipoPessoaTest()
        {
            // Monto TO com dados inválidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.Agencia = 9008;
            toClientePxc.CodCliente = "9008";
            toClientePxc.NomeCliente = "Gabriel Pereira";

            // Executo inclusão
            Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);

            // Valido que deu erro na inclusão
            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.TipoPessoaInvalido);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir com o tipo pessoa do cliente inválido.", Author = "T10863")]
        public void US2_CA06_IncluirComTipoPessoaInvalidaTest()
        {
            // Monto TO com dados inválidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.Agencia = 9008;
            toClientePxc.CodCliente = "9008";
            toClientePxc.TipoPessoa = "X";
            toClientePxc.NomeCliente = "Gabriel Pereira";

            // Executo inclusão
            Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);

            // Valido que deu erro na inclusão
            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.TipoPessoaInvalido);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir sem a agência.", Author = "T10863")]
        public void US2_CA07_IncluirSemAgenciaTest()
        {
            // Monto TO com dados inválidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.CodCliente = "9008";
            toClientePxc.TipoPessoa = "F";
            toClientePxc.NomeCliente = "Gabriel Pereira";

            // Executo inclusão
            Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);

            // Valido que deu erro na inclusão
            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.AgenciaInvalida);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }
        ///  <summary>
        /// Realiza o teste padrão para o método Incluir(TOClientePxc).
        /// </summary>
        [Test(Description = "Testa o método Incluir(TOClientePxc).", Author = "T10863")]
        public void US2_CA08_IncluirComAgenciaInvalidaTest()
        {
            // Monto TO com dados válidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.CodCliente = "9008";
            toClientePxc.Agencia = 1;
            toClientePxc.TipoPessoa = "F";
            toClientePxc.NomeCliente = "Gabriel Pereira";

            // Executo inclusão
            Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);

            // Valido que deu erro na inclusão
            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.AgenciaInvalida);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Incluir com registro duplicado.", Author = "T10863")]
        public void US2_CA09_IncluirComRegistroDuplicadoTest()
        {
            // Aplico o mock
            var mock = new MockClientePxc(this.Infra);
            mock.ObterRegistroDuplicado();

            // Monto TO com dados válidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.CodCliente = "9008";
            toClientePxc.Agencia = 515;
            toClientePxc.TipoPessoa = "F";
            toClientePxc.NomeCliente = "Gabriel Pereira";

            // Executo inclusão
            Retorno<Int32> retorno = this.RN.Incluir(toClientePxc);

            // Valido que deu erro na inclusão
            Assert.False(retorno.OK);
            Assert.AreEqual(0, retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.RegistroDuplicado);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Listar com sucesso.", Author = "T10863")]
        public void US3_CA01_ListarComSucessoTest()
        {
            // Monto TO com dados válidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.CodCliente = "9008";
            toClientePxc.Agencia = 515;
            toClientePxc.TipoPessoa = "F";
            toClientePxc.NomeCliente = "Gabriel Pereira";

            // Executo inclusão para garantir que vai ter pelo menos um registro na listagem
            this.RN.Incluir(toClientePxc);

            // Monto TO com dados válidos
            TOClientePxc to = new TOClientePxc();
            to.NomeCliente = "Gabriel Pereira";

            // Executo listagem
            base.TestarListar(to, null);
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Listar sem mandar o nome.", Author = "T10863")]
        public void US3_CA02_ListarSemNomeTest()
        {
            // Monto TO com dados inválidos
            TOClientePxc toClientePxc = new TOClientePxc();
            
            // Executo listagem
            var retorno = this.RN.Listar(toClientePxc, null);

            // Valido que deu erro na listagem
            Assert.False(retorno.OK);
            Assert.IsNull(retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.NomeInvalido);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }

        ///  <summary></summary>
        [Test(Description = "Testa o método Listar com nome inválido.", Author = "T10863")]
        public void US3_CA03_ListarComNomeInvalidoTest()
        {
            // Monto TO com dados inválidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.NomeCliente = "@@@";

            // Executo inclusão
            var retorno = this.RN.Listar(toClientePxc, null);

            // Valido que deu erro na listagem
            Assert.False(retorno.OK);
            Assert.IsNull(retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = TOClientePxc.MENSAGEM_NOME_INVALIDO;
            MMAssert.True(retorno.Mensagem.ParaUsuario.ToString().Contains(mensagemEsperada));
        }
        ///  <summary></summary>
        [Test(Description = "Testa o método Listar sem nenhum registro.", Author = "T10863")]
        public void US3_CA04_ListarSemNenhumRegistroTest()
        {
            // Aplico o mock
            var mock = new MockClientePxc(this.Infra);
            mock.ListarComFalha();

            // Monto TO com dados válidos
            TOClientePxc toClientePxc = new TOClientePxc();
            toClientePxc.NomeCliente = "Gabriel Pereira";

            // Executo listagem
            var retorno = this.RN.Listar(toClientePxc, null);

            // Valido que deu erro na listagem
            Assert.False(retorno.OK);
            Assert.IsNull(retorno.Dados);

            // Valido que a mensagem obtida é a esperada
            var mensagemEsperada = new ClienteMensagem(TipoMensagem.NenhumClienteEncontrado);
            MMAssert.FalhaComMensagem<ClienteMensagem>(retorno, mensagemEsperada.Identificador);
        }
	}
}

