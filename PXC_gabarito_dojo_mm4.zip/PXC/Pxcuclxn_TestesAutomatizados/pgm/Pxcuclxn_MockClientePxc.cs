﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcqclxn;
using Bergs.Pxc.Pxcsclxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcuclxn.Tests
{
	
	///  <summary>
	/// Contém os métodos de mock para testes da classe ClientePxc.
	/// </summary>
	public class MockClientePxc : AbstractMmMock
	{
		#region Construtor
		///  <summary>
		/// Construtor da classe de mocks
		/// </summary>
		/// <param name="infra">Infra</param>
		public MockClientePxc(InfraTeste infra) : 
				base(infra)
		{
		}
		#endregion
		///  <summary>
		/// Registra um mock para o método Incluir.
		/// </summary>
		public void ObterRegistroDuplicado()
		{
			Pxcqclxn.ClientePxc mockClientePxcBD = this.Mock.Para<Pxcqclxn.ClientePxc>();
            mockClientePxcBD.Obter(MmMockArgumento.Qualquer<TOClientePxc>()).Retorna(this.Infra.RetornarSucesso<TOClientePxc>(new TOClientePxc()));
		}
		///  <summary>
		/// Registra um mock para o método Listar.
		/// </summary>
		public void ListarComFalha()
		{
			Pxcqclxn.ClientePxc mockClientePxcBD = this.Mock.Para<Pxcqclxn.ClientePxc>();
			mockClientePxcBD.Listar(MmMockArgumento.Qualquer<TOClientePxc>(), MmMockArgumento.Qualquer<TOPaginacao>()).Retorna(this.Infra.RetornarSucesso(new List<TOClientePxc>()));
		}
	}
}

