# Avaliação: Gestão de contas bancárias

## Problema

Você precisa criar uma aplicação MM4 para a gestão de contas bancárias, compreendendo toda a parte operacional de criação, consultas e atualização de contas bancárias. A deleção não é permitida — logo não será desenvolvida.

As user stories disponibilizadas pelos times de negócio e qualidade são as seguintes:

```gherkin
US1 - Inclusão de nova conta bancária

Como um analista financeiro
Eu quero incluir uma nova conta bancária informando número da agência, número da conta e cliente associado
Para que o sistema mantenha um cadastro oficial e padronizado de contas bancárias

Regras
    [PRONTA] [R01] O número da agência é obrigatório
    [PRONTA] [R02] O número da agência deve conter exatamente 4 dígitos numéricos de 1000 a 9999
    [PRONTA] [R03] O número da conta é obrigatório
    [PRONTA] [R04] O número da conta deve conter até 10 dígitos numéricos de 1 até 2000000000 (dois bilhões)
    [PRONTA] [R05] A combinação de número de agência e número de conta deve ser única na base
    [PRONTA] [R06] O saldo inicial é obrigatório
    [PRONTA] [R07] O saldo inicial deve ser maior ou igual a 0 (zero)
    [PRONTA] [R08] O código do cliente é obrigatório
    [PRONTA] [R09] O código do cliente é representado pelo seu respectivo CPF ou CNPJ
    [VERIFICAR COM A ANOTAÇÃO] [R10] O código do cliente deve ser válido perante cálculos de dígito verificador (não é necessária a verificação prévia de existência do cliente na base de dados)
    [PRONTA] [R11] O tipo de pessoa é obrigatório
    [PRONTA] [R12] O tipo de pessoa deve aceitar apenas "F" (física) ou "J" (jurídica)
    [PRONTA] [R13] A situação é obrigatória e deve ser sempre "A" (ativa) no momento da inclusão
    [PRONTA] [R14] O operador é obrigatório e deve ser sempre preenchido com a matrícula do usuário logado no momento da inclusão
    [PRONTA] [R15] A data de última atualização é obrigatória e deve ser sempre preenchida com a data data/hora atual no momento da inclusão

Critérios de Aceitação
    [PROBLEMA REGISTRO DUPLICADO] [CA01] Dado que informo um número de agência válido, um número de conta válido, um código de cliente válido, um tipo de pessoa válido e um saldo inicial válido (maior ou igual a zero), sendo que não existe na base de dados uma conta bancária com a mesma combinação de números de agência e conta, então a aplicação inclui a nova conta bancária com situação "A", preenche o código do operador de acordo com usuário logado, e a data de atualização com a data/hora atuais
    [PRONTO] [CA02] Dado que o número da agência não é informado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de agência deve ser informado (entre 1000 e 9999)."
    [PRONTO] [CA03] Dado que o número da agência está fora do intervalo numérico esperado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de agência deve ser informado (entre 1000 e 9999)." 
    [PRONTO] [CA04] Dado que o número da conta não é informado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de conta deve ser informado (entre 1 e 2000000000)."
    [PRONTO] [CA05] Dado que o número da conta está fora do intervalo numérico esperado, então a aplicação rejeita a inclusão com a mensagem "Um número válido de conta deve ser informado (entre 1 e 2000000000)."
    [PRONTO] [CA06] Dado que já existe uma conta bancária com a mesma combinação de números de agência e conta, então a aplicação rejeita a inclusão com a mensagem "Já existe na base de dados uma conta bancária com a combinação de número de agência e número de conta informados."
    [PRONTO] [CA07] Dado que o saldo inicial não é informado, então a aplicação rejeita a inclusão com a mensagem "Um saldo válido deve ser informado (não negativo)."
    [PRONTO] [CA08] Dado que o saldo inicial está fora do intervalo numérico esperado, então a aplicação rejeita a inclusão com a mensagem "Um saldo válido deve ser informado (não negativo)."
    [PRONTO] [CA09] Dado que o código do cliente informado é inválido (referente aos cálculos de dígito verificador de CPF e CNPJ), então a aplicação rejeita a inclusão com a mensagem "Um CPF/CNPJ válido deve ser informado."
    [PRONTO] [CA10] Dado que o tipo de pessoa informado é diferente das opções possíveis, então a aplicação rejeita a inclusão com a mensagem "Um tipo de pessoa válido deve ser informado ('F' para pessoa física ou 'J' para pessoa jurídica)."
```

```gherkin
US2 - Listagem de contas bancárias

Como um gerente de agência
Eu quero visualizar a lista completa de contas bancárias cadastradas
Para apoiar consultas operacionais, análises financeiras e auditorias internas

Regras
    [PRONTO] [R01] A listagem deve retornar as contas cadastradas de acordo com os critérios de filtragem (todos opcionais), que podem ser uma composição de:
        - Número da agência
        - Número da conta
        - Código do cliente
        - Tipo de pessoa do cliente
        - Situação
    [PRONTO] [R02] A listagem deve exibir para cada conta bancária:
        - Número da agência
        - Número da conta
        - Saldo
        - Código do cliente
        - Tipo de pessoa do cliente
        - Situação
        - Operador da última atualização
        - Data/hora da última atualização

Critérios de Aceitação
    [PRONTO] [CA01] Dado que solicito a listagem sem nenhum critério de filtragem informado, se houver contas bancárias cadastradas, então a aplicação retorna todas as contas bancárias cadastradas com as informações esperadas
    [PRONTO] [CA02] Dado que solicito a listagem com um set de critérios informado, se houver contas bancárias cadastradas para os critérios informados, então a aplicação retorna as devidas contas bancárias cadastradas com as informações esperadas
    [PRONTO*** RETORNAR LISTA] [CA03] Dado que solicito a listagem e não há contas bancárias cadastradas, então a aplicação rejeita a consulta com a mensagem "Não existem contas bancárias cadastradas."
    [TODO**] Precisa validar os campos como os especificados na US1
```

```gherkin
US3 - Consulta de conta bancária

Como um gerente de agência
Eu quero consultar os dados completos de uma conta bancária específica
Para validar informações em operações internas, auditorias e conferências periódicas de dados

Regras
    [PRONTO] [R01] O número da agência é obrigatório
    [PRONTO] [R02] O número da agência deve conter exatamente 4 dígitos numéricos de 1000 a 9999
    [PRONTO] [R03] O número da conta é obrigatório
    [PRONTO] [R04] O número da conta deve conter até 10 dígitos numéricos de 1 até 2000000000 (dois bilhões)
    [PRONTO] [R05] A consulta deve exibir para a conta bancária:
        - Número da agência
        - Número da conta
        - Saldo
        - Código do cliente
        - Tipo de pessoa do cliente
        - Situação
        - Operador da última atualização
        - Data/hora da última atualização
    [PRONTO] [R06] A consulta deve ser realizada exclusivamente pelo critério de filtragem da combinação obrigatória de:
        - Número da agência
        - Número da conta

Critérios de Aceitação
    [PRONTO] [CA01] Dado que informo um número de agência válido e um número de conta válido, e existe na base de dados uma conta bancária correspondente, então a aplicação retorna os dados completos da conta com as informações esperadas
    [CA02] Dado que o número da agência não é informado, então a aplicação rejeita a consulta com a mensagem "Um número válido de agência deve ser informado (entre 1000 e 9999)."
    [CA03] Dado que o número da agência está fora do intervalo numérico esperado, então a aplicação rejeita a consulta com a mensagem "Um número válido de agência deve ser informado (entre 1000 e 9999)."
    [CA04] Dado que o número da conta não é informado, então a aplicação rejeita a consulta com a mensagem "Um número válido de conta deve ser informado (entre 1 e 2000000000)."
    [CA05] Dado que o número da conta está fora do intervalo numérico esperado, então a aplicação rejeita a consulta com a mensagem "Um número válido de conta deve ser informado (entre 1 e 2000000000)."
    [CA06] Dado que não existe uma conta bancária com a mesma combinação de números de agência e conta informados, então a aplicação rejeita a consulta com a mensagem "Não existe uma conta bancária cadastrada para os critérios informados."
```

```gherkin
US4 - Alteração de situação de conta bancária

Como um analista financeiro
Eu quero alterar a situação de uma conta bancária específica
Para manter o cadastro atualizado conforme bloqueios, ativações e suspensões operacionais

Regras
    [R01] O número da agência é obrigatório
    [R02] O número da agência deve conter exatamente 4 dígitos numéricos de 1000 a 9999
    [R03] O número da conta é obrigatório
    [R04] O número da conta deve conter até 10 dígitos numéricos de 1 até 2000000000 (dois bilhões)
    [R05] A situação é o único campo permitido para alteração, e deve aceitar apenas:
        - "A" (ativa)
        - "I" (inativa)
        - "S" (suspensa)
    [R06] O operador é obrigatório e deve ser sempre atualizado com a matrícula do usuário logado no momento da alteração
    [R07] A data de última atualização é obrigatória e deve ser sempre atualizada com a data data/hora atual no momento da alteração
    [R08] A alteração deve ser realizada exclusivamente pelo critério de filtragem da combinação obrigatória de:
        - Número da agência
        - Número da conta

Critérios de Aceitação
    [CA01] Dado que informo um número de agência válido, um número de conta válido e uma situação válida ("A", "I" ou "S"), e existe na base de dados uma conta bancária correspondente, então a aplicação altera a situação da conta bancária, o código do operador de acordo com usuário logado e a data de atualização com a data/hora atuais
    [CA02] Dado que o número da agência não é informado, então a aplicação rejeita a alteração com a mensagem "Um número válido de agência deve ser informado (entre 1000 e 9999)."
    [CA03] Dado que o número da agência está fora do intervalo numérico esperado, então a aplicação rejeita a alteração com a mensagem "Um número válido de agência deve ser informado (entre 1000 e 9999)."
    [CA04] Dado que o número da conta não é informado, então a aplicação rejeita a alteração com a mensagem "Um número válido de conta deve ser informado (entre 1 e 2000000000)."
    [CA05] Dado que o número da conta está fora do intervalo numérico esperado, então a aplicação rejeita a alteração com a mensagem "Um número válido de conta deve ser informado (entre 1 e 2000000000)."
    [CA06] Dado que a nova situação informada não corresponde aos valores permitidos, então a aplicação rejeita a alteração com a mensagem "Uma situação válida deve ser informada ('A' para conta ativa, 'I' para inativa e 'S' para suspensa)."
    [CA07] Dado que não existe uma conta bancária com a mesma combinação de números de agência e conta informados, então a aplicação rejeita a alteração com a mensagem "Não existe uma conta bancária cadastrada para os critérios informados."
```

## Estrutura de dados

Modelagem já efetuada e pronta no **IBM DB2**:

```sql
SELECT
    AGENCIA           -- DECIMAL(4,0)   NN PK
  , CONTA             -- DECIMAL(10,0)  NN PK
  , SALDO             -- DECIMAL(15,2)  NN
  , IND_SITUACAO      -- CHAR(1)        NN
  , COD_CLIENTE       -- CHAR(14)       NN FK(PXC.CLIENTE_PXC)
  , IND_TP_PESSOA     -- CHAR(1)        NN FK(PXC.CLIENTE_PXC)
  , COD_OPERADOR      -- CHAR(6)        NN
  , ULT_ATUALIZACAO   -- TIMESTAMP      NN
FROM PXC.CONTA;
```

> Dica: Quando estiver construindo testes na camada U, caso precise preparar a tabela removendo registros de contas, certifique-se que registros filhos nas tabelas `PXC.BOLETO` e `PXC.PIX` sejam removidos antes, para evitar o bloqueio de deleção da conta devido às dependências.

## Informações adicionais

- Além da operação _Excluir_ , as operações _Contar_ e _Imprimir_ também **não precisam ser desenvolvidas**;
- O _identificador curto para o TO_ de contas é **"cn"**;
- Os dados de cliente a serem utilizados para cenários de teste em geral devem ser:
  - JOHN DOE:
    - CPF: **"89276546090"**;
    - Tipo: **"F"**.
  - DB TREINAMENTOS LTDA:
    - CPNJ: **"43977980000190"**;
    - Tipo: **"J"**.

<!--
Seed para inserção dos dois clientes na base de dados de desenvolvimento

INSERT INTO PXC.CLIENTE_PXC(
  COD_CLIENTE,
  TIPO_PESSOA,
  NOME_CLIENTE,
  AGENCIA,
  COD_OPERADOR,
  ULT_ATUALIZACAO,
  DT_ABE_CAD
) VALUES (
  '89276546090',
  'F',
  'JOHN DOE',
  1000,
  'T07007',
  CURRENT_TIMESTAMP,
  CURRENT_DATE
)

INSERT INTO PXC.CLIENTE_PXC(
  COD_CLIENTE,
  TIPO_PESSOA,
  NOME_CLIENTE,
  AGENCIA,
  COD_OPERADOR,
  ULT_ATUALIZACAO,
  DT_ABE_CAD
) VALUES (
  '43977980000190',
  'J',
  'DB TREINAMENTOS LTDA',
  1000,
  'T07007',
  CURRENT_TIMESTAMP,
  CURRENT_DATE
)
-->
  
![Registro cliente](./_assets/01-registro-clientes.png)

## Objetivos

- Criação do projeto de **TOs**
  - Deve tratar corretamente o mapeamento dos devidos _enums_ para tipo de pessoa do cliente e situação
- Criação do projeto de **camada Q:**
  - Deve conter o controle por _alias_
  - Deve conter o controle de _SAC_
- Criação do projeto de **camada S:**
  - A interface pública deve obrigatoriamente fazer uso dos métodos gerados pelo **Gerador de Classes MM4** para cada uma das operações respectivas às user stories — métodos com nomes diferentes dos originais serão desconsiderados na correção
  - Todas as regras contidas nas user stories devem ser satisfeitas
  - Deve conter o objeto de mapa de mensagens
  - Deve retornar para os devidos cenários, **mensagens idênticas** às definidas nos critérios de aceitação das user stories
- Criação do projeto de **camada U:**
  - Todos os critérios de aceitação contidos nas user stories devem ser atendidos por testes (não é necessária a entrega de casos de teste)
    - No nome do teste deve constar o identificador da user story e do critério de aceitação que ele cobre (exemplos: `US1_CA01_IncluirContaComSucessoTest`, `US3_CA05_ObterContaComNumeroContaInvalidoTest`, etc.)
  - As devidas mensagens retornadas da camada S devem ser validadas de acordo com os critérios de aceitação contidos nas user stories
  - Deve conter o objeto mock com ao menos 1 teste de falha ou exceção com dependência "mockada"
- É necessária a agregação de todos os projetos na **solução padrão** (arquivo .sln)

## Classe utilitária

Para esta avaliação, na pasta da aula foi disponibilizada uma classe utilitária contendo métodos e validadores reutilizáveis. Coloque-a **dentro do projeto de TOs** (`Pxcbtoxn`).
<!-- Utilitário em [./_assets/02-utilitario-avaliacao/] -->

Ela inclui funcionalidades de apoio como:

### BDUtils

- Constante `BD_CURRENT_TIMESTAMP` para auxiliar na implementação de SAC na **camada Q**. Em uma inclusão, por exemplo:
  
  ```csharp
  // Problema: Diferentes trechos de código usando a mesma string "CURRENT_TIMESTAMP" de forma duplicada e com margens para erro
  Sql.MontarCampoInsert(TOIdioma.DATA_HORA_ULTIMA_ALTERACAO); // ou Sql.MontarCampoInsert("DTHR_ULT_ATU");
  Sql.Temporario.Append("CURRENT_TIMESTAMP");
  
  // Solução: String centralizada em um só lugar e auxiliada pela tipagem forte
  Sql.MontarCampoInsert(TOIdioma.DATA_HORA_ULTIMA_ALTERACAO); // ou Sql.MontarCampoInsert("DTHR_ULT_ATU");
  Sql.Temporario.Append(BDUtils.BD_CURRENT_TIMESTAMP);
  ```

- Métodos `IsParametroPontoFlutuante(...)` e `FormatarParametroPontoFlutuante(...)` para auxiliar em uma configuração mais limpa de campos de valor monetário dentro do método `CriarParametro(...)` da **Camada Q**:
  
  ```csharp
  // Problema: Código de difícil compreensão e com regras sem muita explicação do porquê
  // [...]
  if (parametro.Scale > 0 && conteudo != null &&  parametro.DbType != DbType.DateTime)
  {
      parametro.Value = String.Format(CultureInfo.InvariantCulture, "{0:F" + parametro.Scale + "}", conteudo);
  }
  else
  {
      parametro.Value = conteudo;
  }
  // [...]

  // Solução: Mesma implementação, porém mais clara quanto à intenção (mais expressiva)
  // [...]
  if (BDUtils.IsParametroPontoFlutuante(parametro.DbType, parametro.Scale) && conteudo != null)
      parametro.Value = BDUtils.FormatarParametroPontoFlutuante(conteudo, parametro.Scale);
  else
      parametro.Value = conteudo;
  // [...]
  ```

### TOUtils

- Método `ExtrairMensagemAtributoValidacaoCampoTO<T>(...)` para auxiliar a pegar as mensagens de validação adicionadas via atributos de validação direto nos campos do TO, por exemplo:

  Para um dado campo do TO anotado com o atributo **NaoBranco** (nome de classe `NaoBrancoAttribute`):

  ```csharp
  // [...]
  [NaoBranco(mensagemErro: "Código ISO combinado deve ser informado.")]
  public CampoObrigatorio<string> CodigoIsoCombinado { get; set; }
  // [...]
  ```

  No momento do teste na camada U, essa mensagem que foi configurada no parâmetro `mensagemErro` pode ser recuperada para validar o resultado através de:

  ```csharp
  // [...]
  var mensagemNaoBrancoEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<NaoBrancoAttribute>(toIdioma, nameof(toIdioma.CodigoIsoCombinado));

  Assert.That(resultado.Mensagem.ParaUsuario, Contains.Substring(mensagemNaoBrancoEsperada)); // "Código ISO combinado deve ser informado."
  // [...]
  ```

### Validador combinado de CPF e CNPJ

- Atributo `CPFCNPJAttribute` para fazer a validação combinada de ambos os tipos de documento ao mesmo tempo para um dado campo:

  ```csharp
  // [...]
  [CPFCNPJ(mensagemErro: "Um CPF ou CNPJ válido deve ser informado para o identificador.")]
  public CampoObrigatorio<string> Identificador { get; set; }
  // [...]
  ```

> Notas:
>
> - Os trechos de código acima **são exemplos** — use-os como base para implementar na sua aplicação, conforme as regras e critérios de aceitação fornecidos;
> - O uso das funcionalidades de **BDUtils** e **TOUtils** é opcional — não haverão prejuízos de pontuação caso decida-se não utilizá-los (porém, para efeitos de aprendizado e clareza de código, recomendamos o uso).

## Entrega

A entrega será feita via upload da pasta completa `PXC` compactada (em `.zip` ou `.rar` de preferência) dentro da pasta de avaliação disponibilizada no espaço da aula.

Utilize como nome do arquivo o padrão `Avaliação-MM4-[matrícula]` ex.: `Avaliação-MM4-T07007`.

A data e horário limite para a entrega é **até 12:00 do dia 10/02/2026**. Entregas efetuadas após esse prazo sofrerão uma penalização de perda de **0.5 pontos do total**.

Lembrando que uma aplicação usual deve seguir um padrão estrutural semelhante a este:

```makefile
PXC\
|
├── pxcbtoxn\                         # Pasta do projeto - TOs
├── pxcqcnxn_Conta\                   # Pasta do projeto - Camada Q
├── pxcscnxn_Conta\                   # Pasta do projeto - Camada S
├── pxcucnxn_TestesAutomatizados\     # Pasta do projeto - Camada U
└── pxckcfxn.sln                      # Arquivo .NET da solução
```

Boa sorte e bom trabalho!
