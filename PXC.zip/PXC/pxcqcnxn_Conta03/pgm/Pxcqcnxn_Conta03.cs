﻿using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxodaxn.Excecoes;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.BD;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using System;
using System.Collections.Generic;
using System.Data;
using System.Globalization;
using System.Text;

namespace Bergs.Pxc.Pxcqcnxn
{
    /// <summary>Classe que possui os métodos de manipulação de dados da tabela CONTA da base de dados PXC.</summary>
    public sealed class RegistroInexistenteCriteriosNaoAtendidosMensagem : Mensagem
    {
        /// <summary>Classe que possui os métodos de manipulação de dados da tabela CONTA da base de dados PXC.</summary>
        public override string ParaUsuario {
            get { return "Não existe uma conta bancária cadastrada para os critérios informados."; }
            }
    }


    /// <summary>Classe que possui os métodos de manipulação de dados da tabela CONTA da base de dados PXC.</summary>
    public class Conta : AplicacaoDados
    {
        #region Métodos

        /// <summary>Método alterar referente à tabela CONTA.</summary>
        /// <param name="toConta">Transfer Object de entrada referente à tabela CONTA.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<int> Alterar(TOConta toConta)
        {
            try
            {
                int registrosAfetados;
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear();
                toConta.CodOperador = Infra.Usuario.Matricula;
                    
                //Inicia montagem do comando
                this.Sql.Comando.Append("UPDATE PXC.CONTA");
                //Monta campos que serão modificados
                // R05
                this.Sql.MontarCampoSet("IND_SITUACAO", toConta.IndSituacao);
                this.Sql.MontarCampoSet("COD_OPERADOR", toConta.CodOperador);
                this.Sql.MontarCampoSet("ULT_ATUALIZACAO");
                this.Sql.Comando.Append("CURRENT_TIMESTAMP");
                //Filtra a alteração pelas chaves da tabela
                // R08
                this.MontarWhereChaves(toConta, String.Empty);
                //Filtra a alteração pelo campo de controle de acessos concorrentes
                // R07
                this.Sql.MontarCampoWhere("ULT_ATUALIZACAO", toConta.UltAtualizacao);

                //Executa o comando
                registrosAfetados = this.AlterarDados();
                if (registrosAfetados == 0)
                {
                    return this.Infra.RetornarFalha<int>(new ConcorrenciaMensagem());
                }

                return this.Infra.RetornarSucesso(registrosAfetados);
            }
			catch (ChaveEstrangeiraInexistenteException ex)
            {
                return this.Infra.RetornarFalha<int>(new ChaveEstrangeiraInexistenteMensagem(ex));
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<int>(ex);
            }
        }
            
        /// <summary>Método incluir referente à tabela CONTA.</summary>
        /// <param name="toConta">Transfer Object de entrada referente à tabela CONTA.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<int> Incluir(TOConta toConta)
        {
            try
            { 
                int registrosAfetados;                
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Sql.Temporario.Length = 0;
                this.Parametros.Clear();
                toConta.CodOperador = Infra.Usuario.Matricula; 
                //Inicia montagem do comando
                this.Sql.Comando.Append("INSERT INTO PXC.CONTA (");
                //Monta campos que serão inseridos
                this.MontarInsert(toConta);
                 
                //Une os buffers de montagem do comando
                this.Sql.Comando.Append(") VALUES (");                
                this.Sql.Comando.Append(this.Sql.Temporario.ToString());
                
                this.Sql.Comando.Append(")");

                //Executa o comando
                registrosAfetados = this.IncluirDados();

                return this.Infra.RetornarSucesso(registrosAfetados);
            }
			catch (RegistroDuplicadoException ex)
            {
                return this.Infra.RetornarFalha<int>(new RegistroDuplicadoMensagem(ex));
            }
			catch (ChaveEstrangeiraInexistenteException ex)
            {
                return this.Infra.RetornarFalha<int>(new ChaveEstrangeiraInexistenteMensagem(ex));
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<int>(ex);
            }
        }
    
        /// <summary>Método listar referente à tabela CONTA.</summary>
        /// <param name="toConta">Transfer Object de entrada referente à tabela CONTA.</param>
        /// <param name="toPaginacao">Classe da infra-estrutura contendo as informações de paginação.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<List<TOConta>> Listar(TOConta toConta, TOPaginacao toPaginacao)
        {
            try
            {
                List<TOConta> dados;
                TOConta toRetorno;
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear(); 

                //Inicia montagem do comando
                this.Sql.Comando.Append("SELECT ");
                this.Sql.Comando.Append("CON.AGENCIA, ");
                this.Sql.Comando.Append("CON.CONTA, ");
                this.Sql.Comando.Append("CON.SALDO, ");
                this.Sql.Comando.Append("CON.COD_CLIENTE, ");
                this.Sql.Comando.Append("CON.IND_TP_PESSOA, ");
                this.Sql.Comando.Append("CON.IND_SITUACAO, ");
                this.Sql.Comando.Append("CON.COD_OPERADOR, ");
                this.Sql.Comando.Append("CON.ULT_ATUALIZACAO ");
                this.Sql.Comando.Append("FROM PXC.CONTA CON");
                //Filtra consulta pelos dados informados no TO
                // Garante R01
                this.Sql.MontarCampoWhere("CON.AGENCIA", toConta.Agencia);
                this.Sql.MontarCampoWhere("CON.CONTA", toConta.Conta);
                this.Sql.MontarCampoWhere("CON.COD_CLIENTE", toConta.CodCliente);
                this.Sql.MontarCampoWhere("CON.IND_TP_PESSOA", toConta.IndTpPessoa);
                this.Sql.MontarCampoWhere("CON.IND_SITUACAO", toConta.IndSituacao);

                dados = new List<TOConta>();

                if (toPaginacao == null)
                {
                    //Executa o comando sem utilizar paginação
                    using (ListaConectada listaConectada = this.ListarDados())
                    {
                        //Cria TO para cada tupla retornada
                        while (listaConectada.Ler())
                        {
                            toRetorno = new TOConta();
                            toRetorno.PopularRetorno(listaConectada.LinhaAtual);
                            dados.Add(toRetorno);
                        }
                    }
                }
                else
                {
                    //Executa o comando utilizando paginação
                    ListaDesconectada listaDesconectada = this.ListarDados(toPaginacao);

                    //Cria TO para cada tupla retornada
                    foreach (Linha linha in listaDesconectada.Linhas)
                    {
                        toRetorno = new TOConta();
                        toRetorno.PopularRetorno(linha);
                        dados.Add(toRetorno);
                    }
                }

                return this.Infra.RetornarSucesso(dados);
            }    
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<List<TOConta>>(ex);
            }
        }
    
        /// <summary>Método obter referente à tabela CONTA.</summary>
        /// <param name="toConta">Transfer Object de entrada referente à tabela CONTA.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOConta> Obter(TOConta toConta)
        {
            try
            {
                Linha linha;
                TOConta dados;
                
                //Limpa as propriedades utilizadas para a montagem do comando
                this.Sql.Comando.Length = 0;
                this.Parametros.Clear(); 

                //Inicia montagem do comando
                // US3_R05
                this.Sql.Comando.Append("SELECT ");
                this.Sql.Comando.Append("CON.AGENCIA, ");
                this.Sql.Comando.Append("CON.CONTA, ");
                this.Sql.Comando.Append("CON.SALDO, ");
                this.Sql.Comando.Append("CON.COD_CLIENTE, ");
                this.Sql.Comando.Append("CON.IND_TP_PESSOA, ");
                this.Sql.Comando.Append("CON.IND_SITUACAO, ");
                this.Sql.Comando.Append("CON.COD_OPERADOR, ");
                this.Sql.Comando.Append("CON.ULT_ATUALIZACAO ");
                this.Sql.Comando.Append("FROM PXC.CONTA CON");
                //Filtra consulta pelos dados informados no TO
                // Garante US3_R06
                this.MontarWhereChaves(toConta, "CON.");

                //Executa o comando
                linha = this.ObterDados();
                if (linha == null)
                {
                    return this.Infra.RetornarFalha<TOConta>(new RegistroInexistenteCriteriosNaoAtendidosMensagem());
                }
                
                //Cria TO para a tupla retornada
                dados = new TOConta();
                dados.PopularRetorno(linha);

                return this.Infra.RetornarSucesso(dados);
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<TOConta>(ex);
            }
        }
    
        /// <summary>Monta campos para cláusula WHERE.</summary>
        /// <param name="toConta">TO contendo os campos.</param>
        /// <param name="alias">Alias da tabela Conta.</param>
        private void MontarWhere(TOConta toConta, String alias)
        {
            //Monta no WHERE todos os campos da tabela que foram informados
            
            this.MontarWhereChaves(toConta, alias);
            this.MontarCampos(this.Sql.MontarCampoWhere, toConta, alias);
            
			this.Sql.MontarCampoWhere(alias + "ULT_ATUALIZACAO", toConta.UltAtualizacao);
        }
        
        /// <summary>Monta campos chave para cláusula WHERE.</summary>
        /// <param name="toConta">TO contendo os campos.</param>
        /// <param name="alias">Alias da tabela Conta.</param>
        private void MontarWhereChaves(TOConta toConta, String alias)
        {
            //Monta no WHERE todos os campos chave da tabela
            
            this.MontarCamposChave(this.Sql.MontarCampoWhere, toConta, alias);
        }
        
        /// <summary>Monta campos para cláusula SET.</summary>
        /// <param name="toConta">TO contendo os campos.</param>
        private void MontarSet(TOConta toConta)
        {
            //Monta no SET todos os campos não chave da tabela que foram informados
            
            this.MontarCampos(this.Sql.MontarCampoSet, toConta, String.Empty);
            this.Sql.MontarCampoSet("ULT_ATUALIZACAO");
            this.Sql.Comando.Append("CURRENT_TIMESTAMP");
        }
        
        /// <summary>Monta campos para cláusula INSERT.</summary>
        /// <param name="toConta">TO contendo os campos.</param>
        private void MontarInsert(TOConta toConta)
        {
            //Monta no INSERT todos os campos da tabela que foram informados
            
            this.MontarCamposChave(this.Sql.MontarCampoInsert, toConta, String.Empty);
            this.MontarCampos(this.Sql.MontarCampoInsert, toConta, String.Empty);
            this.Sql.MontarCampoInsert("ULT_ATUALIZACAO");
            this.Sql.Temporario.Append("CURRENT_TIMESTAMP");
        }
        
        /// <summary>Executa uma ação nos campos chave de um TO.</summary>
        /// <param name="montagem">Ação a ser executada.</param>
        /// <param name="toConta">TO alvo das ações.</param>
        /// <param name="alias">Alias da tabela Conta.</param>
        private void MontarCamposChave(ConstrutorSql.MontarCampo montagem, TOConta toConta, String alias)
        {   
            //Invoca qualquer comando simples de montagem nos campos chave da tabela
            
            montagem.Invoke(alias + "AGENCIA", toConta.Agencia);
            montagem.Invoke(alias + "CONTA", toConta.Conta);
        }
        
        /// <summary>Executa uma ação nos campos não chave de um TO.</summary>
        /// <param name="montagem">Ação a ser executada.</param>
        /// <param name="toConta">TO alvo das ações.</param>
        /// <param name="alias">Alias da tabela Conta.</param>
        private void MontarCampos(ConstrutorSql.MontarCampo montagem, TOConta toConta, String alias)
        {   
            //Invoca qualquer comando simples de montagem nos campos não chave da tabela, exceto no que faz controle de acessos concorrentes
            
            montagem.Invoke(alias + "SALDO", toConta.Saldo);
            montagem.Invoke(alias + "IND_SITUACAO", toConta.IndSituacao);
            montagem.Invoke(alias + "COD_CLIENTE", toConta.CodCliente);
            montagem.Invoke(alias + "IND_TP_PESSOA", toConta.IndTpPessoa);
            montagem.Invoke(alias + "COD_OPERADOR", toConta.CodOperador);
        }

        /// <summary>Cria um parâmetro para a instrução SQL.</summary>
        /// <param name="nomeCampo">Nome do campo da tabela.</param>
        /// <param name="conteudo">Valor para o parâmetro.</param>
        /// <returns>Parâmetro recém-criado.</returns>
        protected override Parametro CriarParametro(String nomeCampo, Object conteudo)
        {
            Parametro parametro = new Parametro();
            switch (nomeCampo)
            {   
                #region Chaves Primárias
                case "AGENCIA":
                    parametro.Precision = 4;
                    parametro.Size = 4;
                    parametro.DbType = DbType.Decimal;
                    break;
                case "CONTA":
                    parametro.Precision = 10;
                    parametro.Size = 10;
                    parametro.DbType = DbType.Decimal;
                    break;                        
                #endregion

                #region Campos Obrigatórios
                case "SALDO":
                    parametro.Precision = 15;
                    parametro.Scale = 2;
                    parametro.Size = 15;
                    parametro.DbType = DbType.Decimal;
                    break;
                case "IND_SITUACAO":
                    parametro.Precision = 1;
                    parametro.Size = 1;
                    parametro.DbType = DbType.String;
                    break;
                case "COD_CLIENTE":
                    parametro.Precision = 14;
                    parametro.Size = 14;
                    parametro.DbType = DbType.String;
                    break;
                case "IND_TP_PESSOA":
                    parametro.Precision = 1;
                    parametro.Size = 1;
                    parametro.DbType = DbType.String;
                    break;
                case "COD_OPERADOR":
                    parametro.Precision = 6;
                    parametro.Size = 6;
                    parametro.DbType = DbType.String;
                    break;
                case "ULT_ATUALIZACAO":
                    parametro.Precision = 10;
                    parametro.Scale = 6;
                    parametro.Size = 10;
                    parametro.DbType = DbType.DateTime;
                    break;
                #endregion

                #region Campos Opcionais

#if DEBUG
                default:
                    //Força um erro em modo debug para alertar o programador caso tenha caido no default
                    //Todo parâmetro deve cair em um case neste switch
                    parametro = null;
                    break;
#endif
                #endregion                
            }
            parametro.Direction = ParameterDirection.Input;
            parametro.SourceColumn = nomeCampo;
            
            if (parametro.Scale > 0 && conteudo != null &&  parametro.DbType != DbType.DateTime)
            {
                parametro.Value = String.Format(CultureInfo.InvariantCulture, "{0:F" + parametro.Scale + "}", conteudo);
            }
            else
            {
                parametro.Value = conteudo;
            }
            
            return parametro;
        }
        #endregion
    }
}