<!-- markdownlint-disable MD033 -->
<!-- markdownlint-disable MD055 -->
<!-- markdownlint-disable MD056 -->

# Critérios de análise da avaliação: Gestão de contas bancárias

## Regras de pontuação

| Categoria | Pontuação |
| :- | :-: |
| Estruturação e Organização de Solução e Projetos | 0.5 |
| TOs | 1.5 |
| Camada Q | 2.0 |
| Camada S | 3.0 |
| Camada U | 3.0 |
| **Total** | **10.0** |
| **Pontuação mínima para aprovação** | (**7.0**) |
  
### Metodologia de pontuação

- A pontuação é distribuída proporcionalmente entre os itens avaliados: Conta-se o número de ocorrências do item avaliado e distribui-se a pontuação possível em **frações de igual valor** para cada repetição da ocorrência — se a ocorrência estiver correta, a pontuação é somada, caso contrário, é desconsiderada;
- Em casos excepcionais, quando o fracionamento igualitário de pontuação do item não for possível, as primeiras ocorrências recebem maior fração da pontuação — ou seja — as primeiras ocorrências encontradas podem ter um peso levemente superior às demais.

### Artefatos de referência

- **_Avaliação modelo_**: é uma reprodução de resolução da avaliação feita pelo próprio time de aprendizagem, que simula um "projeto ideal", servindo como referência para a correção das avaliações dos alunos;
- **_Gabarito de correções_**: é uma camada U com uma suíte de testes mais robusta, criada para automatização de correções de algumas partes das avaliações dos alunos.

## Detalhamento

### Estruturação e Organização de Solução e Projetos

| Item Avaliado | Pontuação Possível<br/>0.5 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| Estrutura Geral | 0.2 | **Estrutura de pastas** conforme padrão estabelecido. | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Solution | 0.2 | **Existência do arquivo de solution** (`.sln`) agregadora dos projetos. | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Identificador curto | 0.1 | **Identificador curto de TO `cn`** aplicado corretamente nos projetos de camada Q, S e U. | Comparação com a _avaliação modelo_. |

### TOs

| Item Avaliado | Pontuação Possível<br/>1.5 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| Enums | 0.4 | **2 enums** devidamente estruturados para uso na tipagem e população (através do método `PopularRetorno(...)`) das respectivas propriedades, suportando uma tradução mais expressiva das enumerações `CHAR(1)` da modelagem.<br/>- **0.02 por enum** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Tipagem | 0.4 | **8 propriedades** (representação dos campos) tipados corretamente conforme a modelagem.<br/>- **0.05 por propriedade**<br/>- Deve considerar os 2 enums<br/>- Ordem é irrelevante | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Mapeamento de retorno | 0.4 | **8 propriedades** (representação dos campos) sendo populadas corretamente através do método `PopularRetorno(...)`.<br/>- **0.05 por propriedade**<br/>- Deve considerar os 2 enums<br/>- Ordem é irrelevante | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Wrappers | 0.3 | **8 propriedades** (representação dos campos) envelopadas nos wrappers corretos `CampoObrigatorio<T>` e `CampoOpcional<T>` conforme a modelagem.<br/>- **0.03 por propriedade**\*<br/>- Deve considerar os 2 enums<br/>- Ordem é irrelevante<br/><br/><sub>* **0.04 nas primeiras 6 propriedades** devido à impossibilidade de divisão igualitária.</sub> | Comparação com a _avaliação modelo_. |

### Camada Q

| Item Avaliado | Pontuação Possível<br/>2.0 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| US1 - Inclusão de nova conta bancária: Interações com a base de dados | 0.65 | Comando SQL montado corretamente em relação à modelagem, às regras e aos critérios de aceitação da US principalmente com enfoque nas entradas (valores a serem inseridos) e saídas (retorno do comando), além de SAC implementado corretamente.<br/>- **0.3 para entradas**<br/>- **0.1 para saídas**<br/>- **0.25 para SAC** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Listagem de contas bancárias: Interações com a base de dados | 0.35 | Comando SQL montado corretamente em relação à modelagem, às regras e aos critérios de aceitação da US principalmente com enfoque nas entradas (critérios de filtragem) e saídas (valores a serem consultados), além do uso correto de alias.<br/>- **0.1 para entradas**<br/>- **0.15 para saídas**<br/>- **0.1 para alias** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US3 - Consulta de conta bancária: Interações com a base de dados | 0.35 | Comando SQL montado corretamente em relação à modelagem, às regras e aos critérios de aceitação da US principalmente com enfoque nas entradas (critérios de filtragem) e saídas (valores a serem consultados), além do uso correto de alias.<br/>- **0.1 para entradas**<br/>- **0.15 para saídas**<br/>- **0.1 para alias** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US4 - Alteração de situação de conta bancária: Interações com a base de dados | 0.65 | Comando SQL montado corretamente em relação à modelagem, às regras e aos critérios de aceitação da US principalmente com enfoque nas entradas (valores a serem atualizados e critérios de filtragem) e saídas (retorno do comando), além de SAC implementado corretamente.<br/>- **0.3 para entradas**<br/>- **0.1 para saídas**<br/>- **0.25 para SAC** | Comparação com a _avaliação modelo_. |

### Camada S

| Item Avaliado | Pontuação Possível<br/>3.0 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| US1 - Inclusão de nova conta bancária: Funcionalidade | 0.4 | Inclusão bem sucedida — validada pela suíte de testes do _gabarito de correções_.<br/>- Os seguintes testes com execução bem sucedida: **_TC01_**<br/>- **Tudo ou nada** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US2 - Listagem de contas bancárias: Funcionalidade | 0.2 | Consulta bem sucedida — validada pela suíte de testes do _gabarito de correções_.<br/>- Os seguintes testes com execução bem sucedida: **_TC39_**, **_TC41_**<br/>- **Tudo ou nada** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US3 - Consulta de conta bancária: Funcionalidade | 0.2 | Consulta bem sucedida — validada pela suíte de testes do _gabarito de correções_.<br/>- Os seguintes testes com execução bem sucedida: **_TC45_**<br/>- **Tudo ou nada** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US4 - Alteração de situação de conta bancária: Funcionalidade | 0.4 | Alteração bem sucedida — validada pela suíte de testes do _gabarito de correções_.<br/>- Os seguintes testes com execução bem sucedida: **_TC75_**<br/>- **Tudo ou nada** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US1 - Inclusão de nova conta bancária: Validações | 0.3 | **10 regras** destacadas da user story — validadas pela suíte de testes do _gabarito de correções_.<br/>- **0.03 por regra** com os respectivos testes com execução bem sucedida<br/>→ R01: **_TC15_**<br/>→ R02: **_TC03_**, **_TC05_**, **_TC07_**, **_TC09_**, **_TC11_**, **_TC13_**<br/>→ R03: **_TC27_**<br/>→ R04: **_TC17_**, **_TC19_**, **_TC21_**, **_TC23_**, **_TC25_**<br/>→ R06: **_TC33_**<br/>→ R07: **_TC31_**, **_TC111_**<br/>→ R08: **_TC107_**<br/>→ R10: **_TC35_**<br/>→ R11: **_TC109_**<br/>→ R12: **_TC37_** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US2 - Listagem de contas bancárias: Validações | 0.15 | **2 regras** destacadas da user story — validadas pela suíte de testes do _gabarito de correções_.<br/>- **0.075 por regra** com os respectivos testes com execução bem sucedida<br/>→ R01: **_TC39_**, **_TC41_**, **_TC43_**<br/>→ R02: **_TC113_** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US3 - Consulta de conta bancária: Validações | 0.15 | **5 regras** destacadas da user story — validadas pela suíte de testes do _gabarito de correções_.<br/>- **0.03 por regra** com os respectivos testes com execução bem sucedida<br/>→ R01: **_TC59_**<br/>→ R02: **_TC47_**, **_TC49_**, **_TC51_**, **_TC53_**, **_TC55_**, **_TC57_**<br/>→ R03: **_TC71_**<br/>→ R04: **_TC61_**, **_TC63_**, **_TC65_**, **_TC67_**, **_TC69_**<br/>→ R05: **_TC114_** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US4 - Alteração de situação de conta bancária: Validações | 0.3 | **6 regras** destacadas da user story — validadas pela suíte de testes do _gabarito de correções_.<br/>- **0.05 por regra** com os respectivos testes com execução bem sucedida<br/>→ R01: **_TC89_**<br/>→ R02: **_TC77_**, **_TC79_**, **_TC81_**, **_TC83_**, **_TC85_**, **_TC87_**<br/>→ R03: **_TC101_**<br/>→ R04: **_TC89_**, **_TC91_**, **_TC93_**, **_TC95_**, **_TC97_**, **_TC99_**<br/>→ R05: **_TC103_**<br/>→ R06: Checagem manual (comparação com a _avaliação modelo_) | Aplicação do _gabarito de correções_ e comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Mapa de mensagens | 0.3 | Objeto de mapeamento de mensagens devidamente estruturado para uso nos retornos da camada S.<br/>- Herança da classe `Bergs.Pwx.Pwxoiexn.Mensagens.Mensagem` (pode ter qualquer nome)<br/>- 1 enum devidamente estruturado para os tipos de mensagem (pode ter qualquer nome)<br/>- **tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US1 - Inclusão de nova conta bancária: Mensagens | 0.2 | **9 critérios de aceitação** destacados da user story — validados pela suíte de testes do _gabarito de correções_.<br/>- **0.02 por critério**\* com os respectivos testes com execução bem sucedida<br/>→ CA02: **_TC16_**<br/>→ CA03: **_TC04_**, **_TC06_**, **_TC08_**, **_TC10_**, **_TC12_**, **_TC14_**<br/>→ CA04: **_TC28_**<br/>→ CA05: **_TC18_**, **_TC20_**, **_TC22_**, **_TC24_**, **_TC26_**<br/>→ CA06: **_TC30_**<br/>→ CA07: **_TC34_**<br/>→ CA08: **_TC32_**<br/>→ CA09: **_TC36_**<br/>→ CA10: **_TC38_**<br/><br/><sub>* **0.03 nos primeiros 2 critérios** devido à impossibilidade de divisão igualitária.</sub> | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US2 - Listagem de contas bancárias: Mensagens | 0.1 | **1 critério de aceitação** destacado da user story — validado pela suíte de testes do _gabarito de correções_.<br/>→ CA03: **_TC44_**<br/>- **Tudo ou nada** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US3 - Consulta de conta bancária: Mensagens | 0.1 | **5 critérios de aceitação** destacados da user story — validados pela suíte de testes do _gabarito de correções_.<br/>- **0.02 por critério** com os respectivos testes com execução bem sucedida<br/>→ CA02: **_TC60_**<br/>→ CA03: **_TC48_**, **_TC50_**, **_TC52_**, **_TC54_**, **_TC56_**, **_TC58_**<br/>→ CA04: **_TC72_**<br/>→ CA05: **_TC62_**, **_TC64_**, **_TC66_**, **_TC68_**, **_TC70_**<br/>→ CA06: **_TC74_** | Aplicação do _gabarito de correções_. |
<span><!-- - --></span>
| US4 - Alteração de situação de conta bancária: Mensagens | 0.2 | **6 critérios de aceitação** destacados da user story — validados pela suíte de testes do _gabarito de correções_.<br/>- **0.032 por critério**\* com os respectivos testes com execução bem sucedida<br/>→ CA02: **_TC90_**<br/>→ CA03: **_TC78_**, **_TC80_**, **_TC82_**, **_TC84_**, **_TC86_**, **_TC88_**<br/>→ CA04: **_TC102_**<br/>→ CA05: **_TC90_**, **_TC92_**, **_TC94_**, **_TC96_**, **_TC98_**, **_TC100_**<br/>→ CA06: **_TC104_**<br/>→ CA07: **_TC106_**<br/><br/><sub>* **0.04 no primeiro critério** devido à impossibilidade de divisão igualitária.</sub> | Aplicação do _gabarito de correções_. |

### Camada U

| Item Avaliado | Pontuação Possível<br/>3.0 | Critério | Metodologia |
| :- | :-: | :- | :- |
<span><!-- - --></span>
| US1 - Inclusão de nova conta bancária: Testes de funcionalidade bem sucedida | 0.7 | **Teste de integração** com execução bem sucedida e contendo as asserções de inclusão bem sucedida.<br/>- Asserções faltantes em relação à _avaliação modelo_ figuram erro <br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Listagem de contas bancárias: Testes de funcionalidade bem sucedida | 0.25 | **Teste de integração** com execução bem sucedida e contendo as asserções de consulta bem sucedida.<br/>- Asserções faltantes em relação à _avaliação modelo_ figuram erro <br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US3 - Consulta de conta bancária: Testes de funcionalidade bem sucedida | 0.25 | **Teste de integração** com execução bem sucedida e contendo as asserções de consulta bem sucedida.<br/>- Asserções faltantes em relação à _avaliação modelo_ figuram erro <br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US4 - Alteração de situação de conta bancária: Testes de funcionalidade bem sucedida | 0.7 | **Teste de integração** com execução bem sucedida e contendo as asserções de alteração bem sucedida.<br/>- Asserções faltantes em relação à _avaliação modelo_ figuram erro <br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US1 - Inclusão de nova conta bancária: Testes de falha | 0.3 | **Testes de integração para 9 critérios de aceitação** destacados da user story (ao menos 1 para cada critério) — com execução bem sucedida e contendo asserções de falha, inclusive validando com exatidão **mensagens de retorno idênticas às dos critérios**.<br/>- **0.0325 por critério**\*<br/>→ CA02<br/>→ CA03<br/>→ CA04<br/>→ CA05<br/>→ CA06<br/>→ CA07<br/>→ CA08<br/>→ CA09<br/>→ CA10<br/><br/><sub>* **0.04 no primeiro critério** devido à impossibilidade de divisão igualitária.</sub> | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US2 - Listagem de contas bancárias: Testes de falha | 0.15 | **Testes de integração para 1 critério de aceitação** destacado da user story (ao menos 1 teste para o critério) — com execução bem sucedida e contendo asserções de falha, inclusive validando com exatidão **mensagem de retorno idêntica à do critério**.<br/>→ CA03<br/>- **Tudo ou nada** | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US3 - Consulta de conta bancária: Testes de falha | 0.15 | **Testes de integração para 5 critérios de aceitação** destacados da user story (ao menos 1 para cada critério) — com execução bem sucedida e contendo asserções de falha, inclusive validando com exatidão **mensagens de retorno idênticas às dos critérios**.<br/>- **0.03 por critério**<br/>→ CA02<br/>→ CA03<br/>→ CA04<br/>→ CA05<br/>→ CA06 | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| US4 - Alteração de situação de conta bancária: Testes de falha | 0.25 | **Testes de integração para 6 critérios de aceitação** destacados da user story (ao menos 1 para cada critério) — com execução bem sucedida e contendo asserções de falha, inclusive validando com exatidão **mensagens de retorno idênticas às dos critérios**.<br/>- **0.04 por critério**\*<br/>→ CA02<br/>→ CA03<br/>→ CA04<br/>→ CA05<br/>→ CA06<br/>→ CA07<br/><br/><sub>* **0.05 no primeiro critério** devido à impossibilidade de divisão igualitária.</sub> | Comparação com a _avaliação modelo_. |
<span><!-- - --></span>
| Mock | 0.25 | Objeto mock devidamente estruturado para uso nos testes da camada U e ao menos 1 **teste unitário** de falha ou exceção fazendo uso de um dos métodos de setup do objeto mock — com execução bem sucedida e contendo asserções de falha ou exceção.<br/>- Herança da classe `Bergs.Bth.Bthsmoxn.AbstractMmMock` (pode ter qualquer nome)<br/>- 1 método de setup "mockando" a camada Q e os seus métodos conforme necessidade (pode ter qualquer nome)<br/>- **tudo ou nada** | Comparação com a _avaliação modelo_. |
