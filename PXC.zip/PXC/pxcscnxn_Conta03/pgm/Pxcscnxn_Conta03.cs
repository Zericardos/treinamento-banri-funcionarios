﻿using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcqcnxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Relatorios;
using Bergs.Pwx.Pwxoiexn.RN;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using System;
using System.Collections.Generic;
using System.Text;
using Bergs.Pxc.Pxcsclxn;

namespace Bergs.Pxc.Pxcscnxn
{ 
    /// <summary>Classe que possui as regras de negócio para o acesso da tabela CONTA03 da base de dados PXC.</summary>
    public class Conta : AplicacaoRegraNegocio
    {
        private static readonly List<string> TiposPessoaValida = new List<string> { "F", "J" };
        private static readonly List<string> SituacaoValida = new List<string> { "A", "I", "S" };

        #region Métodos

        private bool TipoPessoaEhValida(string tipoPessoa)
        {
            return TiposPessoaValida.Contains(tipoPessoa);
        }
        private bool TipoSituacaoEhValida(string tipoSituacao)
        {
            return SituacaoValida.Contains(tipoSituacao);
        }

        /// <summary>Altera registro da tabela CONTA03.</summary>
        /// <param name="toConta">Transfer Object de entrada referente à tabela CONTA03.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<int> Alterar(TOConta toConta)
        {
            try
            {
                Pxcqcnxn.Conta bdConta;
                Retorno<int> alteracaoConta;

                #region Validação de campos
                //Valida que os campos que fazem parte da chave primária foram informados
                //Valida que os campos obrigatórios foram informados
                // R01
                if (!toConta.Agencia.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarExistenciaAgencia));
                }

                // R03
                if (!toConta.Conta.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarContaNaoInformada));
                }

                // R02, R04
                if (!ValidarTO(toConta, out var listaRetornoValidacao))
                    return Infra.RetornarFalha<int>(new ObjetoInvalidoMensagem(listaRetornoValidacao));

                var retornoObter = Obter(toConta);

                if (!retornoObter.OK)
                    return Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnObterContaCadastrada));
                
                // R05
                if (!TipoSituacaoEhValida(toConta.IndSituacao))
                {
                    return this.Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnAlterarSituacaoValida));
                }


                #endregion

                #region Validação de regras de negócio
                // R06
                toConta.CodOperador = this.Infra.Usuario.Matricula;
                #endregion

                bdConta = this.Infra.InstanciarBD<Pxcqcnxn.Conta>();
                
                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    alteracaoConta = bdConta.Alterar(toConta);
                    if (!alteracaoConta.OK)
                    {
                        return alteracaoConta;
                    }
                    
                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(alteracaoConta.Dados, new OperacaoRealizadaMensagem("Alteração"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<int>(ex);
            }
        }
            
        /// <summary>Inclui registro na tabela CONTA03.</summary>
        /// <param name="toConta">Transfer Object de entrada referente à tabela CONTA03.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<int> Incluir(TOConta toConta)
        {
            try
            {
                Pxcqcnxn.Conta bdConta;
                Retorno<int> inclusaoConta;

                #region Validação de campos
                //Valida que os campos obrigatórios foram informados
                // R01
                if (!toConta.Agencia.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarExistenciaAgencia));// mensagem
                }
                // R03
                if (!toConta.Conta.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarContaNaoInformada));
                }
                // R05 TODO: Avaliar usar método Obter com apenas Conta e Agência para garantir unicidade com essa combinação de chaves
                // R06
                if (!toConta.Saldo.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarSaldoNaoInformadoOuNegativo));
                }
                // R07
                if (toConta.Saldo < 0)
                {
                    return this.Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarSaldoNaoInformadoOuNegativo));
                }
                // R08
                if (!toConta.CodCliente.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("COD_CLIENTE"));
                }

                // R11
                if (!toConta.IndTpPessoa.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new CampoObrigatorioMensagem("IND_TP_PESSOA"));
                }
                // R12
                if (!TipoPessoaEhValida(toConta.IndTpPessoa))
                {
                    return this.Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarTipoPessoa));
                }
                // R13
                toConta.IndSituacao = "A";

                toConta.CodOperador = Infra.Usuario.Matricula;

                var retornoObter = Obter(toConta);

                if (retornoObter.OK && retornoObter.Dados.Conta.FoiSetado && retornoObter.Dados.Agencia.FoiSetado)
                {
                    return this.Infra.RetornarFalha<int>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarContaEAgenciaJaExistente));
                }
                #endregion

                if (!ValidarTO(toConta, out var listaRetornoValidacao))
                    return Infra.RetornarFalha<int>(new ObjetoInvalidoMensagem(listaRetornoValidacao));
                
                #region Validação de regras de negócio
                #endregion

                bdConta = this.Infra.InstanciarBD<Pxcqcnxn.Conta>();

                //Cria escopo transacional para garantir atomicidade
                using (EscopoTransacional escopo = this.Infra.CriarEscopoTransacional())
                {
                    inclusaoConta = bdConta.Incluir(toConta);
                    if (!inclusaoConta.OK)
                    {
                        return inclusaoConta;
                    }
                    
                    escopo.EfetivarTransacao();
                    return this.Infra.RetornarSucesso(inclusaoConta.Dados, new OperacaoRealizadaMensagem("Inclusão"));
                }
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<int>(ex);
            }
        }
    
        /// <summary>Lista registros da tabela CONTA03.</summary>
        /// <param name="toConta">Transfer Object de entrada referente à tabela CONTA03.</param>
        /// <param name="toPaginacao">Classe da infra-estrutura contendo as informações de paginação.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<List<TOConta>> Listar(TOConta toConta, TOPaginacao toPaginacao)
        {
            try
            {
                Pxcqcnxn.Conta bdConta;
                Retorno<List<TOConta>> listagemConta;
                
                #region Validação de regras de negócio
                #endregion
                
                bdConta = this.Infra.InstanciarBD<Pxcqcnxn.Conta>();

                listagemConta = bdConta.Listar(toConta, toPaginacao);
                if (!listagemConta.OK)
                {
                    return listagemConta;
                }

                if (listagemConta.Dados.Count > 0)
                {
                    return this.Infra.RetornarSucesso(listagemConta.Dados, new OperacaoRealizadaMensagem());
                }
                else
                    return this.Infra.RetornarFalha<List<TOConta>>(new ContaMensagem(TipoContaMensagem.FalhaRnListarContasCadastradas));
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<List<TOConta>>(ex);
            }
        }
    
        /// <summary>Obtém registro da tabela CONTA03.</summary>
        /// <param name="toConta">Transfer Object de entrada referente à tabela CONTA03.</param>
        /// <returns>Classe de retorno contendo as informações de resposta ou as informações de erro.</returns>
        public virtual Retorno<TOConta> Obter(TOConta toConta)
        {
            // US3
            try
            {
                Pxcqcnxn.Conta bdConta;
                Retorno<TOConta> obtencaoConta;

                #region Validação de campos
                //Valida que os campos que fazem parte da chave primária foram informados

                // R01
                if (!toConta.Agencia.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOConta>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarExistenciaAgencia));
                }

                // R03, R04
                if (!toConta.Conta.FoiSetado)
                {
                    return this.Infra.RetornarFalha<TOConta>(new ContaMensagem(TipoContaMensagem.FalhaRnValidarContaNaoInformada));
                }

                #endregion

                // R02, 
                if (!ValidarTO(toConta, out var listaRetornoValidacao))
                    return Infra.RetornarFalha<TOConta>(new ObjetoInvalidoMensagem(listaRetornoValidacao));
                
                #region Validação de regras de negócio
                #endregion

                bdConta = this.Infra.InstanciarBD<Pxcqcnxn.Conta>();

                obtencaoConta = bdConta.Obter(toConta);
                if (!obtencaoConta.OK)
                {
                    return obtencaoConta;
                }
                
                return this.Infra.RetornarSucesso(obtencaoConta.Dados, new OperacaoRealizadaMensagem());
            }
            catch (Exception ex)
            {
                return this.Infra.TratarExcecao<TOConta>(ex);
            }
        }
        #endregion
	} 
}