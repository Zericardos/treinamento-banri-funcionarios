﻿using System;

namespace Bergs.Pxc.Pxcsclxn
{
    /// <summary>Mensagens previstas para o componente</summary>
    public enum TipoContaMensagem
    {
        /// <summary>Agência não informada</summary>
        FalhaRnValidarExistenciaAgencia,
        /// <summary>Conta não informada</summary>
        FalhaRnValidarContaNaoInformada,
        /// <summary>Conta e Agência já existem</summary>
        FalhaRnValidarContaEAgenciaJaExistente,
        /// <summary>Combinação de Código Conta e Tipo Pessoa já existentes</summary>
        FalhaRnValidarTipoPessoa,
        /// <summary>Nome de Conta inválido, por favor use apenas letras, números e acentuações</summary>
        FalhaRnValidarSaldoNaoInformadoOuNegativo,
        /// <summary>Não há contas cadastradas</summary>
        FalhaRnListarContasCadastradas,
        /// <summary>Não há conta cadastrada</summary>
        FalhaRnObterContaCadastrada,
        /// <summary>Situação não válida informada</summary>
        FalhaRnAlterarSituacaoValida
    }

    /// <summary>
    /// Classe de mapa de mensagens de Contas
    /// </summary>
    public class ContaMensagem : Pwx.Pwxoiexn.Mensagens.Mensagem
    {
        private const string MOTIVO_INDETERMINADO = "Motivo indeterminado.";
        private const string SUFIXO_GENERICO_INDETERMINANCIA = "indeterminado(a)";

        private readonly TipoContaMensagem _tipoMensagem;
        private readonly string _mensagem;

        /// <summary>
        /// Mensagem para o usuário
        /// </summary>
        public override string ParaUsuario
        {
            get { return ParaOperador; }
        }

        /// <summary>
        /// Mensagem para o operador (logs e auditorias internas)
        /// </summary>
        public override string ParaOperador
        {
            get { return _mensagem; }
        }

        /// <summary>
        /// Identificador do tipo de mensagem
        /// </summary>
        public override string Identificador
        {
            get { return _tipoMensagem.ToString(); }
        }

        /// <summary>
        /// Construtor de uma nova mensagem de conta
        /// </summary>
        /// <param name="tipoMensagem">Identificador do tipo de mensagem</param>
        /// <param name="argumentos">Argumentos extras a serem interpolados na mensagem</param>
        public ContaMensagem(TipoContaMensagem tipoMensagem, params string[] argumentos)
        {
            _tipoMensagem = tipoMensagem;

            _mensagem = MapearMensagem(argumentos);
        }

        /// <summary>
        /// Construtor de uma mensagem de conta a partir de outra mensagem já existente
        /// </summary>
        /// <param name="contaMensagem">Objeto de mensagem de conta</param>
        public ContaMensagem(ContaMensagem contaMensagem)
        {
            _tipoMensagem = (TipoContaMensagem)Enum.Parse(typeof(TipoContaMensagem), contaMensagem.Identificador);

            _mensagem = contaMensagem.ParaUsuario;
        }

        private string MapearMensagem(params string[] argumentos)
        {
            switch (_tipoMensagem)
            {
                case TipoContaMensagem.FalhaRnValidarExistenciaAgencia:
                    return "Um número válido de agência deve ser informado (entre 1000 e 9999).";
                case TipoContaMensagem.FalhaRnValidarContaNaoInformada:
                    return "Um número válido de conta deve ser informado (entre 1 e 2000000000).";
                case TipoContaMensagem.FalhaRnValidarContaEAgenciaJaExistente:
                    return "Já existe na base de dados uma conta bancária com a combinação de número de agência e número de conta informados.";
                case TipoContaMensagem.FalhaRnValidarSaldoNaoInformadoOuNegativo:
                    return "Um saldo válido deve ser informado (não negativo).";
                case TipoContaMensagem.FalhaRnValidarTipoPessoa:
                    return "Um tipo de pessoa válido deve ser informado ('F' para pessoa física ou 'J' para pessoa jurídica).";
                case TipoContaMensagem.FalhaRnListarContasCadastradas:
                    return "Não existem contas bancárias cadastradas.";
                case TipoContaMensagem.FalhaRnObterContaCadastrada:
                    return "Não existe uma conta bancária cadastrada para os critérios informados.";
                case TipoContaMensagem.FalhaRnAlterarSituacaoValida:
                    return "Uma situação válida deve ser informada ('A' para conta ativa, 'I' para inativa e 'S' para suspensa).";
                default:
                    return $"Houve uma falha {SUFIXO_GENERICO_INDETERMINANCIA} durante a execução das validações de categoria.";
            }
        }
    }
}
