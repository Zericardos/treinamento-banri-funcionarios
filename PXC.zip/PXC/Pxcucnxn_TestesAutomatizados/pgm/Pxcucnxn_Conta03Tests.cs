﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Bth.Bthstixn;
using Bergs.Bth.Bthstixn.MM4;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcbtoxn.pgm;
using Bergs.Pxc.Pxcsclxn;
using Bergs.Pxc.Pxcscnxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcucnxn.Tests
{
    // TODO: preencher todos os TOs com campos obrigatórios em todos os testes
	
	///  <summary>
	/// Contém os métodos de teste da classe Conta.
	/// </summary>
	[TestFixture(Description="Classe de testes para a classe RN Conta.", Author="B43925")]
	public class ContaTests : AbstractTesteRegraNegocio<Conta>
	{
        #region Métodos de teste de sucesso.
        #region Métodos de preparação dos testes
        ///  <summary>
        /// Executa uma ação UMA vez por classe, ANTES do início da execução dos métodos de teste.
        /// </summary>
        protected override void BeforeAll()
		{
		}
		///  <summary>
		/// Executa uma ação ANTES de cada método de teste da classe.
		/// </summary>
		protected override void BeforeEach()
		{
		}
		///  <summary>
		/// Executa uma ação UMA vez por classe, DEPOIS do término da execução dos métodos de teste.
		/// </summary>
		protected override void AfterAll()
		{
		}
		///  <summary>
		/// Executa uma ação DEPOIS de cada método de teste da classe.
		/// </summary>
		protected override void AfterEach()
		{
		}
		///  <summary>
		/// Método para setar os dados necessários para conexão com o PHA no servidor de build.
		/// </summary>
		/// <returns>TO com dados necessários para conexão no servidor de build.</returns>
		protected override TOPhaServidorBuild SetarDadosServidorBuild()
		{
			return new TOPhaServidorBuild("GESTAG", "TREINAMENTO MM5");
		}
		#endregion
		///  <summary>
		/// Realiza o teste padrão para o método Contar(TOConta).
		/// Validações realizadas: 
		/// - Chama o Contar usando os filtros informados.
		/// - Verifica se o retorno do método Contar foi de sucesso.
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// 4 - Retorno.Dados não é zero.
		/// 
		/// </summary>
		[Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA01_IncluirComSucessoTest()
		{
            // Preparar

            var mock = new MockConta(this.Infra);
            mock.IncluirComSucesso();

            // var mock2 = new MockConta(this.Infra);
            // mock2.ObterComSucesso();

            TOConta toConta = new TOConta();

            toConta.Agencia = 1540;
            toConta.Conta = 1254;
            toConta.CodCliente = "06532052957";
            //toConta.CodCliente = "85729477015";
            toConta.IndTpPessoa = "F";
            toConta.Saldo = 10;
            // TODO: Setar valores necessários para o toConta
            //Agir
            var retornoInclusao = this.RN.Incluir(toConta);
            Assert.True(retornoInclusao.OK);
            Assert.NotNull(retornoInclusao.Dados);
            // Validar
            //var retornoConsultaInclusao = this.RN.Obter(toConta);

            //Assert.AreEqual(situacaoEsperada, retornoConsultaInclusao.IndSituacao);
            base.TestarIncluir(toConta);

		}
        ///  <summary>
        /// </summary>
        [Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA02_IncluirAgenciaNaoInformadaComFalhaTest()
		{
            // Preparar
            string mensagemEsperada = "Um número válido de agência deve ser informado (entre 1000 e 9999).";
            TOConta toConta = new TOConta();
            toConta.Conta = 1;
            toConta.CodCliente = "43977980000190";
            toConta.IndTpPessoa = "J";
            toConta.Saldo = 10;
            // Agir
            var retornoInclusao = this.RN.Incluir(toConta);

            // Validar
            Assert.False(retornoInclusao.OK);
            Assert.Zero(retornoInclusao.Dados);
            Assert.AreEqual(mensagemEsperada, retornoInclusao.Mensagem.ParaUsuario);
        }

        ///  <summary>
        /// </summary>
        [Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA03_IncluirAgenciaForaDoIntervaloComFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();

            var mensagemForaDoIntervaloEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<Pwx.Pwxoiexn.Validacoes.IntervaloAttribute>(toConta, nameof(toConta.Agencia));
            toConta.Conta = 1;
            toConta.Agencia = 1;
            toConta.CodCliente = "43977980000190";
            toConta.IndTpPessoa = "J";
            toConta.Saldo = 10;
            // Agir
            var retornoInclusao = this.RN.Incluir(toConta);

            // Validar
            Assert.False(retornoInclusao.OK);
            Assert.Zero(retornoInclusao.Dados);
            Assert.That(retornoInclusao.Mensagem.ParaUsuario, Contains.Substring(mensagemForaDoIntervaloEsperada));
            //MMAssert.FalhaComMensagem<ContaMensagem>(retornoInclusao, TipoContaMensagem.FalhaRnValidarExistenciaAgencia.ToString());
            //MMAssert.FalhaComMensagem<ContaMensagem>(retornoInclusao, mensagemEsperada);
        }

        ///  <summary>
        /// </summary>
        [Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA04_IncluirContaNaoInformadaComFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();

            string mensagemContaNaoInformadaEsperada = "Um número válido de conta deve ser informado (entre 1 e 2000000000).";
            toConta.Agencia = 1;
            toConta.CodCliente = "43977980000190";
            toConta.IndTpPessoa = "J";
            toConta.Saldo = 10;
            // Agir
            var retornoInclusao = this.RN.Incluir(toConta);

            // Validar
            Assert.False(retornoInclusao.OK);
            Assert.Zero(retornoInclusao.Dados);
            Assert.AreEqual(mensagemContaNaoInformadaEsperada, retornoInclusao.Mensagem.ParaUsuario);
        }

        ///  <summary>
        /// </summary>
        [Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA05_IncluirContaForadoIntervaloComFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();

            var mensagemForaDoIntervaloEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<Pwx.Pwxoiexn.Validacoes.IntervaloAttribute>(toConta, nameof(toConta.Conta));
            toConta.Conta = 0;
            toConta.Agencia = 1000;
            toConta.CodCliente = "43977980000190";
            toConta.IndTpPessoa = "J";
            toConta.Saldo = 10;
            // Agir
            var retornoInclusao = this.RN.Incluir(toConta);

            // Validar
            Assert.False(retornoInclusao.OK);
            Assert.Zero(retornoInclusao.Dados);
            Assert.That(retornoInclusao.Mensagem.ParaUsuario, Contains.Substring(mensagemForaDoIntervaloEsperada));
            //MMAssert.FalhaComMensagem<ContaMensagem>(retornoInclusao, TipoContaMensagem.FalhaRnValidarExistenciaAgencia.ToString());
            //MMAssert.FalhaComMensagem<ContaMensagem>(retornoInclusao, mensagemEsperada);
        }

        
        ///  <summary>
        /// </summary>
        [Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA06_IncluirContaEAgenciaJaExistenteFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();

            string mensagemContaEAgenciaJaExistentesEsperada = "Já existe na base de dados uma conta bancária com a combinação de número de agência e número de conta informados.";
            toConta.Conta = 1;
            toConta.Agencia = 1000;
            toConta.CodCliente = "43977980000190";
            toConta.IndTpPessoa = "J";
            toConta.Saldo = 10;
            // Agir
            var retornoInclusao = this.RN.Incluir(toConta);

            // Validar
            Assert.False(retornoInclusao.OK);
            Assert.Zero(retornoInclusao.Dados);
            Assert.That(retornoInclusao.Mensagem.ParaUsuario, Contains.Substring(mensagemContaEAgenciaJaExistentesEsperada));
            //MMAssert.FalhaComMensagem<ContaMensagem>(retornoInclusao, TipoContaMensagem.FalhaRnValidarExistenciaAgencia.ToString());
            //MMAssert.FalhaComMensagem<ContaMensagem>(retornoInclusao, mensagemEsperada);
        }

        ///  <summary>
        /// </summary>
        [Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA07_IncluirContaSaldoNaoInformadoFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();

            string mensagemContaEAgenciaJaExistentesEsperada = "Um saldo válido deve ser informado (não negativo).";
            toConta.Conta = 145879;
            toConta.Agencia = 1025;
            toConta.CodCliente = "43977980000190";
            toConta.IndTpPessoa = "J";
            // Agir
            var retornoInclusao = this.RN.Incluir(toConta);

            // Validar
            Assert.False(retornoInclusao.OK);
            Assert.Zero(retornoInclusao.Dados);
            Assert.That(retornoInclusao.Mensagem.ParaUsuario, Contains.Substring(mensagemContaEAgenciaJaExistentesEsperada));
        }

        ///  <summary>
        /// </summary>
        [Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA08_IncluirContaSaldoForaDoIntervaloEsperadoFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();

            string mensagemContaEAgenciaJaExistentesEsperada = "Um saldo válido deve ser informado (não negativo).";
            toConta.Conta = 145879;
            toConta.Agencia = 1025;
            toConta.CodCliente = "43977980000190";
            toConta.IndTpPessoa = "J";
            toConta.Saldo = -10;
            // Agir
            var retornoInclusao = this.RN.Incluir(toConta);

            // Validar
            Assert.False(retornoInclusao.OK);
            Assert.Zero(retornoInclusao.Dados);
            Assert.That(retornoInclusao.Mensagem.ParaUsuario, Contains.Substring(mensagemContaEAgenciaJaExistentesEsperada));
        }

        ///  <summary>
        /// </summary>
        [Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA09_IncluirContaCPFInvalidoFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();

            var mensagemCPFInvalidoEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<CPFCNPJAttribute>(toConta, nameof(toConta.CodCliente));
            toConta.Conta = 145879;
            toConta.Agencia = 1025;
            toConta.CodCliente = "11111111111";
            toConta.IndTpPessoa = "F";
            toConta.Saldo = 10;
            // Agir
            var retornoInclusao = this.RN.Incluir(toConta);

            // Validar
            Assert.False(retornoInclusao.OK);
            Assert.Zero(retornoInclusao.Dados);
            Assert.That(retornoInclusao.Mensagem.ParaUsuario, Contains.Substring(mensagemCPFInvalidoEsperada));
        }
        
        ///  <summary>
        /// </summary>
        [Test(Description="Testa o método Incluir(TOConta).", Author="B43925")]
		public void US1_CA10_IncluirContaTipoPesoaInvalidaFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();

            string mensagemCPFInvalidoEsperada = "Um tipo de pessoa válido deve ser informado ('F' para pessoa física ou 'J' para pessoa jurídica).";
            toConta.Conta = 145879;
            toConta.Agencia = 1025;
            toConta.CodCliente = "43977980000190";
            toConta.IndTpPessoa = "Q";
            toConta.Saldo = 10;
            // Agir
            var retornoInclusao = this.RN.Incluir(toConta);

            // Validar
            Assert.False(retornoInclusao.OK);
            Assert.Zero(retornoInclusao.Dados);
            Assert.That(retornoInclusao.Mensagem.ParaUsuario, Contains.Substring(mensagemCPFInvalidoEsperada));
        }
        ///  <summary>
        /// Realiza o teste padrão para o método Listar(TOConta, TOPaginacao).
        /// Validações realizadas: 
        /// - Chama o Listar usando os filtros informados.
        /// - Verifica se o retorno do método Listar foi de sucesso
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// 4 - Retorno.Dados possui elementos.
        /// - Compara o retorno com os dados da lista de TO preenchida antes do teste.
        /// </summary>
        [Test(Description="Testa o método Listar(TOConta, TOPaginacao).", Author="B43925")]
		public void US2_CA01_ListarTodasAsContasCadastradasComSucessoTest()
		{
			TOConta toConta = new TOConta();
			TOPaginacao toPaginacao = new TOPaginacao(1, 10);
            var retornoListar = this.RN.Listar(toConta, toPaginacao);
            Assert.True(retornoListar.OK);
            Assert.NotZero(retornoListar.Dados.Count);
            base.TestarListar(toConta, toPaginacao);
		}

        ///  <summary>
        /// Realiza o teste padrão para o método Listar(TOConta, TOPaginacao).
        /// Validações realizadas: 
        /// - Chama o Listar usando os filtros informados.
        /// - Verifica se o retorno do método Listar foi de sucesso
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// 4 - Retorno.Dados possui elementos.
        /// - Compara o retorno com os dados da lista de TO preenchida antes do teste.
        /// </summary>
        [Test(Description="Testa o método Listar(TOConta, TOPaginacao).", Author="B43925")]
		public void US2_CA02_ListarContasCadastradasFiltradasPorAgenciaComSucessoTest()
		{
			TOConta toConta = new TOConta();
            toConta.Agencia = 1237;
			TOPaginacao toPaginacao = new TOPaginacao(1, 10);
            var retornoListar = this.RN.Listar(toConta, toPaginacao);
            Assert.True(retornoListar.OK);
            Assert.NotZero(retornoListar.Dados.Count);
            base.TestarListar(toConta, toPaginacao);
		}

        ///  <summary>
        /// Realiza o teste padrão para o método Listar(TOConta, TOPaginacao).
        /// Validações realizadas: 
        /// - Chama o Listar usando os filtros informados.
        /// - Verifica se o retorno do método Listar foi de sucesso
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// 4 - Retorno.Dados possui elementos.
        /// - Compara o retorno com os dados da lista de TO preenchida antes do teste.
        /// </summary>
        [Test(Description="Testa o método Listar(TOConta, TOPaginacao).", Author="B43925")]
		public void US2_CA03_ListarContaInexistenteComFalhaTest()
		{
            string mensagemNaoExistemContasCadastradasEsperada = "Não existem contas bancárias cadastradas.";
            TOConta toConta = new TOConta();
            toConta.CodCliente = "06532052957";
			TOPaginacao toPaginacao = new TOPaginacao(1, 10);
            var retornoListar = this.RN.Listar(toConta, toPaginacao);
            Assert.False(retornoListar.OK);
            //Assert.Zero(retornoListar.Dados);  // TODO: Retornar uma lista, modificar o de baixo
            Assert.That(retornoListar.Mensagem.ParaUsuario, Contains.Substring(mensagemNaoExistemContasCadastradasEsperada));
            //base.TestarListar(toConta, toPaginacao);
		}
		///  <summary>
		/// Realiza o teste padrão para o método Obter(TOConta).
		/// Validações realizadas: 
		/// - Chama o método Obter usando os filtros de chave informados.
		/// - Verifica se o retorno do método Obter foi de sucesso.
		/// - Realiza as seguintes Assertivas:
		/// 1 - Retorno não está nulo.
		/// 2 - Retorno.OK é sucesso (== true).
		/// 3 - Retorno.Dados não está nulo.
		/// - Compara o retorno do Obter com os dados do TO preenchido antes do teste.
		/// </summary>
		[Test(Description="Testa o método Obter(TOConta).", Author="B43925")]
		public void US3_CA01_ObterComSucessoTest()
		{
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Conta = 12313131;
            toConta.Agencia = 1237;

            Decimal AgenciaEsperada = 1237;
            string CodClienteEsperada = "89276546090";
            string CodOperadorEsperada = "T10911";
            Decimal ContaEsperada = 12313131;
            string IndSituacaoEsperada = "S";
            string IndTpPessoaEsperada = "F";
            Decimal SaldoEsperada = 1000000.00M;

            // Agir
            var retornoObter = this.RN.Obter(toConta);

            // Validar

            Assert.True(retornoObter.OK);
            Assert.AreEqual(AgenciaEsperada, retornoObter.Dados.Agencia);
            Assert.AreEqual(CodClienteEsperada, retornoObter.Dados.CodCliente);
            Assert.AreEqual(CodOperadorEsperada, retornoObter.Dados.CodOperador);
            Assert.AreEqual(ContaEsperada, retornoObter.Dados.Conta);
            Assert.AreEqual(IndSituacaoEsperada, retornoObter.Dados.IndSituacao);
            Assert.AreEqual(IndTpPessoaEsperada, retornoObter.Dados.IndTpPessoa);
            Assert.AreEqual(SaldoEsperada, retornoObter.Dados.Saldo);
            
            // TODO: Setar valores necessários para o toConta
            base.TestarObter(toConta);
		}
        #endregion

        #region Métodos de teste de Falha.

        ///  <summary>
        /// Realiza o teste padrão para o método Obter(TOConta).
        /// Validações realizadas: 
        /// - Chama o método Obter usando os filtros de chave informados.
        /// - Verifica se o retorno do método Obter foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Compara o retorno do Obter com os dados do TO preenchido antes do teste.
        /// </summary>
        [Test(Description = "Testa o método Obter(TOConta).", Author = "B43925")]
        public void US3_CA02_ObterAgenciaNaoInformadaComFalhaTest()
        {
            // Preparar
            string mensagemEsperada = "Um número válido de agência deve ser informado (entre 1000 e 9999).";
            TOConta toConta = new TOConta();
            toConta.Conta = 12313131;

            // Agir
            var retornoObter = this.RN.Obter(toConta);

            // Validar

            Assert.False(retornoObter.OK);
            Assert.AreEqual(mensagemEsperada, retornoObter.Mensagem.ParaUsuario);
        }

        ///  <summary>
        /// Realiza o teste padrão para o método Obter(TOConta).
        /// Validações realizadas: 
        /// - Chama o método Obter usando os filtros de chave informados.
        /// - Verifica se o retorno do método Obter foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Compara o retorno do Obter com os dados do TO preenchido antes do teste.
        /// </summary>
        [Test(Description = "Testa o método Obter(TOConta).", Author = "B43925")]
        public void US3_CA03_ObterAgenciaForaDoIntervaloComFalhaTest()
        {
            // TODO: Preparar outros números, testar limites de borda
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Conta = 12313131;
            toConta.Agencia = 999;

            // Agir
            var retornoObter = this.RN.Obter(toConta);
            var mensagemForaDoIntervaloEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<Pwx.Pwxoiexn.Validacoes.IntervaloAttribute>(toConta, nameof(toConta.Agencia));

            // Validar

            Assert.False(retornoObter.OK);
            Assert.That(retornoObter.Mensagem.ParaUsuario, Contains.Substring(mensagemForaDoIntervaloEsperada));
        }

        ///  <summary>
        /// Realiza o teste padrão para o método Obter(TOConta).
        /// Validações realizadas: 
        /// - Chama o método Obter usando os filtros de chave informados.
        /// - Verifica se o retorno do método Obter foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Compara o retorno do Obter com os dados do TO preenchido antes do teste.
        /// </summary>
        [Test(Description = "Testa o método Obter(TOConta).", Author = "B43925")]
        public void US3_CA04_ObterContaNaoInformadaComFalhaTest()
        {
            // TODO: Preparar outros números, testar limites de borda
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Agencia = 9999;

            // Agir
            var retornoObter = this.RN.Obter(toConta);
            string mensagemContaNaoInformadaEsperada = "Um número válido de conta deve ser informado (entre 1 e 2000000000).";

            // Validar

            Assert.False(retornoObter.OK);
            Assert.AreEqual(mensagemContaNaoInformadaEsperada, retornoObter.Mensagem.ParaUsuario);
        }

        ///  <summary>
        /// Realiza o teste padrão para o método Obter(TOConta).
        /// Validações realizadas: 
        /// - Chama o método Obter usando os filtros de chave informados.
        /// - Verifica se o retorno do método Obter foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Compara o retorno do Obter com os dados do TO preenchido antes do teste.
        /// </summary>
        [Test(Description = "Testa o método Obter(TOConta).", Author = "B43925")]
        public void US3_CA05_ObterContaForaDoIntervaloComFalhaTest()
        {
            // TODO: Preparar outros números, testar limites de borda
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Conta = 2000000001;
            toConta.Agencia = 9999;

            // Agir
            var retornoObter = this.RN.Obter(toConta);
            var mensagemContaForaDoIntervaloEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<Pwx.Pwxoiexn.Validacoes.IntervaloAttribute>(toConta, nameof(toConta.Conta));

            // Validar

            Assert.False(retornoObter.OK);
            Assert.That(retornoObter.Mensagem.ParaUsuario, Contains.Substring(mensagemContaForaDoIntervaloEsperada));
        }

        ///  <summary>
        /// Realiza o teste padrão para o método Obter(TOConta).
        /// Validações realizadas: 
        /// - Chama o método Obter usando os filtros de chave informados.
        /// - Verifica se o retorno do método Obter foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Compara o retorno do Obter com os dados do TO preenchido antes do teste.
        /// </summary>
        [Test(Description = "Testa o método Obter(TOConta).", Author = "B43925")]
        public void US3_CA06_ObterContaNaoCadastradaComFalhaTest()
        {
            // TODO: Preparar outros números, testar limites de borda
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Conta = 2000000;
            toConta.Agencia = 9987;

            // Agir
            var retornoObter = this.RN.Obter(toConta);
            string mensagemContaNaoCadastradaEsperada = "Não existe uma conta bancária cadastrada para os critérios informados.";

            // Validar

            Assert.False(retornoObter.OK);
            Assert.AreEqual(mensagemContaNaoCadastradaEsperada, retornoObter.Mensagem.ParaUsuario);
        }

        ///  <summary>
        /// Realiza o teste padrão para o método Alterar(TOConta).
        /// Validações realizadas: 
        /// - Altera o registro na base, conforme os dados informados.
        /// - Verifica se o retorno do método Alterar foi de sucesso.
        /// - Realiza as seguintes Assertivas:
        /// 1 - Retorno não está nulo.
        /// 2 - Retorno.OK é sucesso (== true).
        /// 3 - Retorno.Dados não está nulo.
        /// - Obtém o TO novamente da base, utilizando o método Obter.
        /// - Compara o retorno do Obter com os dados do TO preenchido.
        /// </summary>
        [Test(Description = "Testa o método Alterar(TOConta).", Author = "B43925")]
        public void US4_CA01_AlterarComSucessoTest()
        {
            // Preparar

            TOConta toContaConsulta = new TOConta();
            toContaConsulta.Agencia= 1237;
            toContaConsulta.Conta = 12313131;
            var retornoObter = this.RN.Obter(toContaConsulta);
            Assert.True(retornoObter.OK);
            retornoObter.Dados.IndSituacao = "A";

            // Agir

            var retornoAlterar = this.RN.Alterar(retornoObter.Dados);

            // Validar

            Assert.True(retornoAlterar.OK);
            Assert.NotZero(retornoAlterar.Dados);
            var retornoNovoObter = this.RN.Obter(toContaConsulta);
            Assert.AreEqual(this.Infra.Usuario.Matricula, retornoNovoObter.Dados.CodOperador);
            Assert.NotNull(retornoNovoObter.Dados.UltAtualizacao);
            base.TestarAlterar(retornoNovoObter.Dados);
        }

        ///  <summary>
        /// Realiza um teste para o método Alterar com teste de falha.
        /// </summary>
        [Test(Description="Testa o método Alterar(TOConta).", Author="B43925")]
		public void US4_CA02_AlterarAgenciaNaoInformadaComFalhaTest()
		{
            // Preparar
            string mensagemEsperada = "Um número válido de agência deve ser informado (entre 1000 e 9999).";
            TOConta toConta = new TOConta();
            toConta.Conta = 12313131;
            toConta.IndSituacao = "A";

            // Agir

            var retornoAlterar = this.RN.Alterar(toConta);

            // Validar

            Assert.False(retornoAlterar.OK);
            Assert.Zero(retornoAlterar.Dados);
            Assert.AreEqual(mensagemEsperada, retornoAlterar.Mensagem.ParaUsuario);
        }

        ///  <summary>
        /// Realiza um teste para o método Alterar com teste de falha.
        /// </summary>
        [Test(Description="Testa o método Alterar(TOConta).", Author="B43925")]
		public void US4_CA03_AlterarAgenciaForaDoIntervaloComFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Conta = 12313131;
            toConta.Agencia = 10000;
            toConta.IndSituacao = "A";

            var mensagemAgenciaForaDoIntervaloEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<Pwx.Pwxoiexn.Validacoes.IntervaloAttribute>(toConta, nameof(toConta.Agencia));

            // Agir

            var retornoAlterar = this.RN.Alterar(toConta);

            // Validar

            Assert.False(retornoAlterar.OK);
            Assert.Zero(retornoAlterar.Dados);
            Assert.That(retornoAlterar.Mensagem.ParaUsuario, Contains.Substring(mensagemAgenciaForaDoIntervaloEsperada));


        }

        ///  <summary>
        /// Realiza um teste para o método Alterar com teste de falha.
        /// </summary>
        [Test(Description="Testa o método Alterar(TOConta).", Author="B43925")]
		public void US4_CA04_AlterarContaNaoInformadaComFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Agencia = 1000;
            toConta.IndSituacao = "A";

            string mensagemContaNaoInformadaEsperada = "Um número válido de conta deve ser informado (entre 1 e 2000000000).";

            // Agir

            var retornoAlterar = this.RN.Alterar(toConta);

            // Validar

            Assert.False(retornoAlterar.OK);
            Assert.Zero(retornoAlterar.Dados);
            Assert.AreEqual(mensagemContaNaoInformadaEsperada, retornoAlterar.Mensagem.ParaUsuario);


        }

        ///  <summary>
        /// Realiza um teste para o método Alterar com teste de falha.
        /// </summary>
        [Test(Description="Testa o método Alterar(TOConta).", Author="B43925")]
		public void US4_CA05_AlterarContaForaDoIntervaloComFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Conta = -1;
            toConta.Agencia = 1000;
            toConta.IndSituacao = "A";

            var mensagemContaForaDoIntervaloEsperada = TOUtils.ExtrairMensagemAtributoValidacaoCampoTO<Pwx.Pwxoiexn.Validacoes.IntervaloAttribute>(toConta, nameof(toConta.Conta));

            // Agir

            var retornoAlterar = this.RN.Alterar(toConta);

            // Validar

            Assert.False(retornoAlterar.OK);
            Assert.Zero(retornoAlterar.Dados);
            Assert.That(retornoAlterar.Mensagem.ParaUsuario, Contains.Substring(mensagemContaForaDoIntervaloEsperada));


        }

        ///  <summary>
        /// Realiza um teste para o método Alterar com teste de falha.
        /// </summary>
        [Test(Description="Testa o método Alterar(TOConta).", Author="B43925")]
		public void US4_CA06_AlterarSituacaoNaoValidaComFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Conta = 1234;
            toConta.Agencia = 1000;
            toConta.IndSituacao = "b8";

            string mensagemSituacaoNaoValidaEsperada = "Uma situação válida deve ser informada ('A' para conta ativa, 'I' para inativa e 'S' para suspensa).";

            // Agir

            var retornoAlterar = this.RN.Alterar(toConta);

            // Validar

            Assert.False(retornoAlterar.OK);
            Assert.Zero(retornoAlterar.Dados);
            Assert.AreEqual(mensagemSituacaoNaoValidaEsperada, retornoAlterar.Mensagem.ParaUsuario);

        }

        ///  <summary>
        /// Realiza um teste para o método Alterar com teste de falha.
        /// </summary>
        [Test(Description="Testa o método Alterar(TOConta).", Author="B43925")]
		public void US4_CA07_AlterarContaNaoCadastradaComFalhaTest()
		{
            // Preparar
            TOConta toConta = new TOConta();
            toConta.Conta = 2000000;
            toConta.Agencia = 9987;

            string mensagemContaNaoCadastradaEsperada = "Não existe uma conta bancária cadastrada para os critérios informados.";

            // Agir

            var retornoAlterar = this.RN.Alterar(toConta);

            // Validar

            Assert.False(retornoAlterar.OK);
            Assert.Zero(retornoAlterar.Dados);
            Assert.AreEqual(mensagemContaNaoCadastradaEsperada, retornoAlterar.Mensagem.ParaUsuario);

        }
		#endregion
	}
}

