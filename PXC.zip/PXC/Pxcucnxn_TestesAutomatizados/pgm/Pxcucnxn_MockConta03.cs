﻿using Bergs.Bth.Bthsmoxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Mensagens;
using Bergs.Pxc.Pxcbtoxn;
using Bergs.Pxc.Pxcqcnxn;
using Bergs.Pxc.Pxcscnxn;
using NUnit.Framework;
using System;
using System.Collections.Generic;

namespace Bergs.Pxc.Pxcucnxn.Tests
{
	
	///  <summary>
	/// Contém os métodos de mock para testes da classe Conta.
	/// </summary>
	public class MockConta : AbstractMmMock
	{
		#region Construtor
		///  <summary>
		/// Construtor da classe de mocks
		/// </summary>
		/// <param name="infra">Infra</param>
		public MockConta(InfraTeste infra) : 
				base(infra)
		{
		}
		#endregion
		#region Métodos de mock de Falha.
		///  <summary>
		/// Registra um mock para o método Incluir.
		/// </summary>
		public void IncluirComSucesso()
		{
			Pxcqcnxn.Conta mockContaBD = this.Mock.Para<Pxcqcnxn.Conta>();
			mockContaBD.Incluir(MmMockArgumento.Qualquer<TOConta>()).Retorna(this.Infra.RetornarSucesso<Int32>(1));
            //var retornoObter = this.Infra.RetornarSucesso<TOConta>(new TOConta());
            mockContaBD.Obter(MmMockArgumento.Qualquer<TOConta>()).Retorna(this.Infra.RetornarSucesso<TOConta>(new TOConta()));
        }
		#endregion
	}
}

