﻿using Bergs.Pwx.Pwxodaxn;
using Bergs.Pwx.Pwxoiexn;
using Bergs.Pwx.Pwxoiexn.Btr;
using System;
using System.Data;
using System.Xml.Serialization;
using Bergs.Pwx.Pwxoiexn.Validacoes;
using Bergs.Pxc.Pxcbtoxn.pgm;

namespace Bergs.Pxc.Pxcbtoxn
{       
    /// <summary>Representa um registro da tabela CONTA da base de dados PXC.</summary>
    public class TOConta : TOTabela
  {

        #region Propriedades
        
        #region Chaves Primárias
        /// <summary>Campo AGENCIA da tabela CONTA.</summary>
        [XmlAttribute("agencia")]
        // R01
        [CampoTabela("AGENCIA", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal, Tamanho = 4, Precisao = 4)]
        // CA 03
        [Intervalo(1000, 9999, mensagemErro: "Um número válido de agência deve ser informado (entre 1000 e 9999).")]
        public CampoObrigatorio<decimal> Agencia { get; set; }
        
        /// <summary>Campo CONTA da tabela CONTA.</summary>
        [XmlAttribute("conta")]
        [CampoTabela("CONTA", Chave = true, Obrigatorio = true, TipoParametro = DbType.Decimal, Tamanho = 10, Precisao = 10)]
        // CA
        [Intervalo(1, 2000000000, mensagemErro: "Um número válido de conta deve ser informado (entre 1 e 2000000000).")]
        public CampoObrigatorio<decimal> Conta { get; set; }
        #endregion
        
        #region Campos Obrigatórios
        /// <summary>Campo SALDO da tabela CONTA.</summary>
        [XmlAttribute("saldo")]
        [CampoTabela("SALDO", Obrigatorio = true, TipoParametro = DbType.Decimal, Tamanho = 15, Precisao = 15, Escala = 2)]
        public CampoObrigatorio<decimal> Saldo { get; set; }
        
        /// <summary>Campo IND_SITUACAO da tabela CONTA.</summary>
        [XmlAttribute("ind_situacao")]
        [CampoTabela("IND_SITUACAO", Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<string> IndSituacao { get; set; }
        
        /// <summary>Campo COD_CLIENTE da tabela CONTA.</summary>
        [XmlAttribute("cod_cliente")]
        [CampoTabela("COD_CLIENTE", Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 14, Precisao = 14)]
        [CPFCNPJ(mensagemErro: "Um CPF ou CNPJ válido deve ser informado para o identificador.")]
        public CampoObrigatorio<string> CodCliente { get; set; }
        
        /// <summary>Campo IND_TP_PESSOA da tabela CONTA.</summary>
        [XmlAttribute("ind_tp_pessoa")]
        // R11
        [CampoTabela("IND_TP_PESSOA", Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 1, Precisao = 1)]
        public CampoObrigatorio<string> IndTpPessoa { get; set; }
        
        /// <summary>Campo COD_OPERADOR da tabela CONTA.</summary>
        [XmlAttribute("cod_operador")]
        [CampoTabela("COD_OPERADOR", Obrigatorio = true, TipoParametro = DbType.String, Tamanho = 6, Precisao = 6)]
        public CampoObrigatorio<string> CodOperador { get; set; }
        
        /// <summary>Campo ULT_ATUALIZACAO da tabela CONTA.</summary>
        [XmlAttribute("ult_atualizacao")]
        [CampoTabela("ULT_ATUALIZACAO", Obrigatorio = true, UltAtualizacao = true, TipoParametro = DbType.DateTime, Tamanho = 10, Precisao = 10, Escala = 6)]
        public CampoObrigatorio<DateTime> UltAtualizacao { get; set; }
        #endregion
        
        #region Campos Opcionais
        #endregion
        
        #endregion

        #region Métodos
        /// <summary>Popula os atributos da classe a partir de uma linha de dados.</summary>
        /// <param name="linha">Linha de dados retornada pelo acesso à base de dados.</param>
        public override void PopularRetorno(Linha linha)
        {
            //Percorre os campos que foram retornados pela consulta e converte seus valores para tipos do .NET
            foreach (Campo campo in linha.Campos)
            {
                switch (campo.Nome)
                {   
                    #region Chaves Primárias
                    case "AGENCIA":
                        Agencia = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "CONTA":
                        Conta = Convert.ToDecimal(campo.Conteudo);
                        break;                        
                    #endregion

                    #region Campos Obrigatórios
                    case "SALDO":
                        Saldo = Convert.ToDecimal(campo.Conteudo);
                        break;
                    case "IND_SITUACAO":
                        IndSituacao = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_CLIENTE":
                        CodCliente = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "IND_TP_PESSOA":
                        IndTpPessoa = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "COD_OPERADOR":
                        CodOperador = Convert.ToString(campo.Conteudo).Trim();
                        break;
                    case "ULT_ATUALIZACAO":
                        UltAtualizacao = Convert.ToDateTime(campo.Conteudo);
                        break;
                    #endregion

                    #region Campos Opcionais
                    #endregion

                    default:
                        //TODO: Tratar situação em que a coluna da tabela não tiver sido mapeada para uma propriedade do TO
                        break;
                }
            }
        }
        #endregion
    }
}