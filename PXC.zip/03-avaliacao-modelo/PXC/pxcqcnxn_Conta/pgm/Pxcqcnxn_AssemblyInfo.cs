﻿using System;
using System.Reflection;
using System.Runtime.InteropServices;
        
[assembly: CLSCompliant(true)]
[assembly: AssemblyTitle("Pxcqcnxn")]
[assembly: AssemblyCompany("Banrisul")]
[assembly: AssemblyProduct("Pxcqcnxn")]
[assembly: AssemblyCopyright("Copyright © Banrisul 2025")]
[assembly: AssemblyVersion("1.0.0.0")]
[assembly: AssemblyFileVersion("1.0.0.0")]
[assembly: ComVisible(false)]
[assembly: Guid("e13c1e2e-2622-48fa-b5ea-a0a8d4ad08f4")]